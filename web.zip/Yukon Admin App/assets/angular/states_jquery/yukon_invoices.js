/* [ Yukon Admin - invoices ] */

	$(function() {
		// invoices
		yukon_invoices.qr_code();
	});

	// invoices
	yukon_invoices = {
		qr_code: function() {
            if($('#invoice_qrcode').length) {

            }
		}
	};