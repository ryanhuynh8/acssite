<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global;
$completenum = request_var('complete', '');
$sortfield = request_var('sortfield', 'time_received');
$sortby = request_var('sortby', 'desc');
   //define object class
   $objrealtime = new dbrealtime();
   
   $where_clause = " 1 = 1 AND (rb.status = 3 OR rb.status = 1) AND rs.id = rb.status AND rb.board_system = 1";
   $realtimelist = $objrealtime->get_realtime($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby);
   $pending_total =0;
   $inprogress_total=0;
   if($realtimelist){
      foreach($realtimelist as $realtime){
         if($realtime['status'] == 1){
           $pending_total = $pending_total + 1;
         }
         if($realtime['status'] == 3){
           $inprogress_total = $inprogress_total + 1;
         }
      }
   }
 
 //Missing request
   $where_clause2 = " 1 = 1 AND (rb.status = 3 OR rb.status = 1) AND rs.id = rb.status AND rb.board_system = 2";
   $realtimelist_missing = $objrealtime->get_realtime($where_clause2, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby);
   $pending_total_missing =0;
   $inprogress_total_mising=0;
   if($realtimelist_missing){
      foreach($realtimelist_missing as $realtime){
         if($realtime['status'] == 1){
           $pending_total_missing = $pending_total_missing + 1;
         }
         if($realtime['status'] == 3){
           $inprogress_total_mising = $inprogress_total_mising + 1;
         }
      }
   }
 
 //Service request
   $where_clause3 = " 1 = 1 AND (rb.status = 3 OR rb.status = 1) AND rs.id = rb.status AND rb.board_system = 3";
   $realtimelist_request = $objrealtime->get_realtime($where_clause3, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby);
   $pending_total_request =0;
   $inprogress_total_request=0;
   if($realtimelist_request){
      foreach($realtimelist_request as $realtime){
         if($realtime['status'] == 1){
           $pending_total_request = $pending_total_request + 1;
         }
         if($realtime['status'] == 3){
           $inprogress_total_request = $inprogress_total_request + 1;
         }
      }
   }
 
   $templates->setvar("pending_total", $pending_total);
   $templates->setvar("inprogress_total", $inprogress_total);
   $templates->setvar("realtimelist", $realtimelist);
   
   $templates->setvar("pending_total_missing", $pending_total_missing);
   $templates->setvar("inprogress_total_mising", $inprogress_total_mising);
   $templates->setvar("realtimelist_missing", $realtimelist_missing);
   
   $templates->setvar("pending_total_request", $pending_total_request);
   $templates->setvar("inprogress_total_request", $inprogress_total_request);
   $templates->setvar("realtimelist_request", $realtimelist_request);
   $templates->show('realtime_data.tpl');
?>