<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $actionsPermission;

//define object class
$objtickets = new dbtickets();
$objticketstatus = new dbticketstatus();
$objstates = new dbstates();
$objuser = new dbuser();
$objjobstatus = new dbjobstatus();
$objcustomers = new dbcustomers();
$objstatusservice = new dbstatusservice();
$objbuilders = new dbbuilders();
$objproblem = new dbproblem();
$objrole = new dbroles();

//requets parameter
$search_name = request_var('search_name', '');
$search_address = request_var('search_address', '');
$search_city = request_var('search_city', '');
$search_state = request_var('search_state', '');
$search_zip = request_var('search_zip', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$dispatch = request_var('dispatch_id', '');
$assign = request_var('assign', '');
$statuses = $_GET['statuses'];
$urgency = request_var('urgency','');
$invoice = request_var('invoice_number', '');

$ticket_id = request_var('ticket_id', '');
$status_service_id = request_var('status_service_id', '');

switch ($mode)
{
    case "view":    	
        
        //get users for filter
		$users = $objuser->get_users('', 0, 0, 'name');
		//list statues
        $statuses_service = array();
        if (!in_array('see all records', $actionsPermission) )
		    $statuses_service = $objstatusservice->getStatusCountTickets($user_global['user_id'], array('Claimed', 'Completed', 'Cancelled'));
		else
            $statuses_service = $objstatusservice->getStatusCountTickets(0, array('Claimed', 'Completed', 'Cancelled'));

		$statusesTotal = array();
		$total = 0;
		foreach ($statuses_service as $entry)
		{
			$total += $entry['total'];
			$statusesTotal[$entry['status_service_id']] = $entry['total'];
		}
        
		$statuses = $statuses ? $statuses : array_keys($statusesTotal);
        
        
		
		
        $templates->setvar('users', $users);
		$templates->setvar('statuses', $statuses);
		$templates->setvar('total', $total);
		$templates->setvar('stauses_service', $statuses_service);
    break;

	case "load_markers" :
		
		//list statues
        $statuses_service = array();
        if (!in_array('see all records', $actionsPermission) )
		    $statuses_service = $objstatusservice->getStatusCountTickets($user_global['user_id'], array('Claimed', 'Completed', 'Cancelled'));
		else
            $statuses_service = $objstatusservice->getStatusCountTickets(0, array('Claimed', 'Completed', 'Cancelled'));

		$statusesTotal = array();		
		foreach ($statuses_service as $entry)
			$statusesTotal[$entry['status_service_id']] = $entry['total'];
        
		$statuses = $statuses ? $statuses : array_keys($statusesTotal);
        
        //get all tickets
        $where_clause = ' 1 = 1';        
        $where_clause .= $client_name ? " AND t.client_name like \"%$client_name%\" " : '';
        $where_clause .= $client_phone ? " AND t.client_phone like \"%$client_phone%\" " : '';
        $where_clause .= $client_address ? " AND t.client_address like \"%$client_address%\" " : '';
		$where_clause .= $dispatch ? " AND t.dispatch_id like \"%$dispatch%\" " : '';
        $where_clause .= $invoice ? " AND t.invoice_number like \"%$invoice%\" " : '';
        $where_clause .= $urgency ? " AND t.urgency like \"%$urgency%\" " : '';
        $where_clause .= $from_date ? " AND t.created_date >= '$from_date 00:00:00'" : '';
        $where_clause .= $to_date ? " AND t.created_date <= '$to_date 23:59:59'" : '';
		
        $where_clause .= $statuses ? " AND t.status_service_id IN (". implode(',', $statuses) .")" : '';
		
        if (!in_array('see all records', $actionsPermission) )
        {
            $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
        }
        else 
        {
        	if ($assign != "")
        		$where_clause .= " AND  t.assign_by = " . $objtickets->escape($assign);
        }
        
        
        $tickets_tmp = $objtickets->get_service_tickets($where_clause, null, null, null, null, false);
		$tickets = array();
		if ($tickets_tmp)
		{
			foreach ($tickets_tmp as $entry)
			{
				$record = array();
				$record['point'] = $entry['map_point'] ? $entry['map_point'] : getMapPoint($entry['fulladdress'], $entry['ticket_id']);
				$record['address'] = $entry['client_address'] . ',' . $entry['client_city'] . ',' . $entry['client_state'] . ' ' . $entry['client_zip'];
                if($entry['urgency']=="U"){
				$record['icon'] = "imagegen.php?src=images%2F". $entry['status_service_id'] ."u.png&character=" . $statusesTotal[$entry['status_service_id']];
                }else
				$record['icon'] = "imagegen.php?src=images%2F". $entry['status_service_id'] .".png&character=" . $statusesTotal[$entry['status_service_id']];
                $record['phone'] = $entry['client_phone'];
                $record['name'] = $entry['client_name'];

				$contentHtml = '';
				$contentHtml .= '<table width="100%" border="0" cellpadding="2" cellspacing="0">';
				$contentHtml .= "<tr><td><b>Dispatch No.:</b></td><td>{$entry['dispatch_id']}</td></tr>";
				$contentHtml .= "<tr><td><b>Customer:</b></td><td>{$record['name']}</td></tr>";
				$contentHtml .= "<tr><td><b>Phone:</b></td><td>{$record['phone']}</td></tr>";
				$contentHtml .= "<tr><td><b>Status:</b></td><td>" .
                                    (in_array('update ticket', $actionsPermission) ? getSelectStatuses($entry['status_service_id'], $entry['ticket_id']) : $entry['status_service_name']) .
									" <a href='tickets.php?ticketid={$entry['ticket_id']}'><img src='". $templates->template->template_dir ."/images/select.png' alt='Select Ticket' title='Select Ticket' /></a>".
									" <a href='createtickets.php?mode=details&id={$entry['ticket_id']}'><img src='". $templates->template->template_dir ."/images/view.png' alt='Details' title='Details' /></a>".
                                    (in_array('update ticket', $actionsPermission) ? " <a href='createtickets.php?mode=edit&id={$entry['ticket_id']}'><img src='". $templates->template->template_dir ."/images/edit.png' alt='Edit' title='Edit' /></a>" : '').
								"</td></tr>";
				$contentHtml .= "<tr><td><b>Assigned to:</b></td><td>{$entry['assign_name']}</td></tr>";
				$contentHtml .= "<tr><td><b>Promised Time:</b></td><td>". ($entry['promised_time_from'] ? $entry['promised_time_from'] : 'None') . ' - ' .
									($entry['promised_time_to'] ? $entry['promised_time_to'] : 'None') ."</td></tr>";
				$contentHtml .= '</table>';
				$record['content'] = $contentHtml;


                $contentHtml2 = '';
                $contentHtml2 .= '<table width="100%" border="0" cellpadding="3" cellspacing="0">';
                $contentHtml2 .= '<tr><td><b>Customer Name:</b></td><td>'. $record['name'] .'</td></tr>';
                $contentHtml2 .= '<tr><td><b>Address:</b></td><td>'. $record['address'] .'</td></tr>';
                $contentHtml2 .= '<tr><td><b>Phone:</b></td><td>'. $record['phone'] .'</td></tr>';
                $contentHtml2 .= '</table>';
                $record['content2'] = $contentHtml2;
				
				$tickets[] = $record;

			}
		}

		echo json_encode($tickets);
		
		exit();
	break;

	case "change_status":
    	if ($ticket_id && $status_service_id)
    	{
			$objtickets->save("UPDATE", array('status_service_id' => $status_service_id), " ticket_id = " . $objtickets->escape($ticket_id));
			echo $objtickets->sql;
    	}
		
		exit();
    break;
	
    case "refreshmap":
    	$from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        
        //get all status service for filter
        $stauses_service = array();
        $stauses_service_tmp = $objstatusservice->get_statuses(' status_service_id  not in(3,8)', 0, 0, 'status_service_name');
        
        $total_tickets_status = 0;
        if ($stauses_service_tmp)
        {
            foreach ($stauses_service_tmp as $record)
            {
                if ($record['status_service_id'] != 12)
                {
                    $where_clause = " t.status_service_id = " . $record['status_service_id'];

                    if (!in_array('see all records', $actionsPermission) )
                    {
                        $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
                    }
                    $total_tickets = $objtickets->get_all_tickets($where_clause, 0, 0, '', '', true);
                    $record['total'] = $total_tickets;
                    $stauses_service[] = $record;
                    $total_tickets_status += $total_tickets;
                }
            }
        }
        
        
        
        $templates->setvar('total_tickets_status', $total_tickets_status);
        
        //get all tickets
        $where_clause = ' 1 = 1';        
        $where_clause .= $client_name ? " AND t.client_name like \"%$client_name%\" " : '';
        $where_clause .= $client_phone ? " AND t.client_phone like \"%$client_phone%\" " : '';
        $where_clause .= $client_address ? " AND t.client_address like \"%$client_address%\" " : '';
        $where_clause .= $from_date ? " AND t.created_date >= '$from_date 00:00:00'" : '';
        $where_clause .= $to_date ? " AND t.created_date <= '$to_date 23:59:59'" : '';
        $where_clause .= $status_service ? " AND t.status_service_id in ($status_service)" : " AND t.status_service_id <> 12";	

        if (!in_array('see all records', $actionsPermission) )
        {
            $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
        }
        else 
        {
        	if ($assign != "")
        		$where_clause .= " AND  t.assign_by = " . $objtickets->escape($assign);
        }

        $tickets_tmp = $objtickets->get_service_tickets($where_clause . " and t.status_service_id not in (8,3)", null, null, null, null, false);        		
        $tickets = array();
        $sql = $objtickets->sql;
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $item)
            {
                $problems = $objtickets->get_problems_with_name_by_ticket($item['ticket_id']);
                $item['problem_name'] = $problems[0]['problem_name'];
                $tickets[] = $item;
            }
        }
        
       	echo refeshGoogleMap($tickets, $stauses_service);
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        $templates->setvar("bsys", $bsys);
        exit;
    break;		
	
    case "refreshstatus":
		//get all status service for filter
        $stauses_service = array();
        $stauses_service_tmp = $objstatusservice->get_statuses(' status_service_id  not in(3,8)', 0, 0, 'status_service_name');
        
        $total_tickets_status = 0;
        if ($stauses_service_tmp)
        {
            foreach ($stauses_service_tmp as $record)
            {
                if ($record['status_service_id'] != 12)
                {
                    $where_clause = " t.status_service_id = " . $record['status_service_id'];
                    if (!in_array('see all records', $actionsPermission) )
                    {
                        $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
                    }
                    $total_tickets = $objtickets->get_all_tickets($where_clause, 0, 0, '', '', true);
                    $record['total'] = $total_tickets;
                    $stauses_service[] = $record;
                    $total_tickets_status += $total_tickets;
                }
            }
        }
        $html = '<ul class="filter_radio">';
		foreach ($stauses_service as $status)
		{
			$html .= '<li><input type="checkbox" id="status_service_' . $status['status_service_id'] .'" value="' . $status['status_service_id'] .'" name="status_service[]" '; 
			if (in_array($status['status_service_id'], $_GET['status_service']))
				$html .= ' checked="checked" '; 
			$html .= '/><label for="status_service_' . $status['status_service_id'] .'"> <img src="imagegen.php?src=images%2F' . $status['status_service_id'] .'.png&character=' . $status['total'] .'"> ' . $status['status_service_name'] . ' (' . $status['total'] . ')</label></li>';
			if ($status['status_service_name'] == 'Accepted')
			{
				$html .= '<li><input type="checkbox" id="status_service_0" value="" name="status_service" ';
				if (!$_GET['status_service'])
					$html .= ' checked="checked" ';
				$html .= '/><label for="status_service_0"> ' . $lang['L_ALL'] . '(' . $total_tickets_status . ')</label></li>';
			}
				
		}
		$html .= "</ul>";
		echo $html;
		exit;
    break;
}

$templates->show('createtickets_map.tpl');


function refeshGoogleMap($ticketList, $statusList)
{
	global $configuration, $lang, $objstatusservice;
	//var_dump($ticketList);
	$script = "<script type=\"text/javascript\">

			function load() 
			{
			    if (GBrowserIsCompatible())
			    {
			        var map = new GMap2(document.getElementById(\"map\"));
			        map.addControl(new GSmallMapControl());
			        map.addControl(new GMapTypeControl());
			        map.setCenter(new GLatLng(29.7601927, -95.3693896), 10); 
			
			        // Creates a marker at the given point with the given number label
			        function createMarker(point, StoreInfo, type, char) {
			        	var baseurl = 'imagegen.php?src=';	
			        	var baseIcon = new GIcon(G_DEFAULT_ICON);
				       	var letteredIcon = new GIcon(baseIcon);
				       	letteredIcon.iconSize = new GSize(27, 27);
					    letteredIcon.image = baseurl + \"images%2F\" + type + \".png&character=\" + char;
					    //letteredIcon.image = \"images/\" + type + \".png\";
				   	 	// Set up our GMarkerOptions object
				   	  	markerOptions = { icon:letteredIcon };
			       		var marker = new GMarker(point, markerOptions);
		        		GEvent.addListener(marker, \"mouseover\", function() {
				        	marker.openInfoWindowHtml(StoreInfo);
			        	});
			        	return marker;
			        }
			        var point;";
					
			       foreach ($ticketList as $entry)
			       {
				       $script .= "         
				        var address = '<b>Dispatch No.: " . $entry['dispatch_id'] ."<br />Customer: " .$entry['customer_name'] . "<br />' +
				        			'Phone: " . $entry['customer_phone'] . "<br /><span style=\"color: #ff0000\">Status: " . ServiceStatusDropdown($entry['status_service_id'], $entry['ticket_id']) . "</span></b> &nbsp; ' + 
				        			'<a href=\"tickets.php?ticketid=" . $entry['ticket_id'] . "\"><img src=\"templates/default/fe/images/select.png\" alt=\"Select\" title=\"Select Ticket\" /></a> ' +
				        	        '<a href=\"createtickets.php?mode=details&id=" . $entry['ticket_id']  . "\"><img src=\"templates/default/fe/images/view.png\" alt=\"Details\" title=\"Details\" /></a> ' +
				        	        '<a href=\"createtickets.php?mode=edit&id=" . $entry['ticket_id']  . "\"><img src=\"templates/default/fe/images/edit.png\" alt=\"Edit\" title=\"Edit\" /></a> ' +";
				       
				        	        if ($entry['assign_name'] != "") 
				        	        	$script .= "'<br><b>Assigned to:  " . $entry['assign_name'] . "</b>' + ";

				        	        	
				        	        if ($entry['promised_time_from']) 
				        	        	$script .= "'<br /><b>Promised Time:</b>" . date("h:i A", strtotime($entry['promised_time_from'])). " - ' + ";
				        	        else 
				        	        	$script .= "'<br /><b>Promised Time:</b>" . $lang['L_NONE2'] . " - ' + ";
									
				        	        if ($entry['promised_time_to']) 
				        	        	$script .= "'" . date("h:i A", strtotime($entry['promised_time_to'])) . "' + ";
				        	        else 
			        	        		$script .= "'" . $lang['L_NONE2'] . "' + ";    
				        	        $script .= "'<br>" . $entry['customer_address'] . ", " . $entry['customer_city']. ", " . $entry['customer_state'] . " " . $entry['customer_zip'] . "';";
				        if ($entry['map_point'] != "" && $entry['map_point'] == '29.7601927, -95.3693896')
				        	$script .= "address += '<span style=\"color: #ff0000\">Cannot find out the address on Google map</span><br />' +  address;";
	
				    	if ($entry['map_point'] != "")	
				    		$script .= "point = new GLatLng(" . $entry['map_point'] . ");";
				    	else
				        	$script .= "point = new GLatLng(" . getMapPoint($entry['fulladdress'], $entry['ticket_id']) . ");";
	
				        $script .= "var char='';";
				        foreach ($statusList as $status)
				        {
				        	if ($entry['status_service_id'] == $status['status_service_id'])
				        	  $script .= "char = '" . $status['total'] . "';";
				        }    
				        $script .= "map.addOverlay(createMarker(point, address, '" .$entry['status_service_id'] . "', char));";
			       }
			    $script .= "}";
			$script .= "}";

				 $script .= "load() ;";


		$script .= "</script>";
		return $script;
}

function getSelectStatuses($selected, $ticketId)
{
	global $configuration, $lang, $objstatusservice;
	
	$stauses_service_tmp = $objstatusservice->get_statuses('', 0, 0, 'status_service_name');
	$dropdownbox = '<select ticket_id="'. $ticketId .'" class="select status" style="width:90px">';
	
	foreach($stauses_service_tmp as $status) 
	{
		if ($status["status_service_id"] == $selected)
			$dropdownbox .= '<option value="' . $status["status_service_id"] . '" selected >' . $status['status_service_name'] . '</option>';
		else 
			$dropdownbox .= '<option value="' . $status["status_service_id"] . '">' . $status['status_service_name'] . '</option>';	
	}
	$dropdownbox .= '</select>';
	
	return $dropdownbox;
}


?>