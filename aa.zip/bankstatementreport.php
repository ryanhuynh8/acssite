<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objproposals = new dbproposals();
$objproposalparts = new dbproposalparts();

$objbankcategories = new dbbankcategories();
$objbankstatement = new dbbankstatement();
$objbankaccounts = new dbbankaccounts();

//requets parameter
$category = request_var('category', '');
$account = request_var('account', '');
$fromDate = request_var('from_date', '');
$toDate = request_var('to_date', '');
$page = request_var('page', 1);
$id = request_var('id', '');
$type = request_var('type', '');
$amount = request_var('amount', '');
$postedDate = request_var('posted_date', '');
$description = request_var('description', '');
$deleteAll = request_var('delete_all', '');

$fromDate = convert_to_standard_date($fromDate);
$toDate = convert_to_standard_date($toDate);
$postedDate = convert_to_standard_date($postedDate);
$amount = str_replace(',', '', $amount);

switch ($mode)
{
    case 'view':
        //get all categories for select
        $categories = $objbankcategories->get_categories('', 0, 0, 'bank_category_name');
        $templates->setvar('categories', $categories);
        
        //get bank accounts for select
        $accounts = $objbankaccounts->get_accounts('', 0, 0, 'bank_account_id');
        $templates->setvar('accounts', $accounts);
        
        //delete all searched records        
        if ($deleteAll)
        {
            $whereClause = ' 1 = 1';
            $whereClause .= $category !== '' ? " AND bank_category_id = $category " : '';
            $whereClause .= $account ? " AND bank_account_id = $account " : '';
            $whereClause .= $fromDate ? " AND posted_date >= '$fromDate' " : '';
            $whereClause .= $toDate ? " AND posted_date <= '$toDate' " : '';
            $objbankstatement->sql = 'DELETE FROM ' . TBL_BANK_STATEMENT . ' WHERE ' . $whereClause;
            $objbankstatement->execute();
            
            if (mysql_affected_rows() > 0)
                $templates->setvar('delete_all_success', $lang['L_DELETED_ALL_SUCCESS']);
            else
                $templates->setvar('delete_all_success', $lang['L_NO_ITEM_FOUND']);
        }
        
    break;
    
    case 'deposits':
        $whereClause = ' 1 = 1';
        $whereClause .= " AND s.type <> 'DEBIT' AND s.amount >= 0 ";
        $whereClause .= $category !== '' ? " AND s.bank_category_id = $category " : '';
        $whereClause .= $account ? " AND s.bank_account_id = $account " : '';
        $whereClause .= $fromDate ? " AND s.posted_date >= '$fromDate' " : '';
        $whereClause .= $toDate ? " AND s.posted_date <= '$toDate' " : '';
        
        $statements = $objbankstatement->get_statements($whereClause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'posted_date'), request_var('sortby', 'desc') );
        $itemcount = $objbankstatement->get_statements($whereClause, 0, 0, '', '', true);        
        $templates->setvar('statements', $statements);
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        
        //get bank accounts for select
        $accounts = $objbankaccounts->getAccountsReport($whereClause);
        $templates->setvar('accounts', $accounts);
    break;

    case 'expenses':
        $whereClause = ' 1 = 1';
        $whereClause .= " AND (s.type = 'DEBIT' OR s.amount < 0) ";
        $whereClause .= $category !== '' ? " AND s.bank_category_id = $category " : '';
        $whereClause .= $account ? " AND s.bank_account_id = $account " : '';
        $whereClause .= $fromDate ? " AND s.posted_date >= '$fromDate' " : '';
        $whereClause .= $toDate ? " AND s.posted_date <= '$toDate' " : '';
        
        $statements = $objbankstatement->get_statements($whereClause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'posted_date'), request_var('sortby', 'desc') );
        $itemcount = $objbankstatement->get_statements($whereClause, 0, 0, '', '', true);        
        $templates->setvar('statements', $statements);
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        
        //get bank accounts for select
        $accounts = $objbankaccounts->getAccountsReport($whereClause);
        $templates->setvar('accounts', $accounts);
    break;

    case 'edit':
        if ($id)
        {
            //get all categories for select
            $categories = $objbankcategories->get_categories('', 0, 0, 'bank_category_name');
            
            //get bank accounts for select
            $accounts = $objbankaccounts->get_accounts('', 0, 0, 'bank_account_id');
            
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $statementInfo = $objbankstatement->get_statement_by_id($id);
                $templates->setvar('statementInfo', $statementInfo);
            }
            else
            {
                $error_validator = true;
                
                if ($type == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_type', $lang['E_TYPE']);
                }
                if ($postedDate == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_post_date', $lang['E_POST_DATE']);
                }
                elseif (is_valid_date($postedDate) )
                {
                    $error_validator = false;
                    $templates->setvar('error_post_date', $lang['E_POST_DATE_INVALID']);
                }
                if ($amount == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_amount', $lang['E_AMOUNT']);
                }
                elseif (!is_numeric($amount))
                {
                    $error_validator = false;
                    $templates->setvar('error_amount', $lang['E_AMOUNT_NUMERIC']);
                }
                
                $save_statement = array('bank_category_id'  => $category,
                                        'bank_account_id'   => $account,
                                        'type'              => trim($type),
                                        'posted_date'       => $postedDate,
                                        'amount'            => $amount,
                                        'description'       => $description);
                
                if ($error_validator)
                {
                    $objbankstatement->save('UPDATE', $save_statement, " bank_statement_id = $id");
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('statementInfo', $save_statement);
                }
            }
            
            $templates->setvar('accounts', $accounts);
            $templates->setvar('categories', $categories);
        }
    break;

    case "delete":
        if ($id)
        {
            $objbankstatement->delete($id);
            $templates->setvar('delete_success', true);
        }
        elseif (request_var('delete_all', '') == 'delete_all')
        {
            $objbankstatement->sql = 'DELETE FROM ' . TBL_BANK_STATEMENT;
            $objbankstatement->execute();
            $templates->setvar('delete_success', true);
        }
        
    break;
}



//show template
$templates->show('bankstatementreport.tpl');
?>