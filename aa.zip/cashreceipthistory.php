<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();
$objpaymenthistory = new dbpaymenthistory();
$objbuilders = new dbbuilders();
//requets parameter
$ticketid = request_var('id', '');
$history_id = request_var('history_id', '');
$received_date = request_var('received_date', '');
$received_amount = request_var('received_amount', '');
$payment_method = request_var('payment_method', '');
$payment_number_check = request_var('payment_number_check', '');
$payment_number_credit_card = request_var('payment_number_credit_card', '');


if ($ticketid)
{
    //delete payment history
    if ($mode == 'delete')
    {
        if ($history_id)
        {
            $objpaymenthistory->delete($history_id);
        }
        else
        {
            $save_ticket = array('payment_method' => '', 'payment_amount' => '');
            $objtickets->save('UPDATE', $save_ticket, "ticket_id = $ticketid");
        }
    }
    
    //get ticket information
    $ticket_infor = $objtickets->get_ticket_by_id($ticketid);
    
    //get builder discount
    $builder = $objbuilders->get_builder_by_id($ticket_infor['builder_id']);
    $ticket_infor['builder_discount'] = $builder['discount'];  
    
    //get payment history
    $payment_ticket = array(array('payment_history_id' => 0,
                                  'received_date' => $ticket_infor['complete_date'],
                                  'payment_method' => $ticket_infor['payment_method'],
                                  'received_amount' => $ticket_infor['payment_amount']) );
    
    $payments = $objpaymenthistory->get_payments("ticket_id = $ticketid", 0, 0, 'received_date', 'desc');
    if ($ticket_infor['payment_method'] && $ticket_infor['payment_amount'])
        $payments = array_merge($payment_ticket, $payments);
    
    //get total amount
    $total_amount = 0;
    if ($payments)
    {
        foreach ($payments as $payment)
        {
            $total_amount += $payment['received_amount'];
        }
    }
    $ticket_infor['total_amount'] = $total_amount;
    //get balanced amout
    $ticket_infor['balanced_amount'] = $ticket_infor['authoried_amount'] - ($ticket_infor['authoried_amount'] * $ticket_infor['builder_discount'] / 100);
    $ticket_infor['received_amount'] = number_format($ticket_infor['balanced_amount'] - $ticket_infor['total_amount'], 2, '.', '');
    $ticket_infor['customer_balance'] = $ticket_infor['received_amount'];
    //set session for validator
    $_SESSION['balanced_amount'] = $ticket_infor['balanced_amount'] - $ticket_infor['total_amount'];
    
    
    //submit value
    if ($_SERVER['REQUEST_METHOD'] == "POST")
    {
        $error_validator = true;
        
        if (trim($received_date) == '')
        {
            $error_validator = false;
            $templates->setvar('error_validator_amount', $lang['E_RECEIVED_DATE']);
        }
        elseif (trim($received_amount) == '')
        {
            $error_validator = false;
            $templates->setvar('error_validator_amount', $lang['E_RECEIVED_AMOUNT']);
        }
        elseif (!is_numeric($received_amount) )
        {
            $error_validator = false;
            $templates->setvar('error_validator_amount', $lang['E_RECEIVED_AMOUNT_NUMBERIC']);
        }
        elseif($received_amount < 0 )
        {
            $error_validator = false;
            $templates->setvar('error_validator_amount', $lang['E_RECEIVED_AMOUNT_NUMBERIC']);
        }
        elseif (number_format($received_amount, 2, '.', '') > number_format($_SESSION['balanced_amount'], 2, '.', '') )
        {
            $error_validator = false;
            $templates->setvar('error_validator_amount', $lang['E_RECEIVED_AMOUNT_GREATER']);
        }
        else
        {
            if ($payment_method == 'check' && trim($payment_number_check) == '')
            {
                $error_validator = false;
                $templates->setvar('error_validator_amount', $lang['E_CHECK_NUMBER']);
            }
            elseif ($payment_method == 'credit_card' && trim($payment_number_credit_card) == '')
            {
                $error_validator = false;
                $templates->setvar('error_validator_amount', $lang['E_CREDIT_CARD_NUMBER']);
            }
        }
        
        $save_payment = array('ticket_id' => $ticketid,
                              'received_date' => convert_to_standard_date($received_date),
                              'received_amount' => $received_amount,
                              'payment_method' => $payment_method);
        
        if ($payment_method == 'check')
            $save_payment['payment_number'] = $payment_number_check;
        elseif ($payment_method == 'credit_card')
            $save_payment['payment_number'] = $payment_number_credit_card;
        
        if ($error_validator)
        {
            $objpaymenthistory->save('INSERT', $save_payment);
            
            //update paid full
            $objtickets->UpdatePaidFullTicket($ticketid);
            
            redirect(get_page() . "?id=$ticketid");
        }
        else
        {
            $ticket_infor['received_amount'] = $save_payment['received_amount'];
            $ticket_infor['payment_method'] = $save_payment['payment_method'];
            $ticket_infor['received_date'] = $save_payment['received_date'];
        }
    }
    else
    {
        $ticket_infor['received_date'] = date('m/d/Y');
    }
    
    
    $templates->setvar('ticket_infor', $ticket_infor);
    $templates->setvar('users', $users);
    $templates->setvar('payments', $payments);
}

//show template
$templates->show('cashreceipthistory.tpl');
?>