<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objnotes = new dbnotes();

//requets parameter
$page = request_var('page', 1);
$id = request_var('id', '');
$name = request_var('name', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")

switch ($mode)
{
    case 'view' :
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $search = request_var('search', '');
            $clear = request_var('clear', '');
            if ($search)
            {
                $_SESSION['note_name'] = $name;
            }
            if ($clear)
            {
                $_SESSION['note_name'] = '';
            }
        }
        
        $where_clause = " 1 ";
        $where_clause .= $_SESSION['note_name'] ? " AND note_name like '%". $_SESSION['note_name'] ."%'" : '';
        $notes = $objnotes->get_notes($where_clause, 0, 0, request_var('sortfield', 'note_name'), request_var('sortby', 'asc') );      
        
        $templates->setvar('notes', $notes);
    break;

    case 'edit' :
        if ($id)
        {            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $note_infor = $objnotes->get_note_by_id($id);
                
                $templates->setvar('note_infor', $note_infor);
            }
            else
            {
                $validator_error = true;
                
                if (trim($name) == '')
                {
                    $validator_error = false;
                    $templates->setvar('error_name', $lang['E_NAME']);
                }
                
                $save_note = array('note_name' => $name);
                
                if ($validator_error)
                {
                    $objnotes->save('UPDATE', $save_note, " note_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {            
                    $templates->setvar('note_infor', $save_note);
                }
            }
        }
    break;
    
    case 'add' :
        
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $validator_error = true;
            
            if (trim($name) == '')
            {
                $validator_error = false;
                $templates->setvar('error_name', $lang['E_NAME']);
            }
            
            $save_note = array('note_name' => $name);
            
            if ($validator_error)
            {
                $objnotes->save('INSERT', $save_note);
                
                $templates->setvar('save_success', true);
            }
            else
            {            
                $templates->setvar('note_infor', $save_note);
            }
        }
    break;
    
    case 'details' :
        if ($id)
        {
            $note_infor = $objnotes->get_note_by_id($id);
                
            $templates->setvar('note_infor', $note_infor);
        }
    break;

    case 'delete' :
        if ($id)
        {
            $objnotes->delete($id);
            
            $templates->setvar('delete_success', true);
        }
    break;
}


//show template
$templates->show('notes.tpl');
?>