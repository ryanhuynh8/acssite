<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $tax;


//define object class
$objtickets = new dbtickets();
$objlaborsparts = new dblabors_parts();
$objbuilders = new dbbuilders();
//requets parameter
$builder = request_var('builder', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")

switch ($mode)
{
    case "view":
        get_date_month($start_date, $end_date);
        if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
        if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
        $templates->setvar('filter', array('from_date' => $from_date, 'to_date' => $to_date) );
        
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        
        //get allbuilder for select
        $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
        $templates->setvar('builders', $builders);
        
        //get all user
        $users_temp = $objuser->get_user_builder($builder);
        $users = array();
        $summary = array();
        $number_commission = 0;
        if ($users_temp)
        {
            foreach ($users_temp as $user)
            {
                if ($user['status'] != 0)
                {
                    $tickets_tmp = $objtickets->get_tickets_report($user['user_id'], $from_date, $to_date, $builder);
                
                    $tickets = array();
                    $results = array();
                    if ($tickets_tmp)
                    {
                        foreach ($tickets_tmp as $ticket)
                        {
                            $objtickets->get_ticket_report($ticket, $user['user_id']);
                            
                            $tickets[] = $ticket;
                        }
                    }
                    
                    unset($user['authorized_amount'], $user['discount'], $user['gross'], $user['parts_tax_amount'], $user['installed'],
                                $user['payment_amount'], $user['net'], $user['commission'], $user['cash'], $user['check'], $user['credit_card'], $user['tech_income']);
                    
                    $user['total_tickets'] = 0;
                    if ($tickets)
                    {
                        $index_commission = 0;
                        $number_ticket_worked = 0;                    
                        foreach ($tickets as $row)
                        {
                            $user['total_tickets'] += 1;
                            $user['authorized_average'] += number_format($row['authoried_amount'], 2, '.', '');
                            $user['authorized_amount'] += number_format($row['authoried_amount'], 2, '.', '');
                            $user['discount'] += number_format($row['discount'], 2, '.', '');
                            $user['gross'] += number_format($row['gross'], 2, '.', '');
                            $user['parts_tax_amount'] += number_format($row['parts_tax_amount'], 2, '.', '');
                            $user['labor'] += number_format($row['labor'], 2, '.', '');
                            $user['payment_amount'] += number_format($row['payment_amount'], 2, '.', '');
                            $user['net'] += number_format($row['net'], 2, '.', '');
                            $user['commission'] += number_format($row['commission'], 2, '.', '');
                            $user['tech_income'] += number_format($row['tech_income'], 2, '.', '');
                            $user['acs_income'] += number_format($row['acs_income'], 2, '.', '');
                            if ($row['commission'] > 0)
                                $index_commission++;                    
                            if ($row['payment_method'] == 'cash')
                                $user['cash'] += $row['payment_amount'];
                            if ($row['payment_method'] == 'check')
                                $user['check'] += $row['payment_amount'];
                            if ($row['payment_method'] == 'credit_card')
                                $user['credit_card'] += $row['payment_amount'];
                                
                            if (!$row['seller'] && $row['assign_by'] == $user['user_id'] || $row['seller'] == $user['user_id'])
                                $number_ticket_worked++;
                        }
                        if ($user['tech_income'])
                        {
                            $user['commission'] = $index_commission ? $user['commission'] / $index_commission : 0;
                            $number_commission++;
                        }
                        else
                            $user['commission'] = 0;
                        
                        $user['authorized_average'] = $number_ticket_worked ? number_format($user['authorized_amount'] / $number_ticket_worked, 2, '.', '') : 0;
                    }
                    
                    //send email to user
                    if ($_POST['send_report'] && is_array($_POST['users']) && in_array($user['user_id'], $_POST['users']) )
                    {
                        $subject = 'ACS - Payroll Report Summary';
                        $msgbody = get_email_body($user);
                        $email = $user['email'];
                        $from = $config->configurations["ADMIN_EMAIL"];
                        send_mail($from, $email, $subject, $msgbody, true);
                        
                        $templates->setvar('send_report_success', true);
                    }
                    
                    $summary['total_tickets'] += $user['total_tickets'];
                    $summary['authorized_average'] += $user['authorized_average'];
                    $summary['authorized_amount'] += $user['authorized_amount'];
                    $summary['discount'] += $user['discount'];
                    $summary['gross'] += $user['gross'];
                    $summary['parts_tax_amount'] += $user['parts_tax_amount'];
                    $summary['labor'] += $user['labor'];
                    $summary['payment_amount'] += $user['payment_amount'];
                    $summary['net'] += $user['net'];
                    $summary['commission'] += $user['commission'];
                    $summary['tech_income'] += $user['tech_income'];
                    $summary['acs_income'] += $user['acs_income'];
                    $summary['cash'] += $user['cash'];
                    $summary['check'] += $user['check'];
                    $summary['credit_card'] += $user['credit_card'];
                    
                    $users[] = $user;
                }
            }
        }
        
        $summary['commission'] = $number_commission ? $summary['commission'] / $number_commission : 0;
        $templates->setvar('users', $users);
        $templates->setvar('summary', $summary);
    break;
}


//show template
$templates->show('reportsummary.tpl');


function get_email_body($user)
{
    $body = '';
    
    $body .= "<div>Hi {$user['first_name']} {$user['last_name']},</div><br /><br />";
    $body .= "<div>Payroll report summary from {$_POST['from_date']} to {$_POST['to_date']}</div><br />";
    $body .= '
        <table width="100%" border="0" cellpadding="5" cellspacing="1">
            <tr>
                <td style="background-color:#eee;padding:0 5px;width:160px">Total Tickets:</td>
                <td>'. $user['total_tickets'] .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Avg. Cost:</td>
                <td>'. number_format($user['authorized_average'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Authorized Amount:</td>
                <td>'. number_format($user['authorized_amount'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Discount:</td>
                <td>'. number_format($user['discount'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Gross:</td>
                <td>'. number_format($user['gross'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Parts + Tax:</td>
                <td>'. number_format($user['parts_tax_amount'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Labor:</td>
                <td>'. number_format($user['labor'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Prepaid:</td>
                <td>'. number_format($user['payment_amount'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Net:</td>
                <td>'. number_format($user['net'], 2, '.', ',') .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">% Comm.:</td>
                <td>'. number_format($user['commission'], 0) .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Tech Income:</td>
                <td>'. number_format($user['tech_income'], 2, '.', ',') .'</td>
            </tr>
        </table>
    ';
    
    return $body;
}
?>