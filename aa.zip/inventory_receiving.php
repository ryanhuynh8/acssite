<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objlaborsparts = new dblabors_parts();
$objvendors = new dbvendors();

//requets parameter
$page = request_var('page', '1');
$description = request_var('description', '');
$item_number = request_var('item_number', '');
$id = request_var('labor_part_id', '');
$quantity = request_var('quantity', '');

switch ($mode)
{
    case "view":

        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            if ($id)
            {
                $error = false;
                if ($quantity == '')
                {
                    $error = true;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY']);
                }
                elseif (!ctype_digit($quantity))
                {
                    $error = true;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY_NUMERIC']);
                }

                if (!$error)
                {
                    $partInfo = $objlaborsparts->get_labor_part_by_id($id);
                    $savePart = array(
                        'quantity_on_hand' => $partInfo['quantity_on_hand'] + $quantity,
                        'updated_date' => date('Y-m-d H:i:s')
                    );
                    $objlaborsparts->save('UPDATE', $savePart, "labor_part_id=$id");
                }
            }

        }

        //get current summer
        $spring = strtotime(date('Y') . '-03-20');
        $summer = strtotime(date('Y') . '-07-20');
        $fall = strtotime(date('Y') . '-09-22');
        $winter = strtotime(date('Y') . '-12-21');

        $currentSeason = 'winter';
        if (time() >= $spring && time() < $summer)
            $currentSeason = 'spring';
        elseif (time() >= $summer && time() < $fall)
            $currentSeason = 'summer';
        elseif (time() >= $fall && time() < $winter)
            $currentSeason = 'fall';

        //get all labors
        $whereClause = '';
        if ($description)
            $whereClause .= " AND description like '%$description%'";
        if ($item_number)
            $whereClause .= " AND item_number like '%$item_number%'";

        $labors = $objlaborsparts->getLowInventories($whereClause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'item_number'), request_var('sortby', 'asc'));
        $itemcount = $objlaborsparts->getLowInventories($whereClause, 0, 0, '', '', true);

        $templates->setvar('labors', $labors);
        $templates->setvar('currentSeason', $currentSeason);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false, true) : "");
    break;
    
}



//show template
$templates->show('inventory_receiving.tpl');
?>