<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objproposals = new dbproposals();
$objproposalparts = new dbproposalparts();

//requets parameter
$id = request_var('id', '');
$category_name = request_var('category_name', '');
$ordering = request_var('ordering', '');
$actived = request_var('actived', '');
$page = request_var('page', 1);


switch ($mode)
{
    case 'view':       
        //get all proposal categories
        $where_clause = ' 1 = 1';
        $where_clause .= $category_name ? " AND name like '%$category_name%'" : '';
        
        $categories = $objproposals->get_categories($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'ordering'), request_var('sortby', 'asc') );
        $itemcount = $objproposals->get_categories($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('categories', $categories);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case 'edit':
        if ($id)
        {
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $category_infor = $objproposals->get_category_by_id($id);
                
                $templates->setvar('category_infor', $category_infor);
            }
            else
            {
                $error_validator = true;
                
                if ($category_name == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_category_name', $lang['E_CATEGORY_NAME']);
                }
                
                if ($ordering != '' && !is_numeric($ordering) || floatval($ordering) < 0)
                {
                    $error_validator = false;
                    $templates->setvar('error_ordering', $lang['E_ORDERING']);
                }
                
                $save_category = array('name' => $category_name,
                                       'ordering' => $ordering,
                                       'actived' => $actived);
                
                if ($error_validator)
                {
                    $objproposals->save_category('UPDATE', $save_category, " proposal_category_id = $id");
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('category_infor', $save_category);
                }
            }
        }
    break;

    case 'add':        
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $error_validator = true;
            
            if ($category_name == '')
            {
                $error_validator = false;
                $templates->setvar('error_category_name', $lang['E_CATEGORY_NAME']);
            }
            
            if ($ordering != '' && !is_numeric($ordering) || floatval($ordering) < 0)
            {
                $error_validator = false;
                $templates->setvar('error_ordering', $lang['E_ORDERING']);
            }
            
            $save_category = array('name' => $category_name,
                                   'ordering' => $ordering,
                                   'actived' => $actived);
            
            if ($error_validator)
            {
                $objproposals->save_category('INSERT', $save_category);
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('category_infor', $save_category);
            }
        }
    break;

    case 'details':
        if ($id)
        {            
            $category_infor = $objproposals->get_category_by_id($id);
                
            $templates->setvar('category_infor', $category_infor);
        }
    break;

    case "delete":
        if ($id)
        {
            $parts = $objproposalparts->get_parts_by_category($id);
            if ($parts)
            {
                $confirm_delete = request_var('confirm_delete', '');
                if ($confirm_delete)
                {
                    $objproposalparts->delete_parts_by_category($id);                    
                    $objproposals->delete_category($id);
                    $templates->setvar('delete_success', true);
                }
                else
                {
                    $templates->setvar('confirm_delete', true);
                }
            }
            else
            {
                $objproposals->delete_category($id);
                $templates->setvar('delete_success', true);
            }
        }
    break;
}



//show template
$templates->show('proposalcategories.tpl');
?>