<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();
$objticketstype = new dbticketstype();
//requets parameter
$ticket_id = request_var('ticketid', '');

//get all ticket type
$ticketstype = $objticketstype->get_ticketstype("t.ticket_id={$ticket_id}",0, 0,'created_date');
$templates->setvar('ticketstype', $ticketstype);

//show template
$templates->show('viewrecallhistory.tpl');
?>