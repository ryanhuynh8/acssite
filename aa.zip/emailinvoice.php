<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;


if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');
    
//define object class
$objtickets = new dbtickets();
$objcustomer = new dbcustomers();
$objlabors_parts = new dblabors_parts();
$objcompany = new dbcompany();
$objticketsequipments = new dbticketsequipments();
$objstatusservice = new dbstatusservice();
$objticketstatus = new dbticketstatus();
$objbuilders = new dbbuilders();

//requets parameter
$ticket_id = request_var('ticketid', '');
$email = request_var('email', '');
$payment_type = request_var('payment_type', '');
$payment_method = request_var('payment_method', '');
$payment_amount = request_var('payment_amount', '');
$check_number = request_var('check_number', '');
$card_security_code = request_var('card_security_code', '');
$discount = request_var('discount', '');

//get ticket information
$ticket_infor = $objtickets->get_ticket_by_id($ticket_id);
$templates->setvar('ticket_infor', $ticket_infor);

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $validator_error = true;
    if (trim($email) == '')
    {
        $validator_error = false;
        $templates->setvar('error_email', 'Email address field cannot be blank.');
    }
    else
    {
        if (!is_valid_email($email))
        {
            $validator_error = false;
            $templates->setvar('error_email', 'Invalid email address.');
        }
    }
    if ($discount > $ticket_infor['authoried_amount'])
    {
        $validator_error = false;
        $templates->setvar('error_discount', 'The Discount cannot be greater than Total Amount.');
    }
    
    if ($validator_error)
    {
        if ($mode != 'readonly')
        {
            $save_ticket = array('client_email' => $email,
                                'payment_method' => $payment_method,
                                'payment_amount' => $payment_amount,
                                'payment_type' => $payment_type,
                                'check_number' => $check_number,
                                'card_security_code' => $card_security_code,
                                'send_email_invoice' => 1,
                                'discount' => $discount);            
        }
        $save_ticket['discount'] = $discount;
        
        $objtickets->save('UPDATE', $save_ticket, "ticket_id = $ticket_id");
        
        $updateCustomerEmail = array("email" => $email);
        $objcustomer->save("UPDATE", $updateCustomerEmail, "customer_id = " . $ticket_infor["customer_id"]);
        
        //get information company
        $company_infor = $objcompany->get_company();
            
        //get equipments ticket
        $where_clause = " ticket_id = $ticket_id";
        $equipments = $objticketsequipments->get_ticketsequipments($where_clause, 0, 0);
            
        //get ticket informtion
        $ticket_infor = $objtickets->get_ticket_by_id($ticket_id);
        
        $status_service = $objstatusservice->get_status_by_id($ticket_infor['status_service_id']);
        $ticket_infor['status_service_name'] = $status_service['status_service_name'];
        
        $builder = $objbuilders->get_builder_by_id($ticket_infor['builder_id']);
        $ticket_infor['builder_name'] = $ticket_infor['builder_id'] ? $builder['full_name'] : $lang['L_RESALES'];
        
        $status = $objticketstatus->get_status_by_id($ticket_infor['status']);
        $ticket_infor['ticket_status'] = $status['status_name'];
        
        $user = $objuser->get_user_by_id($ticket_infor['posted_by']);
        $ticket_infor['posted_by'] = $user['first_name'] . ' ' . $user['last_name'];
        
        $user = $objuser->get_user_by_id($ticket_infor['assign_by']);
        $userInfoSurvey = $user;
        $ticket_infor['assign_by'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : '';
        
        $user = $objuser->get_user_by_id($ticket_infor['seller']);
        $ticket_infor['seller'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : '';        
        
        $problems = $objtickets->get_problems_with_name_by_ticket($ticket_infor['ticket_id']);
        $ticket_infor['problems'] = $problems;
        
        //get labor and parts
        $parts_tmp = $objlabors_parts->get_labors_parts_by_ticket($ticket_id, request_var('sortfield', 'type') . ' ' . request_var('sortby', 'asc') );
        $parts = array();
        //calculator part and labor
        $total_parts = 0;
        $total_labor = 0;
        if ($parts_tmp)
        {
            foreach ($parts_tmp as $part)
            {
                if ($part['type'] == 1)
                {
                   $total_labor += $part['price'] * $part['quantity'];
                   $part['name'] = $ticket_infor['assign_by'];
                }
                if ($part['type'] == 2)
                {
                    $total_parts += $part['price'] * $part['quantity'];
                    $part['name'] = $ticket_infor['seller'];
                }
                $part['ext_price'] = $part['price'] * $part['quantity'];
                $parts[] = $part;                
            }
        }
        $ticket_infor['total_parts'] = $total_parts;
        $ticket_infor['total_labor'] = $total_labor;
        if ($ticket_infor['tax_included'])
            $tax = 0;
        $ticket_infor['tax'] = $total_parts * $tax;        
        $ticket_infor['total'] = $ticket_infor['total_parts'] + $ticket_infor['total_labor'] + $ticket_infor['tax'];
        $ticket_infor['total_parts_labor'] = $total_parts + $total_labor;
        $ticket_infor['payment_amount'] = $ticket_infor['authoried_amount'] - $ticket_infor['discount'];
        //send email
        $msgbody = get_body_invoice($base_url, $company_infor, $ticket_infor, $equipments, $parts,$email);
        $from = $config->configurations["ADMIN_EMAIL"];
        $subject = "ACS Absolute Comfort LLC - Invoice Information";
        send_mail($from, $email, $subject, $msgbody, true);
        
        //send emailo survey
        //$msgbody = get_body_email_survey($ticket_infor, $userInfoSurvey);
        //$subject = "ACS Absolute Comfort LLC - Customer Service Survey";
        //send_mail($from, $email, $subject, $msgbody, true);
        
        $templates->setvar('save_success', true);
    }
    else
    {
        $ticket_infor['client_email'] = $email;
        $ticket_infor['discount'] = $discount;
        $templates->setvar('ticket_infor', $ticket_infor);
    }
}

$templates->show('emailinvoice.tpl');


function get_body_email_survey($ticket_infor, $userInfo)
{
    $userName = $userInfo['first_name'] . ' ' . $userInfo['last_name'];
    $userEmail = $userInfo['email'];
    
    $body = '';
    
    $body .= '<p>';
    $body .= 'Dear ' . $ticket_infor['client_name'] .'<br /><br />';
    $body .= 'Please help us serve you and others better by completing our Customer Service Survey here:';
    $body .= '<a href="http://www.acscomfort.com/surveys.php?name='. $ticket_infor['client_name'].'&email='. $email .'&phone='. $ticket_infor['client_phone'].'&technician_name='. $userName .'&technician_email='. $userEmail .'">http://www.acscomfort.com</a>';
    $body .= '<br /><br />Regards,<br />ACS Absolute Comfort';
    $body .= '</p>';
    
    return $body;
}

function get_body_invoice($base_url, $company_infor, $ticket_infor, $equipments, $parts, $email)
{
    global $lang;
    
    $body = '';
    if ($ticket_infor['paid'] && $ticket_infor['payment_method'] != 'non_collected')
    {
        $body .= '
            <div style="text-align:right;padding:10px 0">
                <img src="http://www.acscomfort.net/templates/default/fe/images/email_paid.png" />
            </div>';
    }
    
    $body .= '
        <div style="font-size:120%;">            
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tbody><tr>
                <td width="25%" align="center">';
    if ($ticket_infor['builder_id'] != 20 && $ticket_infor['builder_id'] != 33)
    {
        $body .=    '<img src="'. $base_url .'upload/company/' .$company_infor['logo'] .'" alt="' .$company_infor['name'] .'" title="' .$company_infor['name'] .'" />
                    <h1 style="white-space:nowrap;font-size:220%">'. $lang['L_SERVICE_RECORD'] .'</h1>
                    <h3 style="color:#ff0000;white-space:nowrap;text-align:left">'. $lang['L_THIS_IS_NOT_AN_INVOICE'] .'</h3>';
    }
    else
    {
        $body .=    '<img src="'. $base_url .'upload/company/' .$company_infor['logo'] .'" alt="' .$company_infor['name'] .'" title="' .$company_infor['name'] .'" />
                    <h1 style="white-space:nowrap;font-size:220%">'. $lang['L_SERVICE_INVOICE'] .'</h1>';
    }
    $body .= ' 
                </td>
                <td width="75%" valign="top" align="right" style="padding-top: 10px;">
                    <table width="380" cellspacing="1" cellpadding="5" border="0">
                        <tbody><tr>
                            <td valign="top" style="font-weight: bold;line-height: 120%;width: 60px;">'. $lang['L_NAME'] .'</td>
                            <td style="line-height: 120%;">' .$company_infor['name'] .'
                            <br>LIC. #: TACLB23232C
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-weight: bold;line-height: 120%;width: 60px;">'. $lang['L_ADDRESS'] .'</td>
                            <td style="line-height: 120%;">'. nl2br($company_infor['address']) .'</td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-weight: bold;line-height: 120%;width: 60px;">&nbsp;</td>
                            <td style="line-height: 120%;">
                                Tel. #: '. $company_infor['phone'] . '<br>
                                Email: <a href="mailto:support@acscomfort.com">support@acscomfort.com</a><br />
                                <a target="_blank" href="http://www.acscomfort.com">www.acscomfort.com</a>
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
            <tr>
                <td valign="top" colspan="2">
                    <div style="border: 1px solid #000000;line-height: 140%;padding: 2px 5px;text-align: left;">
                        <table width="100%" cellspacing="0" cellpadding="3" border="0">
                            <tbody><tr>
                                <td valign="top"><b>'. $lang['L_SOLD_TO'] .':</b></td>
                                <td style="width: 95%;">'. $ticket_infor['client_name'] .'</td>
                            </tr>
                            <tr>
                                <td valign="top"><div style="white-space: nowrap;"><b>'. $lang['L_SERVICED_AT'] .':</b></div></td>
                                <td>' .
                                    $ticket_infor['client_address'] .'<br />'.
                                    ($ticket_infor['client_city'] ? $ticket_infor['client_city'] . ' &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;' : ' ') .
                                    ($ticket_infor['client_state'] ? $lang['L_STATE'] . ': ' . $ticket_infor['client_state'] . ' &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;' : ' ') .
                                    ($ticket_infor['client_zip'] ? $lang['L_ZIP'] . ': ' .  $ticket_infor['client_zip'] . ' ' : '') . '
                                </td>
                            </tr>
                        </tbody></table>
                    </div>
                </td>
            </tr>
        </tbody></table>
        </div>
        <br />
        <div style="padding:5px 0;">';
            if ($equipments)
            {
                $body .= '
                <table width="100%" border="0" cellpadding="5" cellspacing="1">
                    <tr style="color:#fff; background-color:#045979;">
                        <th>'. $lang['L_INVOICE'] .'</th>
                        <th>'. $lang['L_MAKE_OF_EQUIPMENT'] .'</th>
                        <th>'. $lang['L_MODEL'] .'</th>
                        <th>'. $lang['L_SERIAL'] .'</th>
                    </tr>';
                    
                    
                        $index = 0;
                        foreach ($equipments as $entry)
                        {
                            $body .= '
                            <tr style="'. ($index % 2 == 0 ? 'background-color:#e1e1e1;' : 'background-color:#f7f7f7;') .'">
                                <td>'. $ticket_infor['invoice_number'] .'</td>
                                <td>'. $entry['made_by'] .'</td>
                                <td>'. $entry['model_number'] .'</td>
                                <td>'. $entry['serial_number'] .'</td>
                            </tr>
                            ';
                            $index ++;
                        }
                
                $body .= '
                </table>
                <br />';
            }    
            $body .= '
            <table width="100%" border="0" cellpadding="5" cellspacing="1">
                <tr style="color:#fff; background-color:#045979;">
                    <th colspan="4" align="center"><span style="font-size:135%">'. $lang['L_PARTS_USED'] .'</span></th>
                </tr>
                <tr style="color:#fff; background-color:#045979;">
                    <th>'. $lang['L_QUANTITY'] .'</th>
                    <th>'. $lang['L_DESCRIPTION'] .'</th>
                    <th style="width:120px">'. $lang['L_PRICE'] .'</th>
                    <th style="width:120px">'. $lang['L_AMOUNT'] .'</th>
                </tr>';
                
                if ($parts)
                {
                    $index = 0;
                    foreach ($parts as $entry)
                    {
                        if ($entry['type'] == 2)
                        {
                            $body .= '
                            <tr style="'. ($index % 2 == 0 ? 'background-color:#e1e1e1;' : 'background-color:#f7f7f7;') .'">
                                <td>'. $entry['quantity'] .'</td>
                                <td>'. $entry['description'] .'</td>
                                <td align="right">$'. $entry['price'] .'</td>
                                <td align="right">$'. $entry['ext_price'] .'</td>
                            </tr>
                            ';
                            $index++;
                        }
                    }
                }
                else
                {
                    $body .= '
                        <tr style="background-color:#e1e1e1;">
                            <td colspan="4">'. $lang['L_NO_PARTS_FOUND'] .'</td>
                        </tr>
                    ';
                }
                
                $body .= '
                <tr>
                    <td colspan="4">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="2" valign="top">
                        <table width="100%" border="0" cellpadding="5" cellspacing="1">
                            <tr style="color:#fff; background-color:#045979;">
                                <th>'. $lang['L_SERVICE_TECHNICIAN'] .'</a></th>
                                <th>'. $lang['L_DATE'] .'</th>
                                <th>'. $lang['L_DESCRIPTION'] .'</th>
                                <th>'. $lang['L_AMOUNT'] .'</th>
                            </tr>';
                            if ($parts)
                            {
                                $index = 0;
                                foreach ($parts as $entry)
                                {
                                    if ($entry['type'] == 1)
                                    {
                                        $body .= '
                                        <tr style="'. ($index % 2 == 0 ? 'background-color:#e1e1e1;' : 'background-color:#f7f7f7;') .'">
                                            <td>'. $entry['name'] .'</td>
                                            <td>'. date('m/d/Y', strtotime($entry['created_date']) ) .'</td>
                                            <td>'. $entry['description'] .'</td>
                                            <td align="right">$'. $entry['ext_price'] .'</td>
                                        </tr>
                                        ';
                                        $index++;
                                    }
                                }
                            }
                            else
                            {
                                $body .= '
                                    <tr style="background-color:#e1e1e1;">
                                        <td colspan="4">'. $lang['L_NO_TECHNICIAN'] .'</td>
                                    </tr>
                                ';
                            }
                            
                            $body .= '
                            <tr style="background-color:#e1e1e1;">
                                <td colspan="3" align="right"><b>'. $lang['L_TOTAL'] .':</b></td>
                                <td align="right"><b>$'. $ticket_infor['total_labor'] .'</b></td>
                            </tr>
                        </table>
                    </td>
                    <td colspan="2" valign="top">
                        <table width="100%" border="0" cellpadding="5" cellspacing="1">
                            <tr>
                                <td style="background-color:#e1e1e1;"><b>'. $lang['L_PARTS'] .'</b></td>
                                <td style="background-color:#e1e1e1;" align="right">$'. $ticket_infor['total_parts'] .'</td>
                            </tr>
                            <tr>
                                <td style="background-color:#f7f7f7;"><b>'. $lang['L_LABOR'] .'</b></td>
                                <td style="background-color:#f7f7f7;" align="right">$'. $ticket_infor['total_labor'] .'</td>
                            </tr>
                            <tr>
                                <td style="background-color:#e1e1e1;"><b>'. $lang['L_TAX'] .'</b></td>
                                <td style="background-color:#e1e1e1;" align="right">$'. number_format($ticket_infor['tax'], 2, '.', ',') .'</td>
                            </tr>
                            <tr>
                                <td style="background-color:#f7f7f7;"><b>'. $lang['L_TOTAL'] .'</b></td>
                                <td style="background-color:#f7f7f7;" align="right">$'.  number_format($ticket_infor['total'], 2, '.', ',') .'</td>
                            </tr>
                            <tr>
                                <td style="background-color:#e1e1e1;"><b>'. $lang['L_AMT_WITH_DISCOUNT'] .'</b></td>
                                <td style="background-color:#e1e1e1;" align="right">$'.  number_format($ticket_infor['discount'], 2, '.', ',') .'</td>
                            </tr>
                        </table>
                        <div style="padding-top: 5px;font-size: 120%;line-height: 140%;">
                            <table width="100%" border="0" cellpadding="5" cellspacing="1" style="border:0">';
                            if ($ticket_infor['payment_method'] == 'cash' || $ticket_infor['payment_method'] == 'check' || $ticket_infor['payment_method'] == 'credit_card')
                            {
                                $body .= '<tr><td><b>';                            
                                if ($ticket_infor['payment_type'] == 'Deductible' || !$ticket_infor['payment_type'])
                                    $body .= $lang['L_PAID_DEDUCTIBLE'] . ':';
                                elseif ($ticket_infor['payment_type'] == 'Paid in Full')
                                    $body .= $lang['L_PAID_IN_FULL'] . ':';
                                elseif ($ticket_infor['payment_type'] == 'Partial')
                                    $body .= $lang['L_PARTIAL_PAYMENT'] . ':';
                                
                                $body .= '</b></td>
                                <td align="right"><b>$'. number_format($ticket_infor['payment_amount'], 2, '.', ',') .'</b></td></tr>';
                            }
                            $body .= '<tr>
                                <td><b>'. $lang['L_PAYMENT_METHOD'] .':</b></td>
                                <td align="right"><b>';
                                if ($ticket_infor['payment_method'] == 'cash')
                                    $body .= $lang['L_CASH'];
                                elseif ($ticket_infor['payment_method'] == 'check')
                                    $body .= $lang['L_CHECK'];
                                elseif ($ticket_infor['payment_method'] == 'credit_card' || !$ticket_infor['payment_method'])
                                    $body .= $lang['L_CREDIT_CARD'];
                                elseif ($ticket_infor['payment_method'] == 'recalled')
                                    $body .= $lang['L_RECALLED'];
                                elseif ($ticket_infor['payment_method'] == 'non_collected')
                                    $body .= $lang['L_NON_COLLECTED'];
                                elseif ($ticket_infor['payment_method'] == 'coupon')
                                    $body .= $lang['L_COUPON'];
                                $body .= '</b></td>
                            </tr>';
                            if ($ticket_infor['payment_method'] == 'check')
                            {
                                $body .= '<tr>
                                    <td><b>'. $lang['L_CHECK_NUMBER'].':</b></td>
                                    <td align="right"><b>'. $ticket_infor['check_number'] .'</b></td>
                                </tr>';
                            }
                            elseif ($ticket_infor['payment_method'] == 'credit_card' || !$ticket_infor['payment_method'])
                            {
                                $body .= '<tr>
                                    <td><b>'. $lang['L_CARD_LAST_4_DIGITS'].':</b></td>
                                    <td align="right"><b>'. $ticket_infor['card_security_code'] .'</b></td>
                                </tr>';
                            }
                            $body .= '</table>                            
                        </div>
                    </td>
                </tr>
            </table>            
        </div>
        <br />
        ';
    if (trim($ticket_infor['field_notes']) )
    {
        $fieldNotes = html_entity_decode($ticket_infor['field_notes']);
        $fieldNotes = str_replace('<span>', '<span style="float:left;font-weight:bold;">', $fieldNotes);
        $fieldNotes = str_replace('<div>', '<div style="padding-left:150px;color:#444;padding-bottom:5px;">', $fieldNotes);
        
        $body .= '
            <div style="line-height:140%">
                <b>'. $lang['L_COMMENTS'] .':</b><br />
                '. $fieldNotes . '
            </div>  <br />      
        ';
    }
    $body .= '
    <div class="invoice_comments">
    <p style="margin: 0pt;">
    <b style="margin: 0pt;">'. $lang['L_PARTS_WARRANTY'] .'</b><br>
    '. $lang['L_PARTS_WARRANTY_TEXT'] .'<br><br>
    
    <b style="margin: 0pt;">'. $lang['L_LABOR_GUARANTY'] .'</b><br>
    '. $lang['L_LABOR_GUARANTY_TEXT'] .'<br><br>
    
    <b style="margin: 0pt;">'. $lang['L_TERMS_AND_CONDITIONS'] .'</b><br>
    '. $lang['L_TERMS_AND_CONDITIONS_TEXT'] .
    '<br /><br />
    <div>Please leave us review to help us improve our services by clicking these links below:<br>
    Facebook: <a href="https://www.facebook.com/acsabsolutecomfort" target="_blank">https://www.facebook.com/acsabsolutecomfort</a> <br>
    
    Thank you for your time and we appreciate your feedback.
    </div><br />
    <div style="text-align: center">
        Regulated by The Texas Department of Licensing and Regulation,<br>
            P.O. Box 12157, Austin, Texas 78711<br>
            1-800-803-9202, 512-463-6599,<br>
            <a href="http://www.license.state.tx.us" target="_blank">www.license.state.tx.us</a>
    </div>
    </p>
</div>';
    
    return $body;
}
?>