<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();
$objfilepayment = new dbfilepayment();
$objfiledetails = new dbfiledetails();
$objpaymenthistory = new dbpaymenthistory();
//requets parameter
$page = request_var('page', 1);
$file_id  =request_var('file_id', '');

switch ($mode)
{
    case 'view':
        //get all users
        $where_clause = ' 1 = 1';
        $files = $objfilepayment->get_file_payments($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'imported_date'), request_var('sortby', 'desc') );
        $itemcount = $objfilepayment->get_file_payments($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('files', $files);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case 'details':
        if ($file_id)
        {
            $file_infor = $objfilepayment->get_file_payment_by_id($file_id);
            $templates->setvar('file_infor', $file_infor);
            
            //get all users
            $where_clause = ' 1 = 1';
            $where_clause .= " AND file_payment_id = $file_id";
            $file_details = $objfiledetails->get_details($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'invoice_date'), request_var('sortby', 'desc') );
            $itemcount = $objfiledetails->get_details($where_clause, 0, 0, '', '', true);
            
            $templates->setvar('file_details', $file_details);
            //paging
            $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        }
    break;
    
    case 'import':
        
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $file_path = 'upload/file_payment/';
            $validator_error = true;
            
            $file = file_upload('file', $file_path);
            
            if ($file['error'] == 1)
            {
                $validator_error = false;
                $templates->setvar('error_file', $lang['E_FILE_SELECT']);
            }            
            else
            {
                $names = explode('.', $file['name']);
                $ext = $names[count($names)-1];
                if ($ext != 'csv')
                {
                    $validator_error = false;
                    $templates->setvar('error_file', $lang['E_FILE_TYPE']);
                }
                else
                {
                    $file_infor = $objfilepayment->get_file_payment_by_name($file['name']);
                    if ($file['error'] == 2 || $file_infor)
                    {
                        $validator_error = false;
                        $templates->setvar('error_file', $lang['E_FILE_EXISTS']);
                    }
                }
            }
            if ($validator_error)
            {
                $file = file_upload('file', $file_path, true);
                
                
                
                
                //insert file name to data
                $save_file_payment = array('file_payment_name' => $file['name'],
                                           'imported_date' => date('Y-m-d H:i:s'),
                                           'processed' => 0);
                
                $file_payment_id = $objfilepayment->save('INSERT', $save_file_payment);
                
                //import data from csv file to database
                $total_row = $objfiledetails->import_csv($file_payment_id, $file_path . $file['name']);
                
                $templates->setvar('save_success', true);
                $templates->setvar('total_row', $total_row);
            }
        }
    break;

    case 'report':
        if ($file_id)
        {
            //get errors processed
            $errors = $objfiledetails->get_errors_report($file_id);
            $templates->setvar('errors', $errors);
            
            //get summarty file payment information
            $file_infor = $objfilepayment->get_file_payment_by_id($file_id);           
            $total_errors = 0;
            $total_success = 0;
            if ($errors)
            {
                foreach ($errors as $error)
                {
                    if ($error['error'])
                        $total_errors++;
                    else
                        $total_success++;
                }
            }
            $file_infor['total_errors'] = $total_errors;
            $file_infor['total_processed'] = $total_success + $total_errors;
            
            $templates->setvar('file_infor', $file_infor);
            
            
        }
    break;
    
    case 'process':
        if ($file_id)
        {
            //update invoice
            $errors = $objfiledetails->get_errors_report($file_id);
            if ($errors)
            {
                foreach ($errors as $error)
                {
                    if (!$error['error'])
                    {
                        $save_payment_history = array('ticket_id' => $error['ticket_id'],
                                                      'received_date' => date('Y-m-d H:i:s'),
                                                      'received_amount' => $error['voucher_amount'],
                                                      'payment_method' => 'credit_card');
                        
                        $objpaymenthistory->save('INSERT', $save_payment_history);
                        $objfiledetails->save('UPDATE', array('done' => 1), " invoice_number = '" . $error['invoice_number'] . "'");
                    }
                }
            }
            //update status
            $save_file_payment = array('processed' => 1, 'processed_date' => date('Y-m-d H:i:s') );
            $objfilepayment->save('UPDATE', $save_file_payment, " file_payment_id = $file_id");
            
            $templates->setvar('save_success', true);
        }
    break;
}





//show template
$templates->show('importpayments.tpl');
?>