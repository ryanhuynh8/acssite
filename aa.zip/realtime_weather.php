<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global, $actionsPermission;

//define object class


//requets parameter


switch($mode)
{
    case 'view':
        $url_xml = "http://xml.weather.yahoo.com/forecastrss/77030_f.xml";
        $xml = simplexml_load_file($url_xml);
        $data = $xml->xpath("/rss/channel");
        $data = $data[0];
        
        $results = array();
        $results['location']['city'] = $data->children('yweather', true)->location->attributes()->city;
        $results['location']['region'] = $data->children('yweather', true)->location->attributes()->region;
        $results['location']['country'] = $data->children('yweather', true)->location->attributes()->country;
        
        $results['pubDate'] = $data->item->pubDate;
        $results['weather'] = $data->item->children('yweather', true)->condition->attributes()->text;
        $results['code'] = $data->item->children('yweather', true)->condition->attributes()->code;
        $results['temp'] = $data->item->children('yweather', true)->condition->attributes()->temp;
        $results['pressure'] = $data->children('yweather', true)->atmosphere->attributes()->pressure;
        $results['humidity'] = $data->children('yweather', true)->atmosphere->attributes()->humidity;
        $results['wind'] = $data->children('yweather', true)->wind->attributes()->speed;
        
        $results['units']['temp'] = $data->children('yweather', true)->units->attributes()->temperature;
        $results['units']['pressure'] = $data->children('yweather', true)->units->attributes()->pressure;
        $results['units']['wind'] = $data->children('yweather', true)->units->attributes()->speed;
        
        $forecast = array();
        foreach ($data->item->children('yweather', true)->forecast as $key => $entry)
        {
            $row = array();
            $row['day'] = $entry->attributes()->day;
            $row['code'] = $entry->attributes()->code;
            $row['weather'] = $entry->attributes()->text;
            $row['hight'] = $entry->attributes()->high;
            $row['low'] = $entry->attributes()->low;
            $forecast[] = $row;
        }
        
        $results['forecast'] = $forecast;
        
        $templates->setvar('data', $results);
    break;
}


$templates->show('realtime_weather.tpl');
?>