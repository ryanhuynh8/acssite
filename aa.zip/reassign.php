<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();
$objuser = new dbuser();
$objticketstatus = new dbticketstatus();
$objcustomers = new dbcustomers();

//requets parameter
$ticketid = request_var('ticketid', '');
$re_assign = request_var('re_assign', '');

//get all users for select
$users = $objuser->get_users('', 0, 0, 'name');

//get ticket information
$ticket_infor = $objtickets->get_ticket_by_id($ticketid);

$user = $objuser->get_user_by_id($ticket_infor['posted_by']);
$ticket_infor['posted_by'] = $user['first_name'] . ' ' . $user['last_name'];

$status = $objticketstatus->get_status_by_id($ticket_infor['status']);
$ticket_infor['ticket_status'] = $status['status_name'];

//get customer information
$customer = $objcustomers->get_customer_by_id($ticket_infor['customer_id']);
$ticket_infor['customer_name'] = $customer['full_name'];
$ticket_infor['customer_address'] = $customer['address'];
$ticket_infor['customer_city'] = $customer['city'];
$ticket_infor['customer_state'] = $customer['state'];
$ticket_infor['customer_zip'] = $customer['zip'];
$ticket_infor['customer_phone'] = $customer['phone1'];


$templates->setvar('ticket_infor', $ticket_infor);
$templates->setvar('users', $users);

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $error_validator = true;
    
    if ($re_assign == '')
    {
        $templates->setvar('error_re_assign', $lang['E_RE_ASSIGN']);
        $error_validator = false;
    }
    
    if ($error_validator && $re_assign)
    {
        $save_ticket = array ('assign_by' => $re_assign);
        
        $objtickets->save('UPDATE', $save_ticket, " ticket_id = $ticketid");
        //redirect page under popup when added parts
        echo '<script type="text/javascript">window.top.location.href="dashboard.php"</script>';
    }
}


//show template
$templates->show('reassign.tpl');
?>