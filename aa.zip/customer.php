<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objbuilders = new dbbuilders();
$objcustomers = new dbcustomers();
$objstates = new dbstates();
$objtickets = new dbtickets();

//requets parameter
$page = request_var('page', '1');
$customer_name = request_var('customer_name', '');
$office_number = request_var('office_number', '');
$id = request_var('id', '');
$full_name = request_var('full_name', '');
$address = request_var('address', '');
$city = request_var('city', '');
$state = request_var('state', '');
$zip = request_var('zip', '');
$phone1 = request_var('phone1', '');
$phone2 = request_var('phone2', '');
$builder1 = request_var('builder1', '');
$builder2 = request_var('builder2', '');
$builder3 = request_var('builder3', '');
$builder4 = request_var('builder4', '');
$email = request_var('email', '');
$client_builder = request_var('client_builder', '');

switch ($mode)
{
    case "view":
        //get all builder for select
        $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
        $templates->setvar('builders', $builders);
        //get all customers
        $where_clause = " 1 = 1";
        if ($customer_name)
            $where_clause .= " AND c.full_name like '%$customer_name%'";
        if ($office_number)
            $where_clause .= " AND c.office_number like '%$office_number%'";
        $where_clause .= $client_builder ? " AND ( c.builder_id_1 = $client_builder OR c.builder_id_2 = $client_builder OR c.builder_id_3 = $client_builder OR c.builder_id_4 = $client_builder ) " : '';

        $customers = $objcustomers->get_customers($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'customer_id'), request_var('sortby', 'desc') );
        $itemcount = $objcustomers->get_customers($where_clause, 0, 0, '', '', true);
        $templates->setvar('customers', $customers);        
        
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "details":
        if ($id)
        {
            //get customer information
            $customer_infor = $objcustomers->get_customer_by_id($id);
            
            $templates->setvar('customer_infor', $customer_infor);         
        }
    break;

    case "delete":
        if ($id)
        {
            $save_ticket = array('customer_id' => 0);
            $objtickets->save('UPDATE', $save_ticket, "customer_id = $id");
            //delete customer
            $objcustomers->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {
            //get state for select
            $states = $objstates->get_states('', 0, 0, 'state_code');
            $templates->setvar('states', $states);
            
            //get builder for select
            $builders = $objbuilders->get_builders('',0, 0, 'full_name');
            $templates->setvar('builders', $builders);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                //get customer information
                $customer_infor = $objcustomers->get_customer_by_id($id);
                $templates->setvar('customer_infor', $customer_infor);                
            }
            else
            {
                $validator = true;
            
                if (trim($full_name) == '')
                {
                    $validator = false;
                    $templates->setvar('error_full_name', $lang['E_NAME']);
                }
                if (trim($address) == '')
                {
                    $validator = false;
                    $templates->setvar('error_address', $lang['E_ADDRESS']);
                }
                if (trim($email) && !is_valid_email($email))
                {
                    $validator = false;
                    $templates->setvar('error_email', $lang['E_EMAIL']);
                }
                
                $save_customer = array( 'full_name' => $full_name,
                                        'address' => $address,
                                        'city' => $city,
                                        'state' => $state,
                                        'zip' => $zip,
                                        'phone1' => $phone1,
                                        'phone2' => $phone2,
                                        'email' => $email,
                                        'builder_id_1' => $builder1,
                                        'builder_id_2' => $builder2,
                                        'builder_id_3' => $builder3,
                                        'builder_id_4' => $builder4,
                                        'office_number' => $office_number);
                
                $customers = $objcustomers->check_exist_customer($save_customer);
                if ($customers && $customers[0]['customer_id'] != $id)
                {
                    $validator = false;
                    $templates->setvar('error_customer', $lang['E_CUSTOMER_EXISTS']);
                }
                
                if ($validator)
                {
                    $objcustomers->save('UPDATE', $save_customer, "customer_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('customer_infor', $save_customer);  
                }
            }
        }
    break;
    
    case "add":
        //get state for select
        $states = $objstates->get_states('', 0, 0, 'state_code');
        $templates->setvar('states', $states);
        
        //get builder for select
        $builders = $objbuilders->get_builders('',0, 0, 'full_name');
        $templates->setvar('builders', $builders);
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $validator = true;
            
            if (trim($full_name) == '')
            {
                $validator = false;
                $templates->setvar('error_full_name', $lang['E_NAME']);
            }
            if (trim($address) == '')
            {
                $validator = false;
                $templates->setvar('error_address', $lang['E_ADDRESS']);
            }
            if (trim($email) && !is_valid_email($email))
            {
                $validator = false;
                $templates->setvar('error_email', $lang['E_EMAIL']);
            }
            
            $save_customer = array('full_name' => $full_name,
                                   'address' => $address,
                                   'city' => $city,
                                   'state' => $state,
                                   'zip' => $zip,
                                   'phone1' => $phone1,
                                   'phone2' => $phone2,
                                   'email' => $email,
                                   'builder_id_1' => $builder1,
                                   'builder_id_2' => $builder2,
                                   'builder_id_3' => $builder3,
                                   'builder_id_4' => $builder4,
                                   'office_number' => $office_number);
            
            $customers = $objcustomers->check_exist_customer($save_customer);
            if ($customers)
            {
                $validator = false;
                $templates->setvar('error_customer', $lang['E_CUSTOMER_EXISTS']);
            }
            
            if ($validator)
            {
                $objcustomers->save('INSERT', $save_customer);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('customer_infor', $save_customer);  
            }
        }
    break;
}



//show template
$templates->show('customer.tpl');
?>