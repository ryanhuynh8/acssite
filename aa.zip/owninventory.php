<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global, $actionsPermission;

//define object class
$objlaborsparts = new dblabors_parts();
$objtickets = new dbtickets();
$objinventory = new dbinventory();

//requets parameter
$page = request_var('page', '1');
$item_number = request_var('item_number', '');
$description = request_var('description', '');

switch ($mode)
{
    case "view":
        
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $warningQuantity = $_POST['warning_quantity'];
            foreach ($warningQuantity as $key=>$value)
            {
                $objinventory->save('UPDATE', array('warning_quantity' => $value), " inventory_id=$key");
            }
            
        }
        
        $user_id = $user_global['user_id'];
        
        //get user information
        $user_infor = $objuser->get_user_by_id($user_id);
        $templates->setvar('user_infor', $user_infor);
        
        //get part by technicians
        $where_clause = " 1 AND i.user_id = " . $user_infor['user_id'];
        $where_clause .= $item_number ? " AND lb.item_number like '%$item_number%'" : '';
        $where_clause .= $description ? " AND lb.description like '%$description%'" : '';
        
        $tmp_parts = $objinventory->get_inventories($where_clause, 0, 0, request_var('sortfield', 'inventory_id'), request_var('sortby', 'asc') );            
        $parts = array();
        $total_amount = 0;
        if ($tmp_parts)
        {
            foreach ($tmp_parts as $part)
            {
                $part['tech_price'] = $part['unit_cost']  + $part['unit_cost'] * $part['tech_mark_up'] / 100;
                $part['price'] = number_format($part['tech_price'], 2, '.', '') * number_format($part['quantity'], 2, '.', '');
                $parts[] = $part;
                
                $total_amount += $part['price'];
            }                
        }
        
        $templates->setvar('total_amount', $total_amount);
        $templates->setvar('parts', $parts);
    break;
}


//show template
$templates->show('owninventory.tpl');
?>