<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objrole = new dbroles();
$objstatusservice = new dbstatusservice();
$objrolesstatusservice = new dbrolesstatusservice();
//requets parameter
$id = request_var('id', '');
$role_name = request_var('role_name', '');
$role_description = request_var('role_description', '');


switch ($mode)
{
    case "view":
        //get all pages
        $pages = $objrole->get_pages(0, 'displayed_order');
        //get all roles
        $roles = array();
        $roles_tmp = $objrole->get_roles();
        foreach ($roles_tmp as $role)
        {
            $permitsion = $objrole->get_permitsion($role['role_id']);
            $pages_permitsion = array();
            $pagesName = array();
            foreach ($pages as $page)
            {
                foreach ($permitsion as $item)
                {
                    if ($page['page_id'] == $item['page_id'])
                    {
                        $page['permitsion'] = true;
                        $pagesName[] = $page['page_name'];
                        break;
                    }
                }
                $pages_permitsion[] = $page;
            }
            //statuses
            $statuses = $objrolesstatusservice->get_roles_status_service_name($role['role_id']);
            
            $role['pages_permitsion'] = $pages_permitsion;
            $role['pages_name'] = implode(', ', $pagesName);
            $role['statuses_name'] = implode(', ', $statuses);
            $roles[] = $role;
        }
        
        //set variable for template
        $templates->setvar('pages', $pages);
        $templates->setvar('roles', $roles);
    break;
    case 'edit':
        if ($id)
        {            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $role_infor = $objrole->get_role($id);
                
                $pages_permission = $objrole->get_pages_permission_by_role($role_infor['role_id']);
                $pages_checked = array();
                foreach ($pages_permission as $item)
                {
                    $actions = explode("\n", $item['actions']);
                    $pages_checked[$item['page_id']] = $actions;
                }
                //get all pages
                $pages = $objrole->get_pages_form(0, $pages_checked);
                
                $role_infor['pages'] = $pages;
                
                $templates->setvar('role_infor', $role_infor);
            }
            else
            {
                $error_validator = true;
            
                if (trim($role_name) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_role_name', 'Role Name field cannot be blank!');
                }
                
                $save_role = array('role_name' => $role_name,
                                   'role_description' => $role_description);
                
                if($error_validator)
                {
                    $objrole->save('UPDATE', $save_role, "role_id = $id");
                    
                    //delete all pages permitsion
                    $objrole->delete_pages_permitsion($id);
                    
                    //insert new pages persmitsion
                    foreach ($_POST['page'] as $key=>$value)
                    {
                        $objrole->save_pages_permitsion($id, $value,  is_array($_POST[$value]) ? implode('\n', $_POST[$value]) : '');
                    }
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $role_infor = $save_role;
                    $pages_checked = array();
                    foreach ($_POST['page'] as $key=>$value)
                    {
                        if (is_array($_POST[$value]) )
                        {
                            foreach ($_POST[$value] as $key2=>$value2)
                            {
                                $pages_checked[$value][] = $value2;
                            }
                        }
                    }
                    $pages = $objrole->get_pages_form(0, $pages_checked);
                    $role_infor['pages'] = $pages;
                    $templates->setvar('role_infor', $role_infor);
                }
                
            }
        }
    break;
    case 'add':
        
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            //get all pages
            $pages = $objrole->get_pages_form(0);
        
            $role_infor = $objrole->get_role($id);
            
            $role_infor['pages'] = $pages;
            $templates->setvar('role_infor', $role_infor);
        }
        else
        {
            $error_validator = true;
            
            if (trim($role_name) == '')
            {
                $error_validator = false;
                $templates->setvar('error_role_name', 'Role Name field cannot be blank!');
            }
            
            $save_role = array('role_name' => $role_name,
                               'role_description' => $role_description);
            
            if($error_validator)
            {
                $id = $objrole->save('INSERT', $save_role);
                
                //insert new pages persmitsion
                foreach ($_POST['page'] as $key=>$value)
                {
                    $objrole->save_pages_permitsion($id, $value, implode('\n', $_POST[$value]) );
                }
                
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $role_infor = $save_role;
                $pages_checked = array();
                foreach ($_POST['page'] as $key=>$value)
                {
                    if (is_array($_POST[$value]) )
                    {
                        foreach ($_POST[$value] as $key2=>$value2)
                        {
                            $pages_checked[$value][] = $value2;
                        }
                    }
                }
                $pages = $objrole->get_pages_form(0, $pages_checked);
                $role_infor['pages'] = $pages;
                $templates->setvar('role_infor', $role_infor);
            }
        }
        
        
    break;
    case 'delete':
        if ($id)
        {
            //delete pages permitsion
            $objrole->delete_pages_permitsion($id);            
            //delete role
            $objrole->delete($id);
            
            $templates->setvar('delete_success', true);
        }
    break;
    case 'status_permission':
        if ($id)
        {            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $role_infor = $objrole->get_role($id);
                
                $pages_permission = $objrole->get_pages_permission_by_role($role_infor['role_id']);
                $pages_checked = array();
                foreach ($pages_permission as $item)
                {
                    $pages_checked[] = $item['page_id'];
                }
                //get all statuses service
                $statuses = $objstatusservice->get_statuses('', 0, 0, 'status_service_name');                
                $role_infor['statuses'] = $statuses;
                
                //get permission
                $permission = $objrolesstatusservice->get_roles_status_service($id);
                $role_infor['permission'] = $permission;
                
                $templates->setvar('role_infor', $role_infor);
            }
            else
            {
                $objrolesstatusservice->save($id, $_POST['statuses']);
                
                $templates->setvar('save_success', true);
            }
        }
    break;
}





//show template
$templates->show('rolemanagement.tpl');
?>