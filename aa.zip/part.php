<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objlaborsparts = new dblabors_parts();

//requets parameter
$page = request_var('page', '1');
$description = request_var('description', '');
$item_number = request_var('item_number', '');
$id = request_var('id', '');
$unit_cost = request_var('unit_cost', '');
$tech_mark_up = request_var('tech_mark_up', '');
$customer_mark_up = request_var('customer_mark_up', '');
$submit = request_var('submit', '');
$recalculate = request_var('recalculate', '');

switch ($mode)
{
    case "view":
        //get all labors
        $where_clause = " 1 = 1 AND type = 2";
        if ($description)
            $where_clause .= " AND description like '%$description%'";
        if ($item_number)
            $where_clause .= " AND item_number like '%$item_number%'";
        
        $labors = array();
        $labors_tmp = $objlaborsparts->get_labors_parts($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', ''), request_var('sortby', 'asc') );
        foreach ($labors_tmp as $labor)
        {
            $labor['tech_mark_up'] = $labor['tech_mark_up'] / 100;
            $tech_price = $labor['unit_cost'] + ($labor['tech_mark_up'] * $labor['unit_cost']);
            $labor['tech_price'] = $tech_price;
            $labor['customer_mark_up'] = $labor['customer_mark_up'] / 100;
            $customer_price = $labor['unit_cost'] + ($labor['customer_mark_up'] * $labor['unit_cost']);
            $labor['customer_price'] = $customer_price;
            
            $labors[] = $labor;
        }
        $itemcount = $objlaborsparts->get_labors_parts($where_clause, 0, 0, '', '', true);
        $templates->setvar('labors', $labors);
        
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "details":
        if ($id)
        {
            //get labor information
            $labor_infor = $objlaborsparts->get_labor_part_by_id($id);
            
            $labor_infor['customer_mark_up'] = $labor_infor['customer_mark_up'] / 100;
            $customer_price = $labor_infor['unit_cost'] + ($labor_infor['unit_cost'] * $labor_infor['customer_mark_up']);
            $labor_infor['customer_price'] = $customer_price;
            
            $labor_infor['tech_mark_up'] = $labor_infor['tech_mark_up'] / 100;
            $tech_price = $labor_infor['unit_cost'] + ($labor_infor['unit_cost'] * $labor_infor['tech_mark_up']);
            $labor_infor['tech_price'] = $tech_price;
            
            $templates->setvar('labor_infor', $labor_infor);          
        }
    break;

    case "delete":
        if ($id)
        {
            //delete labor
            $objlaborsparts->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {
            //get labor information
            $labor_infor = $objlaborsparts->get_labor_part_by_id($id);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $labor_infor['customer_mark_up'] = $labor_infor['customer_mark_up'] / 100;
                $customer_price = $labor_infor['unit_cost'] + ($labor_infor['unit_cost'] * $labor_infor['customer_mark_up']);
                $labor_infor['customer_price'] = $customer_price;
                
                $labor_infor['tech_mark_up'] = $labor_infor['tech_mark_up'] / 100;
                $tech_price = $labor_infor['unit_cost'] + ($labor_infor['unit_cost'] * $labor_infor['tech_mark_up']);
                $labor_infor['tech_price'] = $tech_price;
                
                $templates->setvar('labor_infor', $labor_infor);               
            }
            else
            {
                if ($recalculate)
                {
                    $save_labor = array('item_number' => $item_number,
                                        'description' => $description,
                                        'unit_cost' => $unit_cost,
                                        'tech_mark_up' => $tech_mark_up,
                                        'customer_mark_up' => $customer_mark_up);
                    
                    $customer_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['customer_mark_up']);
                    $save_labor['customer_price'] = $customer_price;
                    
                    $tech_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['tech_mark_up']);
                    $save_labor['tech_price'] = $tech_price;
                    
                    $templates->setvar('labor_infor', $save_labor);                      
                }
                else if ($submit)
                {
                    $validator = true;
                
                    if (trim($item_number) == '')
                    {
                        $validator = false;
                        $templates->setvar('error_item_number', $lang['E_ITEM_NUMBER']);
                    }
                    else
                    {                    
                        $labors = $objlaborsparts->get_labors_parts("item_number = '$item_number' AND item_number <> '".$labor_infor['item_number']."'", 0, 0);
                        if ($labors)
                        {
                            $validator = false;
                            $templates->setvar('error_item_number', $item_number);
                        }
                    }
                    if ($unit_cost && !is_numeric($unit_cost) || $unit_cost < 0)
                    {
                        $validator = false;
                        $templates->setvar('error_unit_cost', $lang['E_UNIT_COST']);
                    }
                    if ($tech_mark_up && !is_numeric($tech_mark_up) || $tech_mark_up < 0)
                    {
                        $validator = false;
                        $templates->setvar('error_tech_mark_up', $lang['E_TECH_MARK_UP']);
                    }
                    if ($customer_mark_up && !is_numeric($customer_mark_up) || $customer_mark_up < 0)
                    {
                        $validator = false;
                        $templates->setvar('error_customer_mark_up', $lang['E_CUSTOMER_MARK_UP']);
                    }
                    
                    $save_labor = array('item_number' => $item_number,
                                        'description' => $description,
                                        'unit_cost' => $unit_cost,
                                        'tech_mark_up' => $tech_mark_up,
                                        'customer_mark_up' => $customer_mark_up);
                    
                    if ($validator)
                    {
                        $save_labor['tech_mark_up'] = $save_labor['tech_mark_up'] * 100;
                        $save_labor['customer_mark_up'] = $save_labor['customer_mark_up'] * 100;
                        
                        $objlaborsparts->save('UPDATE', $save_labor, " labor_part_id = $id");
                        
                        $templates->setvar('save_success', true);
                    }
                    else
                    {
                        $customer_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['customer_mark_up']);
                        $save_labor['customer_price'] = $customer_price;
                        
                        $tech_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['tech_mark_up']);
                        $save_labor['tech_price'] = $tech_price;
                        
                        $templates->setvar('labor_infor', $save_labor);  
                    }
                }
            }
        }
    break;
    
    case "add":        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            if ($recalculate)
            {
                $save_labor = array('item_number' => $item_number,
                                    'description' => $description,
                                    'unit_cost' => $unit_cost,
                                    'tech_mark_up' => $tech_mark_up,
                                    'customer_mark_up' => $customer_mark_up,
                                    'type' => 2,
                                    'is_availabled' => 1);
                
                $customer_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['customer_mark_up']);
                $save_labor['customer_price'] = $customer_price;
                
                $tech_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['tech_mark_up']);
                $save_labor['tech_price'] = $tech_price;
                
                $templates->setvar('labor_infor', $save_labor);  
            }
            else if ($submit)
            {
                $validator = true;
                
                if (trim($item_number) == '')
                {
                    $validator = false;
                    $templates->setvar('error_item_number', $lang['E_ITEM_NUMBER']);
                }
                else
                {
                    $labors = $objlaborsparts->get_labors_parts("item_number = '$item_number'", 0, 0);
                    if ($labors)
                    {
                        $validator = false;
                         $templates->setvar('error_item_number', $item_number);
                    }
                }
                if ($unit_cost && !is_numeric($unit_cost) || $unit_cost < 0)
                {
                    $validator = false;
                    $templates->setvar('error_unit_cost', $lang['E_UNIT_COST']);
                }
                if ($tech_mark_up && !is_numeric($tech_mark_up) || $tech_mark_up < 0)
                {
                    $validator = false;
                    $templates->setvar('error_tech_mark_up', $lang['E_TECH_MARK_UP']);
                }
                if ($customer_mark_up && !is_numeric($customer_mark_up) || $customer_mark_up < 0)
                {
                    $validator = false;
                    $templates->setvar('error_customer_mark_up', $lang['E_CUSTOMER_MARK_UP']);
                }
                
                $save_labor = array('item_number' => $item_number,
                                    'description' => $description,
                                    'unit_cost' => $unit_cost,
                                    'tech_mark_up' => $tech_mark_up,
                                    'customer_mark_up' => $customer_mark_up,
                                    'type' => 2,
                                    'is_availabled' => 1);
                
                if ($validator)
                {
                    $save_labor['tech_mark_up'] = $save_labor['tech_mark_up'] * 100;
                    $save_labor['customer_mark_up'] = $save_labor['customer_mark_up'] * 100;
                    
                    $objlaborsparts->save('INSERT', $save_labor);
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $customer_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['customer_mark_up']);
                    $save_labor['customer_price'] = $customer_price;
                    
                    $tech_price = $save_labor['unit_cost'] + ($save_labor['unit_cost'] * $save_labor['tech_mark_up']);
                    $save_labor['tech_price'] = $tech_price;
                    
                    $templates->setvar('labor_infor', $save_labor);  
                }
            }
        }
    break;
}



//show template
$templates->show('part.tpl');
?>