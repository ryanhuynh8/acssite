<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');



$objtickets = new dbtickets();
$jobstatusinfo = new dbjobstatus();
$objticketsequipments = new dbticketsequipments();
$objcustomers = new dbcustomers();
$objproblem = new dbproblem();

$myticketid = request_var('ticketid', '');
$equipment_id = request_var('equipment_id', '');

if (!isset($myticketid) || !isnumeric($myticketid) )
    redirect('dashboard.php');

if ($mode == 'delete_equipment' && $equipment_id)
{
    $objticketsequipments->delete_ticketsequipments($equipment_id);
}


$ticketinfo = $objtickets->get_ticket_by_id($myticketid);

//if ticket completed then redirect to details page, don't allow user change everything
//if ($ticketinfo['status_service_id'] == 3 || $ticketinfo['status_service_id'] == 12)
    //redirect('ticketsadmin.php?ticketid=' . $ticketinfo['ticket_id']);

$job_ticket = array('promised_date' => $ticketinfo["promised_date"],
                    'promised_time_from' => $ticketinfo["promised_time_from"],
                    'promised_time_to' => $ticketinfo["promised_time_to"],
                    'job_status' => $ticketinfo["job_status"],
                    'field_notes' => $ticketinfo["field_notes"]);

$seller = $objuser->get_user_by_id($ticketinfo['seller']);
$ticketinfo['seller'] = $seller['first_name'] . ' ' . $seller['last_name'];

$jobstatus = $jobstatusinfo->get_jobstatus("", 0, null);
$Where_ticketsequipments=" 1 and ticket_id =$myticketid";
$ticketsequipmentsinfo = $objticketsequipments->get_ticketsequipments("$Where_ticketsequipments", 0, null);

//define object class


//requets parameter

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $job_date = request_var('job_date', '');
    $job_time_in = request_var('job_time_in', '');
    $job_time_out = request_var('job_time_out', '');
    $field_notes = request_var('field_notes', '');
    $validator_error = true;
    if (trim($job_date) && !is_valid_date($job_date) )
    {
        if('000-00-0' != $job_date ){
            $templates->setvar('error_job_date', $lang['E_DATE']);
            $validator_error = false;
        }
    }
    if (trim($job_time_in) && !is_valid_time_custom($job_time_in) )
    {
        $templates->setvar('error_job_time_in', $lang['E_TIME']);
        $validator_error = false;
    }
    if (trim($job_time_out) )
    {
        if (!is_valid_time_custom($job_time_out))
        {
            $templates->setvar('error_job_time_out', $lang['E_TIME']);
            $validator_error = false;
        }
        else if (trim($job_time_in) && is_valid_time_custom($job_time_in) && strtotime($job_time_in) > strtotime($job_time_out) )
        {
            $templates->setvar('error_job_time_out', $lang['E_TIME_LESS_THAN']);
            $validator_error = false;
        }
    }            
    $job_ticket = array('job_date' => convert_to_standard_date($job_date),
                        'job_time_in' => $job_time_in,
                        'job_time_out' => $job_time_out,
                        'field_notes' => $field_notes);
    //changed status to In-Process if this ticket is in Accepted status
    if ($ticketsequipmentsinfo["status_service_id"] == 15)
        $job_ticket = array_merge($job_ticket, array("status_service_id"   =>  11));
    
    if ($validator_error)
    {
        $objtickets->save('UPDATE', $job_ticket, "ticket_id = $myticketid");
        $templates->setvar('save_success', true);
    }
    
}

//get problem of ticket
$problems = $objproblem->getAllProblemsByParent();
$ticketinfo['problems'] = $objtickets->get_ticket_problems($myticketid);
$countProblems = count($objtickets->get_ticket_problems_by_parent($myticketid, 0) );

//show template
$templates->setvar("ticketsequipmentsinfo", $ticketsequipmentsinfo);
$templates->setvar("ticket_id", $myticketid);
$templates->setvar("jobstatus", $jobstatus);
$templates->setvar("job_ticket", $job_ticket);
$templates->setvar("ticketinfo", $ticketinfo);
$templates->setvar("size_problems", count($problems));
$templates->setvar("problems", $problems);
$templates->show('ticketsadmin.tpl');
?>