<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();
$objlaborsparts = new dblabors_parts();
$objbuilders = new dbbuilders();

//requets parameter
$user = request_var('user', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$payment = request_var('payment', '2');

switch ($mode)
{
    case "view":
        
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            foreach ($_POST as $key=>$value)
            {
                $hidden = substr($key, 0, 12);                
                if ($hidden == 'hidden_paid_')
                {
                    $checked = request_var("checkbox_paid_$value", '');
                    
                    $save_ticket = array('paid' => $checked ? 1 : 0,
                                         'paid_date' => $checked ? date('Y-m_d') : '' );
                    
                    $objtickets->save('UPDATE', $save_ticket, " ticket_id = $value");
                }
            }
        }
        
        get_date_month($start_date, $end_date);
        if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
        if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
        $templates->setvar('filter', array('from_date' => $from_date, 'to_date' => $to_date) );
        
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        //get all user for select
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        
        //get al tickets
        $tickets_tmp = $objtickets->get_tickets_report($user, $from_date, $to_date);        
        $tickets = array();
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $ticket)
            {
                if ($payment == 1) $paid = 1;
                elseif ($payment == 2) $paid = 0;
                else $paid = -1;                
                
                if ($ticket['paid'] == $paid || $paid == -1)
                {
                    $objtickets->get_ticket_report($ticket, $user);                    
                    $tickets[] = $ticket;
                }
            }
        }
        
        
        $templates->setvar('tickets', $tickets);
    break;
}

//show template
$templates->show('processinvoice.tpl');
?>