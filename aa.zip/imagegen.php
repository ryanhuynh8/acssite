<?php
header('content-type: image/jpeg');    
$file = $_GET['src'];
$char = $_GET['character'];
$relative = $_GET['relative'];
$currentdir = dirname(__FILE__);

$file = $currentdir . '/' .urldecode($file);	

	if (!file_exists($file))
	{
		echo "don't have file";
		return;
	}
	
	$info = getimagesize($file);
	
				$info = array(
	            	'width'  => $info[0],
	            	'height' => $info[1],
	            	'bits'   => $info['bits'],
	            	'mime'   => $info['mime']
	        	);  
	
	  
	$mime = $info['mime'];
			
	$image =  imagecreatefrompng($file);
    imagecolortransparent($image);
	$dest_x = $info["width"] - 20;    
	$dest_y = $info["height"] - 23;  
	  
	//imagecopymerge($image, $watermark, $dest_x, $dest_y, 0, 0, $watermark_width, $watermark_height, 100);
	$textcolor = imagecolorallocate($image, 255, 255, 255);

	// Write the string at the top left
	imagestring($image, 2, $dest_x, $dest_y, $char, $textcolor);
	imagecolortransparent($image);
	$imageinfo = pathinfo($file);
	imagealphablending($image,true); 
	imagesavealpha($image,true); 
		
	$extension = strtolower($imageinfo['extension']);
	   
	imagepng($image);
	
	imagedestroy($image);    
 
?> 