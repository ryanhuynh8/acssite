<?php

require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global, $actionsPermission;

//define object class
$objticketstatus = new dbticketstatus();
$objcitypermitticket = new dbcitypermittickets();

//requets parameter
$ticketid = request_var('ticketid', '');
$ticket_status = request_var('ticket_status', '');

switch($mode)
{
    //---------------Accept Open------------------------------------------------    
    case 'accept':
        if ($ticketid)
        {
            $objcitypermitticket->change_status(15, $ticketid);
            redirect(get_page());
        }
    break;
    
    case 'unaccepted':
        if ($ticketid)
        {
            $objcitypermitticket->change_status(2, $ticketid);
            redirect(get_page());
        }
    break;

    case 'claim':
        if ($ticketid)
        {
            $objcitypermitticket->change_status(12, $ticketid);
            
        }    
    break;
}


$ticketstatus = $objticketstatus->get_ticketstatus("", 0, null);


$currentDate = date('Y-m-d');    
//get oppen ticket in today
$Where_Open = " 1 AND t.status_service_id = 2 AND promised_date = '$currentDate' ";
if (!in_array('see all records', $actionsPermission) )
    $Where_Open .= " AND (t.assign_by=" . $authenticate->get_user_id() . " OR t.seller=" . $authenticate->get_user_id() . ")";

$ticketOpeninfo = $objcitypermitticket->get_tickets_dashboard("$Where_Open", 0, 0, request_var('sortfield', 'promised_time_from'), request_var('sortby', 'asc') );

//end oppen ticket in today


$tomorrow = date('Y-m-d', time() + 24*60*60);
//get oppen ticket in tomorrow
$WhereOpenTomorrow = " 1 AND t.status_service_id = 2 AND promised_date = '$tomorrow' ";
if (!in_array('see all records', $actionsPermission) )
    $WhereOpenTomorrow .= " AND (t.assign_by=" . $authenticate->get_user_id() . " OR t.seller=" . $authenticate->get_user_id() . ")";

$ticketOpenTomorrow = $objcitypermitticket->get_tickets_dashboard("$WhereOpenTomorrow", 0, 0, request_var('sortfield', 'promised_time_from'), request_var('sortby', 'asc') );

//end oppen ticket in tomorrow


//get accept ticket
$Where_Accept = " 1 and t.status_service_id = 15 ";
if (!in_array('see all records', $actionsPermission) )
    $Where_Accept .= " AND (t.assign_by=" . $authenticate->get_user_id() . " OR t.seller=" . $authenticate->get_user_id() . ")";
    
$ticketAcceptinfo = $objcitypermitticket->get_tickets_dashboard("$Where_Accept", 0, 0, request_var('sortfield', 'promised_time_from'), request_var('sortby', 'asc') );

//get accept ticket

//get inprocess ticket
$Where_Pending = " 1 and t.status_service_id = 11 ";
if (!in_array('see all records', $actionsPermission) )
    $Where_Pending .= " AND (t.assign_by=" . $authenticate->get_user_id() . " OR t.seller=" . $authenticate->get_user_id() . ")";

$ticketPendinginfo = $objcitypermitticket->get_tickets_dashboard("$Where_Pending", 0, 0, request_var('sortfield', 'promised_time_from'), request_var('sortby', 'asc') );

//end pending ticket

//get completed ticket
$Where_Completed = " 1 and t.status_service_id = 3 ";
if (!in_array('see all records', $actionsPermission) )
    $Where_Completed .= " AND (t.assign_by=" . $authenticate->get_user_id() . " OR t.seller=" . $authenticate->get_user_id() . ")";

$ticketCompletedinfo = $objcitypermitticket->get_tickets_dashboard("$Where_Completed", 0, 0, request_var('sortfield', 'complete_date'), request_var('sortby', 'desc') );

//end completed ticket   
    
//show template
$templates->setvar("ticketstatus", $ticketstatus);
//$templates->setvar("ticketOpenTomorrow", $ticketOpenTomorrow);
//$templates->setvar("dateTomorrow", time() + 24*60*60);
//$templates->setvar("ticketOpeninfo", $ticketOpeninfo);
//$templates->setvar("ticketAcceptinfo", $ticketAcceptinfo);
//$templates->setvar("ticketPendinginfo", $ticketPendinginfo);
//$templates->setvar("ticketClaiminfo", $ticketClaiminfo);
$templates->setvar("ticketCompletedinfo", $ticketCompletedinfo);

$templates->show('citypermitdashboard.tpl');
?>