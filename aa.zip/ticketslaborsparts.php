<?php
require_once("includes/common.php");

global $templates, $config, $authenticate, $lang;

if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');

//define object class
$objtickets = new dbtickets();
$objlaborsparts = new dblabors_parts();
$objinventory = new dbinventory();
$objPurchasedItems = new dbpurchaseditems();
$objPurchasedOder = new dbpurchasedorder();

//requets parameter
$ticket_id = request_var('ticketid', '');
$part_id = request_var('partid', '');
$ticket_part_id = request_var('ticket_part_id', '');
$payment_method = request_var('payment_method', '');
$payment_type = request_var('payment_type', '');
$authoried_amount = request_var('authoried_amount', '');
$installation_charge = request_var('installation_charge', '');
$complete = request_var('complete_x', '');
$pending = request_var('pending_x', '');
$save = request_var('save_x', '');
$payment_amount = request_var('payment_amount', '');
$check_number = request_var('check_number', '');
$coupon_code = request_var('coupon_code', '');
$tax_price = request_var('tax_price', '');
$quantity = request_var('quantity', '');
$price = request_var('price', '');
$agree = request_var('agree', '');
$card_security_code = request_var('card_security_code', '');
$tax_included = request_var('tax_included', 0);

switch ($mode)
{
    case 'delete':
        if ($ticket_part_id)
        {

            //update quantity in inventory
            //get ticket part information
            $ticket_part = $objtickets->get_ticket_part_by_id($ticket_part_id);
            //Helpers::varDump($ticket_part);
            $new_quantity = $ticket_part['quantity'];

            $purchaseItem = $objPurchasedItems->get_item_by_id($ticket_part['purchased_item_id']);
            if(!empty($purchaseItem))
            $purchaseOder = $objPurchasedOder->get_order_by_id($purchaseItem['purchased_order_id']);

            if(!empty($purchaseOder) && $purchaseOder['vendor_id']==139) // if acs
                $objinventory->update_quantity_warehourse($new_quantity, $ticket_part['labor_part_id']);
            else
            {
                if($ticket_part['purchased_item_id'] == ''): // if PO was created by commit action
                    $user_tech_ids=$objtickets->get_user_tech_by_ticket_id($ticket_id);
                    $user_tech_id =$user_tech_ids['user_id'];
                    $objinventory->subtract_quantity_of_user($ticket_part['user_id'], $ticket_part['labor_part_id'], $new_quantity);
                endif;
            }

            $objorderitem = new dbpurchaseditems();
            $purchased_item_id = $ticket_part['purchased_item_id'];
            $objorderitem->delete($purchased_item_id);

            $objtickets->delete_ticket_part($ticket_part_id);
        }
        break;

    case 'tax_included' :
        if ($ticket_id)
        {
            $save_ticket = array('tax_included' => $tax_included);

            $objtickets->save('UPDATE', $save_ticket, "ticket_id = $ticket_id");
        }

        exit();
        break;
}


//get ticket information
$ticketinfo = $objtickets->get_ticket_by_id($ticket_id);

//if ticket completed then redirect to details page, don't allow user change everything
if ($ticketinfo['status_service_id'] == 3 || $ticketinfo['status_service_id'] == 12)
{
    redirect('ticketsadmin.php?ticketid=' . $ticketinfo['ticket_id']);
}

$seller = $objuser->get_user_by_id($ticketinfo['seller']);
$ticketinfo['seller'] = $seller['first_name'] . ' ' . $seller['last_name'];

//get all parts
$parts_tmp = $objlaborsparts->get_labors_parts_by_ticket($ticket_id);
$parts = array();
//price total parts
$ticketinfo['labor_price'] = 0;
$ticketinfo['part_price'] = 0;
if ($parts_tmp)
{
    foreach ($parts_tmp as $part)
    {
        if ($part['type'] == 1)
            $ticketinfo['labor_price'] += $part['price'] * $part['quantity'];
        if ($part['type'] == 2)
            $ticketinfo['part_price'] += $part['price'] * $part['quantity'];

        $part['ext_price'] = $part['price'] * $part['quantity'];
        $parts[] = $part;
    }
}
$ticketinfo['sub_price'] = $ticketinfo['labor_price'] + $ticketinfo['part_price'];

$assign = $objtickets->get_userid_by_ticketid($ticket_id);
$templates->setvar('assign',$assign);

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    //validator
    $error_validator = true;


    if (!is_numeric($authoried_amount) || floatval($authoried_amount) < 0)
    {
        $error_validator = false;
        $templates->setvar('error_complete', $lang['E_AUTHORIED_AMOUNT']);
    }
    elseif (!is_numeric($installation_charge) || floatval($installation_charge) < 0)
    {
        $error_validator = false;
        $templates->setvar('error_complete', $lang['E_INSTALLATION_CHARGE']);
    }
    //end validator

    //update labor or parts
    if ($save && $ticket_part_id)
    {
        //check validator
        $error_validator = true;
        //remove check quantity
        $ticket_part = $objtickets->get_ticket_part_by_id($ticket_part_id);
        $quantity = $ticket_part['quantity'];
        //$quantity=0;
        if (trim($quantity) == '')
        {
            $error_validator = false;
            $templates->setvar('error_complete', $lang['E_QUANTITY']);
        }
        elseif (!is_numeric($quantity) || floatval($quantity) < 0)
        {
            $error_validator = false;
            $templates->setvar('error_complete', $lang['E_QUANTITY_NUMBERIC']);
        }
        elseif (trim($price) == '')
        {
            $error_validator = false;
            $templates->setvar('error_complete', $lang['E_PRICE']);
        }
        elseif (!is_numeric($price) || floatval($price) < 0)
        {
            $error_validator = false;
            $templates->setvar('error_complete', $lang['E_PRICE_NUMBERIC']);
        }
        else
        {
            //validator quantity
            //get ticket part information
            $ticket_part = $objtickets->get_ticket_part_by_id($ticket_part_id);
            $part_infor = $objlaborsparts->get_labor_part_by_id($ticket_part['labor_part_id']);
            if ($part_infor['type'] == 2)
            {
                $inventory_quantity = $objinventory->get_quantity_in_inventory($ticket_part['user_id'], $ticket_part['labor_part_id']);
                if ($quantity > $inventory_quantity + $ticket_part['quantity'])
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_SELECT_QUANTITY']);
                }
            }
        }


        $save_ticket_part = array('quantity' => $quantity,
            'price' => $price);
        if ($error_validator)
        {
            //update quantity in inventory
            //get ticket part information
            $ticket_part = $objtickets->get_ticket_part_by_id($ticket_part_id);
            $old_quantity = $ticket_part['quantity'];
            $new_quantity = $old_quantity - $quantity;
            $objinventory->subtract_quantity_of_user($ticket_part['user_id'], $ticket_part['labor_part_id'], $new_quantity);
            //end update quantity in inventory
            //delete inventory if it is zero
            $objinventory->delete_inventory_zero();

            //update quantity and price labor or parts            
            $objtickets->update_ticket_part('UPDATE', $save_ticket_part, "ticket_part_id = $ticket_part_id");

            redirect(get_page() . "?ticketid=$ticket_id");
        }
        else
        {
            $templates->setvar('labor_part_infor', $save_ticket_part);
        }
    }
    //pending button click
    elseif ($pending)
    {
        $save_ticket = array('status_service_id' => 9);



        $objtickets->save('UPDATE', $save_ticket, "ticket_id = $ticket_id");

        //update paid full
        $objtickets->UpdatePaidFullTicket($ticket_id);

        $templates->setvar('save_success', true);

        //send email warning quatity to technician
        $objinventory->email_warning_quantity();
    }
    //comple button click
    elseif ($complete)
    {
        if($error_validator)
        {
            if (!$agree)
            {
                $error_validator = false;
                $templates->setvar('error_complete', $lang['E_AGREE']);
            }
            if ($payment_method == 'cash')
            {
                //check cash paymnet
                if (trim($payment_amount) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CASH_AMOUNT']);
                }
                elseif (!is_numeric($payment_amount) || floatval($payment_amount) < 0)
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CASH_AMOUNT_NUMBERIC']);
                }
                elseif ($payment_amount > $authoried_amount)
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CASH_AMOUNT_LESS_THAN']);
                }
            }
            elseif ($payment_method == 'check')
            {
                //check payment
                if (trim($payment_amount) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CHECK_AMOUNT']);
                }
                elseif (!is_numeric($payment_amount) || floatval($payment_amount) < 0)
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CHECK_AMOUNT_NUMBERIC']);
                }
                elseif (trim($check_number) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CHECK_NUMBER']);
                }
                elseif ($payment_amount > $authoried_amount)
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CHECK_AMOUNT_LESS_THAN']);
                }
            }
            elseif ($payment_method == 'credit_card')
            {
                //credit card payment
                if (trim($payment_amount) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CARD_AMOUNT']);
                }
                elseif (!is_numeric($payment_amount) || floatval($payment_amount) < 0)
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CARD_AMOUNT_NUMERIC']);
                }
                elseif (trim($card_security_code) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CARD_CODE']);
                }
                elseif (trim(strlen($card_security_code) ) != 4 || !ctype_digit($card_security_code) )
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CARD_CODE_LENGTH']);
                }
                elseif ($payment_amount > $authoried_amount)
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_CARD_AMOUNT_LESS_THAN']);
                }
            }
            elseif ($payment_method == 'coupon')
            {
                if (trim($coupon_code) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_complete', $lang['E_COUPON_CODE']);
                }
            }
        }

        $save_ticket = array('status' => 3,
            'status_service_id' => 3,
            'complete_date' => date('Y-m-d H:i:s'),
            'payment_method' => $payment_method,
            'payment_type' => $payment_type,
            'payment_amount' => $payment_amount,
            'check_number' => $check_number,
            'coupon_code' => $coupon_code,
            'card_security_code' => $card_security_code,
            'authoried_amount' => $authoried_amount,
            'installation_charge' => $installation_charge);

        if ($error_validator)
        {

            $objtickets->save('UPDATE', $save_ticket, "ticket_id = $ticket_id");

            //update paid full
            $objtickets->UpdatePaidFullTicket($ticket_id);

            $templates->setvar('save_success', true);

            //send email warning quatity to technician
            $objinventory->email_warning_quantity();
        }
        else
        {
            $ticketinfo['payment_method'] =  $save_ticket['payment_method'];
            $ticketinfo['payment_type'] =  $save_ticket['payment_type'];
            $ticketinfo['payment_amount'] =  $save_ticket['payment_amount'];
            $ticketinfo['check_number'] =  $save_ticket['check_number'];
            $ticketinfo['coupon_code'] =  $save_ticket['coupon_code'];
            $ticketinfo['card_security_code'] =  $save_ticket['card_security_code'];
            $ticketinfo['authoried_amount'] =  $save_ticket['authoried_amount'];
            $ticketinfo['installation_charge'] =  $save_ticket['installation_charge'];
        }
    }
    //on blur authorized and installation charge
    else
    {
        $save_ticket = array('authoried_amount' => $authoried_amount,
            'installation_charge' => $installation_charge,
            'payment_method' => $payment_method,
            'payment_type' => $payment_type,
            'card_security_code' => $card_security_code);

        if ($payment_amount != '')
            $save_ticket['payment_amount'] = $payment_amount;
        if ($check_number != '')
            $save_ticket['check_number'] = $check_number;
        if ($coupon_code != '')
            $save_ticket['coupon_code'] = $coupon_code;

        if ($error_validator)
        {


            $objtickets->save('UPDATE', $save_ticket, "ticket_id = $ticket_id");

            //update paid full
            $objtickets->UpdatePaidFullTicket($ticket_id);

            redirect(get_page() . "?ticketid=$ticket_id");
        }
        else
        {
            $ticketinfo['payment_method'] =  $save_ticket['payment_method'];
            $ticketinfo['payment_type'] =  $save_ticket['payment_type'];
            $ticketinfo['payment_amount'] =  $save_ticket['payment_amount'];
            $ticketinfo['check_number'] =  $save_ticket['check_number'];
            $ticketinfo['coupon_code'] =  $save_ticket['coupon_code'];
            $ticketinfo['card_security_code'] =  $save_ticket['card_security_code'];
            $ticketinfo['authoried_amount'] =  $save_ticket['authoried_amount'];
            $ticketinfo['installation_charge'] =  $save_ticket['installation_charge'];
        }
    }


}
$ticketinfo['tax_price_hidden'] = number_format($ticketinfo['part_price'] * $tax, 2, '.', '');
if ($ticketinfo['tax_included'])
    $tax = 0;
$ticketinfo['tax_price'] = number_format($ticketinfo['part_price'] * $tax, 2, '.', '');
$ticketinfo['total_price'] = number_format($ticketinfo['tax_price'] + $ticketinfo['sub_price'], 2, '.', '');
$ticketinfo['additional_charge'] = number_format($ticketinfo['authoried_amount'] - $ticketinfo['installation_charge'] - $ticketinfo['total_price'], 2, '.', '');

switch ($mode)
{
    case 'change_amount':
        if ($ticket_id)
        {
            $save_ticket = array('authoried_amount' => $ticketinfo['installation_charge'] + $ticketinfo['total_price']);



            $objtickets->save('UPDATE', $save_ticket, " ticket_id = $ticket_id");

            //update paid full
            $objtickets->UpdatePaidFullTicket($ticket_id);

            redirect(get_page() . "?ticketid=$ticket_id");
        }
        break;
}


//show template
$templates->setvar("parts", $parts);
$templates->setvar("ticketinfo", $ticketinfo);
$templates->show('ticketslaborsparts.tpl');



?>