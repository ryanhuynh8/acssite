<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objuser = new dbuser();

//requets parameter
$email = request_var('email', '');



if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $error_validator = true;
    if (trim($email) == '')
    {
        $error_validator = false;
        $templates->setvar('error_email', $lang['E_EMAIL']);
    }
    else
    {
        if (!is_valid_email($email))
        {
            $error_validator = false;
            $templates->setvar('error_email', $lang['E_INVALID_EMAIL']);
        }
        else
        {
            $user = $objuser->get_user_by_email($email);
            if (!$user)
            {
                $error_validator = false;
                $templates->setvar('error_email', $lang['E_EMAIL_NOT_EXISTS']);
            }
        }
    }
    
    if ($error_validator)
    {
        $password = generatePassword(5, 3);
        $save_user = array("password" => md5($password) );
        $objuser->save("UPDATE", $save_user, "email = '$email'");
        
        //send email
        $user_infor = $objuser->get_user_by_email($email);
        $param_arr = array("EMAIL"	=>	$user_infor['email'],
                            "NAME"	=>	$user_infor['first_name'] . ' ' . $user_infor['last_name'],
                            "PASSWORD"   =>      $password,
                            "URL" => $base_url
                            );
        notified_email(3, $param_arr, '', $email);
                
        $templates->setvar("save_successed", true);
    }
}


//show template
$templates->show('forgotpassword.tpl');
?>