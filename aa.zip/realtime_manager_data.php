<?php
require_once("includes/common.php");
@ini_set('display_errors', 'Off');
//error_reporting(E_ALL);
global $templates, $config, $authenticate, $lang, $user_global, $actionsPermission;

$objrealtime = new dbrealtime();

$mode       = request_var('mode', 'view');
$sortfield  = request_var('sortfield', '');
$sortby     = request_var('sortby', '');
$myuserID   = $authenticate->get_user_id();
$bsys       = request_var('bsys', '1');

$whereBsys = " and rb.board_system=".$bsys;
if ($bsys == 4) {
    $whereBsys = " and (rb.board_system=1 or rb.board_system=3)";
}


switch ($mode)
{
    case 'view' :
        $where_pending = " 1 = 1".$whereBsys;
        $where_pending .=" AND (rb.status = 1)";
        $realtimelist = $objrealtime->get_realtime($where_pending, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby);

        $pending_total =count($realtimelist);

        $where_inprocess = " 1 = 1 ".$whereBsys;
        if (!in_array('see all records', $actionsPermission) )
            $where_inprocess .= " AND ((rb.status = 3) AND rb.userID =".$myuserID.")";
        else
            $where_inprocess .= " AND (rb.status = 3)";
        $realinprocess = $objrealtime->get_realtime($where_inprocess, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby);
        $inprogress_total= count($realinprocess);
        $templates->setvar("realinprocess", $realinprocess);


        $templates->setvar("pending_total", $pending_total);
        $templates->setvar("inprogress_total", $inprogress_total);
        $templates->setvar("realtimelist", $realtimelist);
    break;

    case 'load_markers' :
        $whereClause  = " 1 = 1 ".$whereBsys;
        $whereClause .= " AND (rb.status = 1)";
        $realtimelist = $objrealtime->get_realtime($whereClause, 0, 0, $sortfield, $sortby);
        //echo $objrealtime->sql;
        $tickets = array();
        if ($realtimelist)
        {
            foreach ($realtimelist as $entry)
            {
                $record = array();
                $record['address'] = $entry['address'] . ',' . $entry['city'] . ',' . $entry['state'] . ' ' . $entry['zipcode'];
                $record['point'] = $record['map_point'] ? $record['map_point'] : getMapPoint($record['address'], $entry['id'], 2);
                $record['icon'] = 'http://maps.google.com/intl/en_us/mapfiles/ms/micons/red-dot.png';
                $record['address'] = $entry['address'] . ', ' . $entry['city'] . ', ' . $entry['state'] . ' ' . $entry['zipcode'];
                $record['phone'] = $entry['phone'];
                $record['name'] = $entry['customer_name'];

                $contentHtml = '';
                $contentHtml .= '<table width="100%" border="0" cellpadding="2" cellspacing="0">';
                $contentHtml .= "<tr><td><b>Dispatch No.:</b></td><td>{$entry['dispatchID']}</td></tr>";
                $contentHtml .= "<tr><td><b>Customer:</b></td><td>{$record['name']}</td></tr>";
                $contentHtml .= "<tr><td><b>Phone:</b></td><td>{$record['phone']}</td></tr>";
                $contentHtml .= "<tr><td><b>Address:</b></td><td>{$record['address']}</td></tr>";
                $contentHtml .= '</table>';
                $record['content'] = $contentHtml;

                $tickets[] = $record;
            }
        }

        echo json_encode($tickets);

        exit();
    break;

}

$templates->show('realtime_manager_data.tpl');
   
   
?>