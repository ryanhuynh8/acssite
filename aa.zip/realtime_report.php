<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
//requets parameter
$page = request_var('page', '1');
$sortfield = request_var('sortfield', 'time_received');
$sortby = request_var('sortby', 'DESC');
$recieved_date = request_var('recieved_date', '');
$complete_date = request_var('complete_date', '');
$type = request_var('type', '');
$status = request_var('status', '');
$cus_name = request_var('cus_name', '');
$address = request_var('address', '');
$objrealtime = new dbrealtime();
switch ($mode)
{
    case "view":
        $where_clause = " 1 = 1 ";
        if ($type)
            $where_clause .= " AND board_system = $type";
        if ($status)
            $where_clause .= " AND status = $status";
        if ($cus_name)
            $where_clause .= " AND customer_name like '%$cus_name%'";
        if ($address)
            $where_clause .= " AND address like '%$address%'";   
       
            $realtimelist = $objrealtime->get_realtime($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby);
       
        $itemcount =  $objrealtime->get_realtime($where_clause, 0, 0, '', '', true);
        $templates->setvar('realtimelist', $realtimelist);
        
        //paging
            $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
       
     break;
}           
//show template
$templates->setvar("reportmenu", "tab_on");
$templates->show('realtime_report.tpl');
?>