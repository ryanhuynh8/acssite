<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objorder = new dbpurchasedorder();
$objlaborsparts = new dblabors_parts();
$objinventory = new dbinventory();
$objpurchaseditem = new dbpurchaseditems();
$objvendors = new dbvendors();
$objcustomers = new dbcustomers();
$objticket = new dbtickets();
$objuser = new dbuser();
//requets parameter
$tab = request_var('tab', '');
$id = request_var('id', '');
$part_id = request_var('part_id', '');
$item_number = request_var('item_number', '');
$description = request_var('description', '');
$search_item_number = request_var('search_item_number', '');
$search_description = request_var('search_description', '');
$search_part = request_var('search_part', '');
$uom = request_var('uom', '');
$price = request_var('price', '');
$quantity = request_var('quantity', '');
$user = request_var('user', '');
$vendor = request_var('vendor', '');
$approved =request_var('approved','');
$notes = request_var('notes', '');
$est_received_date = request_var('est_received_date','');
//var_dump($est_received_date);
$purchased_by = request_var('purchased_by','');
$purchased =request_var('purchased','');
$stt = request_var('status','');
$service_ticket = request_var('serviceticket','');
$invoice_service_tech =request_var('invoice_service','');

$page_manage =request_var('page_manage','');
$invoice =request_var('invoice','');
$received_date = request_var('received_date', '');
$quantity_received = request_var('quantity_received', '');
$page = request_var('page', 1);
$order_number = request_var('order_number', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$date_est_received_from= request_var('date_est_received_from','');
$date_est_received_to = request_var('date_est_received_to','');
$date_order_from = request_var('date_order_from','');
$date_order_to = request_var('date_order_to','');
$search = request_var('search', '');
$clear = request_var('clear', '');
$search_name = request_var('search_name', '');
$search_invoice = request_var('search_invoice','');
//if ($_SERVER['REQUEST_METHOD'] == "POST")
switch ($mode)
{
    case 'view';

        $_SESSION['selfURL'] = selfURL();

        get_date_month($start_date, $end_date);
        get_date_month($start_received_date,$end_received_date);
        get_date_month($start_est_received_date,$end_est_received_date);

        //if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
        // if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
        if (!$from_date) $from_date = null;
        if (!$date_order_from) $date_order_from = date('m/d/Y', strtotime($start_date) );
        if (!$date_order_to) $date_order_to = date('m/d/Y', strtotime($end_date) );

        if (!$date_est_received_from) $date_est_received_from = date('m/d/Y', strtotime($start_date) );
        if (!$date_est_received_to) $date_est_received_to = date('m/d/Y', strtotime($end_date) );

        $filter = array('from_date' => $from_date, 'to_date' => $to_date,
            'date_order_from'=>$date_order_from,'date_order_to'=>$date_order_to,
            'date_est_received_from'=>$date_est_received_from,'date_est_received_to'=>$date_est_received_to);
        $templates->setvar('filter', $filter);

        //get all users for select
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        $status =  $objuser->get_status();
        $templates->setvar('status_po',$status);

        $vendors = $objvendors->get_vendors('', 0, 0, 'name');
        $templates->setvar('vendors', $vendors);
        $user_id=$authenticate->get_user_id();
        $templates->setvar('user_id',$user_id);
        $user_global = $objuser->get_user_by_id($authenticate->get_user_id());
        $templates->setvar("currentrole", $user_global['role_id']);
        if($tab==""){
            if($user_global['role_id']==30){
                $tab='receiving';
            }else{
                $tab="tech";
            }
        }


        switch($tab)
        {
            case 'tech';$templates->setvar("managermenu1", "tab_on");$type ="L";break;
            case 'warehouse';$templates->setvar("managermenu2", "tab_on");$type ="P";break;
            case 'receiving';$templates->setvar("managermenu3", "tab_on");$type ="P";break;
        }

        $templates->setvar('tab',$tab);
        // $order_number= str_replace ("#","",$order_number);

        //get all orders in grid view
        $where_clause = ' 1 = 1';
        $where_clause .= $item_number ? " AND po.item_number like '%". $item_number ."%'" : "";
        $where_clause .= $order_number ? " AND CONCAT(po.type,'0000',po.purchased_order_id) like '%". $order_number . "%'" : "";
        $where_clause .= $user ? " AND po.user_id = ". $user : "";

        $where_clause .= $approved ? " AND po.approved_by_id = ". $approved: "";
        $where_clause .= $purchased ? " AND po.purchased_by_id = ". $purchased: "";
        if ($tab=='tech'){
            $where_clause .= $type ? " AND (po.type = '". $type ."' OR po.type ='S')"  : "";
        }else
            $where_clause .= $type ? " AND po.type = '". $type ."'" : "";
        //var_dump($where_clause);
        $where_clause .= $stt ? "AND po.status_id = '". $stt ."'" : "";

        $where_clause .= "AND (2 = 2 ";
        $where_clause .= $from_date ? " AND po.received_date >= '". convert_to_standard_date($from_date) ."'" : "";
        $where_clause .= $to_date ? " AND po.received_date <= '". convert_to_standard_date($to_date) ."'" : "";
        if($tab !='tech'){
            $where_clause .= $date_order_from ? " AND po.order_date >= '". convert_to_standard_date($date_order_from) ."'" : "";
            $where_clause .= $date_order_to ? " AND po.order_date <= '". convert_to_standard_date($date_order_to) ."'" : "";

            $where_clause .= $date_est_received_from ? " AND po.est_received_date >= '". convert_to_standard_date($date_est_received_from) ."'" : "";
            $where_clause .= $date_est_received_to ? " AND po.est_received_date <= '". convert_to_standard_date($date_est_received_to) ."'" : "";
        }

        if(($search)!=null){
            $where_clause .=") ";
        }else{
            $where_clause .= " OR po.received_date is NULL OR po.received_date ='0000-00-00' OR po.order_date is NULL OR po.order_date ='0000-00-00' OR po.est_received_date is NULL OR po.est_received_date ='0000-00-00')";
        }
        // delano
        if($tab=='receiving'){
            $orders = $objorder->get_orders($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'status_id,est_received_date'), request_var('sortby', 'asc'));
        }else{
            $orders = $objorder->get_orders($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'purchased_order_id'), request_var('sortby', 'desc') );
        }
        //echo $objorder->sql;

        $itemcount = $objorder->get_orders($where_clause, 0, 0, '', '', true);
        $templates->setvar('total_po', $objlaborsparts->get_summary_po($where_clause));
        $templates->setvar('orders', $orders);
        // var_dump($orders);
        //echo $objorder->sql;
        //var_dump($itemcount);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        break;

    case 'edit'; //caseedit
        if ($id)
        {
            $invoice_po_arr = $objticket->get_invoice_by_purchased_id($id);
            $invoice_po=$invoice_po_arr['invoice_number'];
            // delano
            $purchaseOder = $objorder->get_order_by_id($id);
            //
            $po_parts_tmp = $objpurchaseditem->get_items_by_order($id);
            $po_parts = array();
            $total_part="";
            foreach ($po_parts_tmp as $entry)
            {
                $entry['unit_cost'] = $entry['price'];
                $po_parts[] = $entry;
                $total_part+=$entry['price']*$entry['quantity'];
            }

            $total_part_receiving="";
            foreach ($po_parts_tmp as $entry)
            {
                $entry['unit_cost'] = $entry['price'];
                $total_part_receiving+=$entry['price']*$entry['quantity_received'];
            }
            if ($_SERVER['REQUEST_METHOD'] == "GET")
            {
                $_SESSION['po_parts'] = $po_parts;
            }


            //get all users for select purchased By
            $users = $objuser->get_users('', 0, 0, 'name');
            $templates->setvar('users', $users);
            // delano purchased by
            $templates->setvar('purchased_by_id',$purchaseOder['purchased_by_id']);




            $templates->setvar('tab',$tab);
            $templates->setvar('mode',$mode);
            $status =  $objuser->get_status();
            $templates->setvar('status_po',$status);

            $vendors = $objvendors->get_vendors('', 0, 0, 'full_name');
            $templates->setvar('vendors', $vendors);
            $templates->setvar('received_date',date('m/d/Y'));

            //get all part no labor
            $where_clause = " 1 AND type = 2";
            $parts = $objlaborsparts->get_labors_parts($where_clause, 0, 0, 'description');
            $templates->setvar('parts', $parts);

            $order_infor = $objorder->get_order_by_id($id);

            $received_date_edit = date('m/d/Y', strtotime(str_replace('-', '/', $order_infor['received_date'])));
            $templates->setvar('received_date',$received_date_edit);
            $est = date('m/d/Y', strtotime(str_replace('-', '/', $order_infor['est_received_date'])));
            //var_dump($est);
            $templates->setvar('est_received_date',$est);
            if($order_infor['notes']!=null)
            {
                if(substr($order_infor['notes'],0,9)!="&lt;span&")
                {
                    if(!strpos($order_infor['notes'], "span")){
                        $note_update = '<span>' . '[Undefined datetime]:'. '</span><div>' . $order_infor['notes'] . '</div>';
                        $order_infor['notes']=$note_update;
                        $objorder->save('UPDATE', $order_infor, " purchased_order_id = $id");
                    }
                }

            }
            // $order_infor['est_received_date'] = date('m/d/Y', strtotime(str_replace('-', '/', $order_infor['est_received_date'])));
            //$order_infor['est_received_date'] =1;
            $templates->setvar('order_infor', $order_infor);

            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {

            }
            else
            {
                $error_validator = true;

                if (trim($user) == '' && $tab=='tech')
                {
                    $error_validator = false;
                    $templates->setvar('error_user', $lang['E_USER']);
                }
                if (trim($vendor) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_vendor', $lang['E_VENDOR']);
                }
//                if (trim($approved) == '')
//                {
//                    $error_validator = false;
//                    $templates->setvar('error_approved', $lang['E_APPROVED']);
//
//                }
                $note = request_var('note', '');

                if (trim($notes) != '')
                    $note .= '<span>' . date('m/d/Y h:i A') .':'. '</span><div>' . $notes . '</div>';

                if($stt==3){
                    $received_date = date('Y-m-d');//received_date
                }else
                    $received_date = convert_to_standard_date(request_var('received_date', ''));
                $est_received_date=convert_to_standard_date($est_received_date) ;

                if($tab=='tech'){
                    $save_order = array('item_number' => $item_number,
                        'user_id'=>$user,
                        'notes' => $note,
                        'vendor_id'=>$vendor,
                        'approved_by_id'=>$approved,
                        'est_received_date'=>($est_received_date),
                        'invoice_number'=>$invoice,
                        'status_id'=>$stt);
                }else{
                    $save_order = array('item_number' => $item_number,
                        'user_id'=>$user,
                        'notes' => $note,
                        'vendor_id'=>$vendor,
                        'approved_by_id'=>$approved,
                        'purchased_by_id'=>$purchased_by,
                        'received_date'=>$received_date,//received_date
                        'est_received_date'=>($est_received_date),
                        'invoice_number'=>$invoice,
                        'status_id'=>$stt);
                }
                //var_dump($save_order);
                $error_quantity = array();
                $i=0;
                foreach ($_POST['quantity'] as $key=>$value)
                {

                    if (trim($value) == '')
                    {

                        $error_validator = false;
                        $error_quantity[$key] = $lang['E_QUANTITY'];
                    }
                    elseif (!ctype_digit($value) || floatval($value) <0)
                    {

                        $error_validator = false;
                        $error_quantity[$key] = $lang['E_QUANTITY_NUMERIC'];
                    }

                    else
                    {

                        if(($vendor==139 && $tab=='tech')|| $tab !='tech')
                        {

                            $po_parts = $_SESSION['po_parts'];
                            $id_labor=$po_parts [$i]['labor_part_id'];
                            $partInfo = $objlaborsparts->get_labor_part_by_id($id_labor);
                            $i++;
                            // var_dump($po_parts);
                            foreach ($po_parts as $entry)//array new quantity
                            {
                                if($entry['labor_part_id'] ==$key)//if same labor id
                                {
                                    $ql=$_POST['quantity'][$key]-$entry['quantity'];// new- old quantity
                                    if($partInfo['quantity_on_hand']<$ql){
                                        // delano edit
                                        if($tab != 'warehouse'):
                                            $error_validator = false;
                                            $error_quantity[$key] = $lang['E_QUANTITY_WAREHOUSE'];
                                        endif;
                                    }
                                }
                            }
                        }
                    }
                }
                $ticketid = $objticket->get_ticket_id_by_invoice2($invoice);
                $assign = $objticket->get_userid_by_ticketid($ticketid);
                $load_to_user =$objuser->get_username_by_id($user);
                $assign_user= $objuser->get_username_by_id($assign);
                if($ticketid){
                    if(!$assign){
                        $error_validator = false;
                        $error_invoice ="This PO can't be linked with invoice $invoice since invoice $invoice is not assigned to $load_to_user";
                        $templates->setvar('error_invoice',$error_invoice);
                    }elseif($assign!=$user)
                    {
                        $error_validator = false;
                        $error_invoice ="This PO can't be linked with invoice $invoice since invoice $invoice is assigned to $assign_user";
                        $templates->setvar('error_invoice',$error_invoice);
                    }
                }

                $templates->setvar('error_quantity', $error_quantity);
                if ($error_validator)
                {

                    $objorder->save('UPDATE', $save_order, " purchased_order_id = $id");
                    $objpurchaseditem->deleteByOrder($id);
                    $po_parts = $_SESSION['po_parts'];



                    foreach ($po_parts as $entry)
                    {
                        $quantity_part_received =$_POST['quantity_received'][$entry['labor_part_id']];
                        $item = array(
                            'purchased_order_id' => $id,
                            'labor_part_id' => $entry['labor_part_id'],
                            'item_number' => $entry['item_number'],
                            'description' => $entry['description'],
                            'uom' => $entry['uom'],
                            'price' => $_POST['price'][$entry['labor_part_id']],
                            'quantity' => $_POST['quantity'][$entry['labor_part_id']],
                            'quantity_received' => $quantity_part_received
                        );

                        $ticket_id=($objticket->get_ticket_id_by_invoice($invoice));
                        $ticketid=$ticket_id[ticket_id];
                        $quantity_part =$_POST['quantity'][$entry['labor_part_id']];
                        $labor_part_id_part=$entry['labor_part_id'];
                        $part_infor = $objlaborsparts->get_labor_part_by_id($entry['labor_part_id']);
                        $customer_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['customer_mark_up'] / 100);
                        $tech_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100);
                        $save_ticket_part = array('ticket_id' => $ticketid,
                            'user_id' => $user,
                            'labor_part_id' => $labor_part_id_part,
                            'quantity' => $quantity_part,
                            'quantity_received' => $quantity_part_received,
                            'price' => $customer_price,
                            'tech_price' => $tech_price,
                            'created_date' => date('Y-m-d') );
                        if(($vendor==139 && $tab=='tech')|| $tab !='tech')
                        {
                            if($stt == '3' && ($tab == 'warehouse' || $tab == 'receiving')){
                                foreach ($_POST['quantity_received'] as $key=>$value)//array new quantity
                                {
                                    if($entry['labor_part_id'] ==$key)//if same labor id
                                    {//var_dump($_POST['quantity'][$key]);
                                        //var_dump($entry['quantity']);
                                        $whql=$_POST['quantity_received'][$key];
                                        // delano edit
                                        $objinventory->update_quantity_warehourse($whql, $entry['labor_part_id']);
                                    }
                                }
                            }
                            else
                                foreach ($_POST['quantity'] as $key=>$value)//array new quantity
                                {
                                    if($entry['labor_part_id'] ==$key)//if same labor id
                                    {//var_dump($_POST['quantity'][$key]);
                                        //var_dump($entry['quantity']);
                                        $ql=$_POST['quantity'][$key]-$entry['quantity'];// new- old quantity
                                        $whql=$_POST['quantity'][$key];
                                        // delano edit
                                        $objinventory->update_quantity_warehourse(-$ql, $entry['labor_part_id']);
                                    }
                                }
                        }
                        if($tab=='tech')
                        {
                            foreach ($_POST['quantity'] as $key=>$value)//array new quantity
                            {
                                if($entry['labor_part_id'] ==$key)//if same labor id
                                {
                                    if($save_order['invoice_number'])//check exits invoice number or not
                                    {
                                        $ql=$_POST['quantity'][$key]-$entry['quantity'];// new- old quantity

                                        if($invoice==$invoice_po){//check change invoice po when edit or not
                                            //insert part into service ticket
                                            //don't change invoice
                                            $ticket_id=($objticket->get_ticket_id_by_invoice($invoice));
                                            $ticketid=$ticket_id[ticket_id];
                                            $part_exists = $objticket->get_ticket_part_exists($user, $ticketid, $labor_part_id_part);
                                            $part_track_exists =$objticket->get_track_ticket_part_exits($invoice,$entry['labor_part_id']);


                                            if ($part_exists)
                                                $objticket->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] + $ql),
                                                    ' ticket_part_id=' . $part_exists['ticket_part_id']);
                                            elseif($part_track_exists){
                                                //var_dump($part_track_exists);
                                                $where_clause = " 1 AND i.labor_part_id = ". $entry['labor_part_id'] ." and i.user_id = " . $user;
                                                $inventories = $objinventory->get_inventories($where_clause, 0, 0);
                                                $inventory = $inventories[0];

                                                $quantity_inventory = $_POST['quantity'][$key]-$part_track_exists['quantity'] + $inventory['quantity'];
                                                $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);
                                                $objticket->update_track_ticket($_POST['quantity'][$key],$invoice,$entry['labor_part_id']);



                                            }else
                                                $objticket->update_ticket_part('INSERT', $save_ticket_part);
                                        }else{//change po
                                            // add part to new service/invoice
                                            $ticket_id=($objticket->get_ticket_id_by_invoice($invoice));

                                            $ticketid=$ticket_id[ticket_id];
                                            $part_exists = $objticket->get_ticket_part_exists($user, $ticketid, $labor_part_id_part);

                                            if ($part_exists)
                                                $objticket->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] + $_POST['quantity'][$key]),
                                                    ' ticket_part_id=' . $part_exists['ticket_part_id']);
                                            else
                                                $objticket->update_ticket_part('INSERT', $save_ticket_part);
                                            //delete part in old invoice
                                            $ticket_id_po=($objticket->get_ticket_id_by_invoice($invoice_po));
                                            $ticketid_po=$ticket_id_po[ticket_id];
                                            $part_exists_po = $objticket->get_ticket_part_exists($user, $ticketid_po, $labor_part_id_part);
                                            if ($part_exists_po){
                                                $objticket->update_ticket_part('UPDATE', array('quantity' => $part_exists_po['quantity'] - $_POST['quantity'][$key]),
                                                    ' ticket_part_id=' . $part_exists_po['ticket_part_id']);
                                                $objticket->delete_quantity_zero();
                                            }
                                        }
                                    }
                                }else{

                                }
                            }

                        }

                        $objpurchaseditem->save('INSERT', $item);
                    }
                    //delete popart session


                    foreach($po_parts_tmp as $tmp)
                    {
                        $flag=0;
                        foreach($po_parts as $v)//compare session po part with po part in db
                        {
                            if ($tmp['labor_part_id']==$v['labor_part_id']) {//if popart session exist in db
                                //$flag.="1".$tmp['item_number']." ".$tmp['quantity']." ";
                                $flag=1;

                            }else{

                            }

                        }
                        if($flag!=0){

                        }else{//po part session is delete

                            $where_clause = " 1 AND i.labor_part_id = ". $tmp['labor_part_id'] ." and i.user_id = " . $user;
                            $inventories = $objinventory->get_inventories($where_clause, 0, 0);
                            $inventory = $inventories[0];
                            $quantity_inventory = $inventory['quantity']-$tmp['quantity'];
                            if($save_order['invoice_number']==0){

                                $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);
                                $objinventory->delete_inventory_zero();
                            }
                            if(($vendor==139 && $tab=='tech')|| $tab !='tech')
                            {
                                $objinventory->update_quantity_warehourse($tmp['quantity'], $tmp['labor_part_id']);
                            }
                            //delete part into service ticket
                            if($tab=='tech'){
                                $ticket_id=($objticket->get_ticket_id_by_invoice($invoice));
                                $ticketid=$ticket_id[ticket_id];
                                $part_exists = $objticket->get_ticket_part_exists($user, $ticketid, $tmp['labor_part_id']);
                                $part_track_exists =$objticket->get_track_ticket_part_exits($invoice,$tmp['labor_part_id']);

                                if ($part_exists){
                                    $objticket->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] - $tmp['quantity']),
                                        ' ticket_part_id=' . $part_exists['ticket_part_id']);
                                    $objticket->delete_quantity_zero();
                                }
                                elseif($part_track_exists){
                                    //var_dump($part_track_exists);

                                    $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);
                                    $objinventory->delete_track_part_by_labor($invoice,$tmp['labor_part_id']);



                                }else
                                    $objticket->update_ticket_part('INSERT', $save_ticket_part);
                            }
                        }
                    }


                    foreach ($_POST['quantity'] as $key=>$value)//array new quantity
                    {
                        $where_clause = " 1 AND i.labor_part_id = ". $key ." and i.user_id = " . $user;
                        $inventories = $objinventory->get_inventories($where_clause, 0, 0);
                        $inventory = $inventories[0];

                        if($invoice==0){
                            if ($inventory)// if isset inventory true -> update
                            {
                                $add =0;
                                foreach($po_parts as $entry){
                                    if($entry['labor_part_id']==$key){
                                        $add=$_POST['quantity'][$key]-$entry['quantity'];

                                    }
                                }

                                $quantity_inventory = $add + $inventory['quantity'];
                                $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);
                                $objinventory->delete_inventory_zero();
                            }
                            else// if isset inventory false -> add
                            {

                                $save_inventory = array('user_id' => $user,
                                    'labor_part_id' => $key,
                                    'quantity' => $_POST['quantity'][$key],
                                    'actived_date' => date('Y-m-d') );

                                $objinventory->save('INSERT', $save_inventory);

                            }
                        }elseif($order_infor['invoice_number'] ==0){

                            $quantity_away = $inventory['quantity']-$_POST['quantity'][$key];
                            $objinventory->save('UPDATE', array('quantity' => $quantity_away, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);

                        }
                    }

                    $templates->setvar('save_success', true);
                }
                else
                {

                    $save_order['purchased_order_id']=$id;
                    $templates->setvar('order_infor', $save_order);

                }
            }
            $templates->setvar('total_part', $total_part);
            $templates->setvar('total_part_receiving', $total_part_receiving);

            $templates->setvar('po_parts', $_SESSION['po_parts']);
        }
        break;

    case 'add'; // caseadd
        if ($_SERVER['REQUEST_METHOD'] == "GET")
        {
            $_SESSION['po_parts'] = null;
        }

        $search = request_var('search', '');
        $save = request_var('save', '');
        $templates->setvar('tab',$tab);
        $templates->setvar('mode',$mode);
//get all users for select purchased By
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        $status =  $objuser->get_status();
        $templates->setvar('status_po',$status);

        $templates->setvar('purchased_by_id',$authenticate->get_user_id());
        $templates->setvar('received_date',date('m/d/Y'));
        $vendors = $objvendors->get_vendors('', 0, 0, 'full_name');
        $templates->setvar('vendors', $vendors);
//get all part no labor
        $where_clause = " 1 AND type = 2";
        $parts = $objlaborsparts->get_labors_parts($where_clause, 0, 0, 'description');
        $templates->setvar('parts', $parts);
        $invoice_service = $objticket->get_invoice_by_ticket_id2($service_ticket);
        $templates->setvar('invoice_service',$invoice_service);
        $templates->setvar('serviceticket',$service_ticket);
//get last order
        $orders = $objorder->get_orders('', 0, 0, 'purchased_order_id', 'desc');
        $order_infor = $orders[0];
        $templates->setvar('order_number', $order_infor['purchased_order_id'] + 1);
        if($tab=="tech"){
            $type_po ="L";
            if($service_ticket)
                $type_po="S";
        }else{
            $type_po="P";
        }

        $templates->setvar('type_po',$type_po);
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            if ($save!='')
            {
                $error_validator = true;

                if (trim($user) == '' && $tab =='tech')
                {
                    $error_validator = false;
                    $templates->setvar('error_user', $lang['E_USER']);
                }
                if (trim($vendor) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_vendor', $lang['E_VENDOR']);
                }
//                if (trim($approved) == '')
//                {
//                    $error_validator = false;
//                    $templates->setvar('error_approved', $lang['E_APPROVED']);
//
//                }
                if (trim($est_received_date) == ''&& $tab!='tech')
                {
                    $error_validator = false;
                    $templates->setvar('error_est_received_date', $lang['E_EST_RECEIVED_DATE']);

                }
                $note = request_var('note', '');
                if (trim($notes) != '')
                    $note .= '<span>' . date('m/d/Y h:i A') .':'. '</span><div>' . $notes . '</div>';
                $po_parts = $_SESSION['po_parts'];
                $price=0;
                $quantity_po=0;


                foreach ($po_parts as $entry){
                    $price= $price+ $entry['unit_cost']*$_POST['quantity'][$entry['labor_part_id']];
                    $quantity_po=$quantity_po+$_POST['quantity'][$entry['labor_part_id']];

                }
                if($tab=='tech')
                {
                    $received_date=date('Y-m-d');
                }elseif($stt==3){
                    $received_date = date('Y-m-d');//received_date
                }
                //var_dump($invoice_service_tech);
                //die();

                if($invoice_service_tech){
                    $pending=1;
                    $invoice =$invoice_service_tech;
                    // var_dump($service_ticket);
                }else $pending =0;
                if($invoice && $tab=='tech'){
                    $type_po = "S";
                }

                $save_order = array('type'=>$type_po,
                    'user_id' => $user,
                    'price'=>$price,
                    'quantity'=>$quantity_po,
                    'received_date'=>$received_date,
                    'est_received_date'=>convert_to_standard_date($est_received_date),
                    'notes' => $note,
                    'vendor_id'=>$vendor,
                    'approved_by_id'=>$approved,
                    'purchased_by_id'=>$purchased_by,
                    'order_date'=>date('Y-m-d'),//received_date
                    'status_id'=>$stt,
                    'invoice_number'=>$invoice,
                    'pending'=>$pending);
                //add validator for quantity

                $error_quantity = array();
                $i=0;
                foreach ($_POST['quantity'] as $key=>$value)
                {

                    if (trim($value) == '')
                    {

                        $error_validator = false;
                        $error_quantity[$key] = $lang['E_QUANTITY'];
                    }
                    elseif (!ctype_digit($value) || floatval($value) <0)
                    {

                        $error_validator = false;
                        $error_quantity[$key] = $lang['E_QUANTITY_NUMERIC'];
                    }

                    else
                    {

                        //if($vendor==139 && $tab=='tech')
                        if(($vendor==139 && $tab=='tech')|| $tab !='tech')
                        {
                            $parts = $_SESSION['po_parts'];
                            $id_labor=$parts[$i]['labor_part_id'];
                            $i++;
                            $partInfo = $objlaborsparts->get_labor_part_by_id($id_labor);
                            // delano add
                            if($partInfo['quantity_on_hand']<$value)
                            {
                                if($tab != 'warehouse'):
                                    $error_validator = false;
                                    $error_quantity[$key] = $lang['E_QUANTITY_WAREHOUSE'];
                                endif;

                            }else{

                            }
                        }
                    }
                }
                $ticketid = (int)$objticket->get_ticket_id_by_invoice2($invoice);
                $assign = (int)$objticket->get_userid_by_ticketid($ticketid);
                $load_to_user =$objuser->get_username_by_id($user);
                $assign_user= $objuser->get_username_by_id($assign);

                if(0<$ticketid){
                    if($assign<=0){
                        $error_validator = false;
                        $error_invoice ="This PO can't be linked with invoice $invoice since invoice $invoice is not assigned to $load_to_user";
                        $templates->setvar('error_invoice',$error_invoice);
                    }elseif($assign!=(int)$user)
                    {
                        $error_validator = false;
                        $error_invoice ="This PO can't be linked with invoice $invoice since invoice $invoice is assigned to $assign_user";
                        $templates->setvar('error_invoice',$error_invoice);
                    }

                }
                //die();
                $templates->setvar('error_quantity', $error_quantity);


                if ($error_validator)
                {
                    //insert order
                    $orderId = $objorder->save('INSERT', $save_order);

                    //insert order details
                    $po_parts = $_SESSION['po_parts'];

                    foreach ($po_parts as $entry)
                    {
                        $item = array(
                            'purchased_order_id' => $orderId,
                            'labor_part_id' => $entry['labor_part_id'],
                            'item_number' => $entry['item_number'],
                            'description' => $entry['description'],
                            'uom' => $entry['uom'],
                            'price' => $_POST['price'][$entry['labor_part_id']],
                            'quantity' => $_POST['quantity'][$entry['labor_part_id']],
                        );
                        $ticket_id=($objticket->get_ticket_id_by_invoice($invoice));
                        $ticketid=$ticket_id[ticket_id];
                        $quantity_part =$_POST['quantity'][$entry['labor_part_id']];
                        $labor_part_id_part=$entry['labor_part_id'];
                        $part_infor = $objlaborsparts->get_labor_part_by_id($entry['labor_part_id']);
                        $customer_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['customer_mark_up'] / 100);
                        $tech_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100);
                        $save_ticket_part = array('ticket_id' => $ticketid,
                            'user_id' => $user,
                            'labor_part_id' => $labor_part_id_part,
                            'quantity' => $quantity_part,
                            'price' => $customer_price,
                            'tech_price' => $tech_price,
                            'created_date' => date('Y-m-d') );

                        if(($vendor==139 && $tab=='tech' && $pending==0)|| $tab !='tech')
                        {
                            // delano add
                            if($tab != 'warehouse')
                                $objinventory->update_quantity_warehourse(-$_POST['quantity'][$entry['labor_part_id']], $entry['labor_part_id']);
                        }
                        if($tab=='tech' && $pending==0){
                            $ticket_id=($objticket->get_ticket_id_by_invoice($invoice));
                            $ticketid=$ticket_id[ticket_id];
                            $part_exists = $objticket->get_ticket_part_exists($user, $ticketid, $labor_part_id_part);

                            if ($part_exists)
                                $objticket->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] + $quantity_part),
                                    ' ticket_part_id=' . $part_exists['ticket_part_id']);
                            else
                                $objticket->update_ticket_part('INSERT', $save_ticket_part);
                        }

                        $objpurchaseditem->save('INSERT', $item);// insert item into po
                    }

                    //add code change invetory here
                    foreach ($_POST['quantity'] as $key=>$value)//array new quantity
                    {
                        $where_clause = " 1 AND i.labor_part_id = ". $key ." and i.user_id = " . $user;
                        $inventories = $objinventory->get_inventories($where_clause, 0, 0);
                        $inventory = $inventories[0];


                        if(($invoice ==0 || $invoice == '')&& $tab=='tech' && !isset($_GET['serviceticket']) ) {

                            if ($inventory)// if isset inventory true -> update
                            {
                                $quantity_inventory = $_POST['quantity'][$key] + $inventory['quantity'];
                                $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);

                            }
                            else// if isset inventory false -> add
                            {

                                $save_inventory = array('user_id' => $user,
                                    'labor_part_id' => $key,
                                    'quantity' => $_POST['quantity'][$key],
                                    'actived_date' => date('Y-m-d') );

                                $objinventory->save('INSERT', $save_inventory);

                            }
                        }
                    }



                    if($service_ticket){
                        redirect('createtickets.php?mode=manage_po&id='.$service_ticket);
                    }
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $save_order['search_part'] = $search_part;

                    if($save_order['est_received_date'])
                        $save_order['est_received_date'] = date('m/d/Y', strtotime(str_replace('-', '/', $save_order['est_received_date'])));
                    $templates->setvar('order_infor', $save_order);
                    $templates->setvar('quantity_number',$_POST['quantity']);
                    $templates->setvar('invoice_search',$invoice);

                }
            }
        }
// save quantity when error
        $array_popart =array();
        $total_part=0;

        foreach($_SESSION['po_parts'] as $key=>$value){


            foreach ($_POST['quantity'] as $key2=>$value2){

                if($value['labor_part_id']==$key2){

                    $value['quantity']=$value2;
                    $total_part+=$value['quantity']*$value['unit_cost'];
                }
            }array_push($array_popart,$value);

        }
// $templates->setvar('po_parts', $_SESSION['po_parts']);

        $templates->setvar('total_part',$total_part);
        $templates->setvar('po_parts',$array_popart);
        break;

    case 'add_part':
        $parts = isset($_SESSION['po_parts']) ? $_SESSION['po_parts'] : array();
        $partInfo = $objlaborsparts->get_labor_part_by_id($part_id);

        if ($partInfo)
            $parts[] = $partInfo;

        $_SESSION['po_parts'] = $parts;

        $html = '';
        $html .= '<tr>';
        $html .= "<td>{$partInfo['item_number']}</td>";
        $html .= "<td>{$partInfo['description']}</td>";
        $html .= "<td>{$partInfo['uom']}</td>";
        $html .= "<td><input  class ='price' name='price[{$partInfo['labor_part_id']}]' type='text' value='{$partInfo['unit_cost']}' style='width:60px' onkeyup='total()'/></td>";
        $html .= "<td><input  class ='quantity' name='quantity[{$partInfo['labor_part_id']}]' type='text' value='1' style='width:30px' onkeyup='total()'/>";
        $html .= '<td align="center"><a href="'. get_page() .'?mode=delete_part&part_id='. $partInfo['labor_part_id'] .'" class="po_delete"><img src="'.$templates->template->template_dir.'/images/delete.png" align="absmiddle" alt="Delete" title="Delete" /></a></td>';
        $html .= '</tr>';

        echo $html;

        exit();
        break;


    case 'delete_part':
        $parts = $_SESSION['po_parts'];
        $results = array();
        foreach ($parts as $entry)
        {
            if ($entry['labor_part_id'] != $part_id)
                $results[] = $entry;
        }

        $_SESSION['po_parts'] = $results;

        exit();
        break;

    case 'search_parts':
        $where_clause = " 1 AND type = 2 ";
        $where_clause .= $search_item_number ? " AND item_number like '%$search_item_number%' " : "";
        $where_clause .= $search_description ? " AND description like '%$search_description%' " : "";
        $parts = $objlaborsparts->get_labors_parts($where_clause, 0, 0, 'description');

        $html = '<option value="">--Select One--</option>';
        foreach ($parts as $entry)
            $html .= "<option value='{$entry['labor_part_id']}'>{$entry['item_number']} - {$entry['description']}</option>";

        echo $html;
        exit();
        break;
    case "get_customers" :
        $whereClause = ' 1 ';
        $whereClause .= $search_name ? " AND c.full_name like \"%$search_name%\" " : '';
        $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
        //echo $objcustomers->sql;

        $html = '<select id="customer" name="customer" class="select" style="width:100%" onchange="get_information_customer(this)">';
        $html .= '<option value="">'. $lang['L_SELECT_A_CUSTOMER_NAME'] .'</option>';

        if ($customers)
        {
            foreach ($customers as $customer)
            {
                $html .= '<option value="'. $customer['customer_id'] .'">'.
                    truncate_text($customer['full_name'], 50) . ' ('. $customer['address'] . ', ' . $customer['city'] . ', ' . $customer['state'] . ', ' . $customer['phone1'] .')' .
                    '</option>';
            }
        }

        $html .= '</select>';
        echo $html;
        return;
        break;
    case "get_information_customer":
        $customer_id = request_var('customer_id', '');

        if ($customer_id)
        {
            $invoices = $objcustomers->get_name_invoice($customer_id);
        }else{
            $invoices = $objcustomers->search_invoice_by_name($search_invoice);
        }
        // $customer = $objcustomers->get_customer_by_id($customer_id);
        //$problem = $objcustomers->get_problem_name()

        $html = '<select id="invoice" name="invoice" class="select" style="width:100%" >';
        $html .= '<option value="">'. $lang['L_SELECT_INVOICE'] .'</option>';
        if ($invoices)
        {
            foreach ($invoices as $invoice)
            {
                //if(!$objorder->check_invoice_exist($invoice['invoice_number'])){
                $html .= '<option value="'. $invoice['invoice_number'] .'">'.
                    truncate_text($invoice['invoice_number'], 30) . ' ('.  date('m/d/Y', strtotime($invoice['created_date'])) .')' .
                    '</option>';
                //}
            }
        }
        $html .= '</select>';
        echo $html;

        return;

        break;

    case 'details';
        if ($id)
        {
            $templates->setvar('tab',$tab);

            //$order_infor = $objorder->get_order_by_id($id);
            $order_infor=$objorder->get_name_order_by_id($id);
            if($order_infor['notes']!=null)
            {
                if(substr($order_infor['notes'],0,9)!="&lt;span&")
                {
                    if(!strpos($order_infor['notes'], "span")){
                        $note_update = '<span>' . '[Undefined datetime]:'. '</span><div>' . $order_infor['notes'] . '</div>';
                        $order_infor['notes']=$note_update;
                        $objorder->save('UPDATE', $order_infor, " purchased_order_id = $id");
                    }
                }

            }


            $po_parts = $objpurchaseditem->get_items_by_order($id);


            $total_part="";
            $total_part_receiving="";

            foreach ($po_parts as $entry)
            {
                $entry['unit_cost'] = $entry['price'];
                $total_part_receiving+=$entry['price']*$entry['quantity_received'];
            }
            foreach ($po_parts as $entry)
            {
                $entry['unit_cost'] = $entry['price'];
                $total_part+=$entry['price']*$entry['quantity'];
            }

            $user_infor = $objuser->get_user_by_id($order_infor['user_id']);
            if($order_infor['invoice_number']){
                $ticket_infor = $objticket->get_ticket_by_invoice($order_infor['invoice_number']);
                $templates->setvar('ticket_infor',$ticket_infor);
            }
            //var_dump($ticket_infor);
            //var_dump($order_infor);
            $order_infor['name'] = $user_infor['first_name'] . ' ' . $user_infor['last_name'];
            $templates->setvar('order_infor', $order_infor);
            $templates->setvar('po_parts', $po_parts);
            $templates->setvar('total_part',$total_part);
            $templates->setvar('total_part_receiving',$total_part_receiving);

        }
        break;

    case 'received';
        if ($id)
        {
            //get all users for select purchased By
            $users = $objuser->get_users('', 0, 0, 'name');
            $templates->setvar('users', $users);
            $vendors = $objvendors->get_vendors('', 0, 0, 'name');
            $templates->setvar('vendors', $vendors);

            $order_infor = $objorder->get_order_by_id($id);

            $po_parts = $objpurchaseditem->get_items_by_order($id);

            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                $error_validator = true;

                if (trim($received_date) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_received_date', $lang['E_RECEIVED_DATE']);
                }

                $error_quantity = array();
                foreach ($_POST['quantity_received'] as $key=>$value)
                {
                    if (trim($value) == '')
                    {
                        $error_validator = false;
                        $error_quantity[$key] = $lang['E_QUANTITY'];
                    }
                    elseif (!ctype_digit($value) || floatval($value) <0)
                    {
                        $error_validator = false;
                        $error_quantity[$key] = $lang['E_QUANTITY_NUMERIC'];
                    }
                    elseif ($value > $_POST['quantity'][$key])
                    {
                        $error_validator = false;
                        $error_quantity[$key] = $lang['E_QUANTITY_RECEIVED_LEAST_THAN'];
                    }
                    else
                    {
                        $partInfo = $objlaborsparts->get_labor_part_by_id($_POST['labor_part_id'][$key]);
                        if ($value > $partInfo['quantity_on_hand'])
                        {
                            $error_validator = false;
                            $error_quantity[$key] = $lang['E_QUANTITY_WAREHOUSE'];
                        }
                    }
                }
                $templates->setvar('error_quantity', $error_quantity);

                $save_order = array('notes' => $notes,
                    'received_date' => convert_to_standard_date($received_date) );

                if ($error_validator)
                {
                    $objorder->save('UPDATE', $save_order, " purchased_order_id = $id");

                    foreach ($_POST['quantity_received'] as $key=>$value)
                    {
                        $objpurchaseditem->save('UPDATE', array('quantity_received' => $value), "purchased_item_id = $key");
                    }

                    $po_parts = $objpurchaseditem->get_items_by_order($id);


                    foreach ($po_parts as $entry)
                    {
                        $part_infor = $objlaborsparts->get_labor_part_by_id($entry['labor_part_id']);

                        if ($part_infor)
                        {
                            //if part exists, substract quantity in warehour
                            $objinventory->update_quantity_warehourse(-$entry['quantity_received'], $part_infor['labor_part_id']);

                            //add quantity into inventory of user
                            //check if inventory exists
                            $where_clause = " 1 AND i.labor_part_id = ". $part_infor['labor_part_id'] ." and i.user_id = " . $order_infor['user_id'];
                            $inventories = $objinventory->get_inventories($where_clause, 0, 0);
                            $inventory = $inventories[0];
                            if ($inventory)
                            {
                                $quantity_inventory = $entry['quantity_received'] + $inventory['quantity'];
                                $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);
                            }
                            else
                            {
                                $save_inventory = array('user_id' => $order_infor['user_id'],
                                    'labor_part_id' => $part_infor['labor_part_id'],
                                    'quantity' => $entry['quantity_received'],
                                    'actived_date' => date('Y-m-d') );

                                $objinventory->save('INSERT', $save_inventory);
                            }

                            //notify email
                            $objlaborsparts->email_warning_quantity($part_infor['labor_part_id']);
                        }
                        else
                        {
                            $save_part = array('item_number' => $order_infor['item_number'],
                                'description' => $order_infor['description'],
                                'uom' => $order_infor['uom'],
                                'unit_cost' => $order_infor['price'],
                                'type' => 2,
                                'is_availabled' => 1,
                                'posted_date' => date('Y-m-d H:i:s'),
                                'tech_mark_up' => 0,
                                'customer_mark_up' => 0,
                                'quantity_on_hand' => 0);
                            $labor_part_id = $objlaborsparts->save('INSERT', $save_part);
                            $save_inventory = array('user_id' => $order_infor['user_id'],
                                'labor_part_id' => $labor_part_id,
                                'quantity' => $entry['quantity_received'],
                                'actived_date' => date('Y-m-d') );

                            $objinventory->save('INSERT', $save_inventory);
                        }
                    }

                    $templates->setvar('save_success', true);


                }
                else
                {
                    $order_infor['notes'] = $save_order['notes'];
                    $order_infor['received_date'] = $received_date;
                }
            }

            $templates->setvar('order_infor', $order_infor);
            $templates->setvar('po_parts', $po_parts);
        }
        break;

    case 'delete';
        if ($id)
        {
            $order_infor = $objorder->get_order_by_id($id);
            $po_parts = $objpurchaseditem->get_items_by_order($id);
            $ticket_id = $objticket->get_ticket_id_by_purchased_id($id);
            foreach($po_parts as $entry)
            {
                $where_clause = " 1 AND i.labor_part_id = ".$entry['labor_part_id'] ." and i.user_id = " .$order_infor['user_id'];
                $inventories = $objinventory->get_inventories($where_clause, 0, 0);
                $inventory = $inventories[0];
                if($inventory['labor_part_id']==$entry['labor_part_id'])
                {
                    $quantity_away = $inventory['quantity']-$entry['quantity'];
                    //$objinventory->save('UPDATE', array('quantity' => $quantity_away, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);
                    if(($order_infor['vendor_id']==139&& $tab=='tech')|| $tab !='tech'){
                        // delano delete
                        if($tab == 'warehouse'){
                            $objinventory->update_quantity_warehourse(-$entry['quantity_received'], $entry['labor_part_id']);
                        }
                        else
                            $objinventory->update_quantity_warehourse($entry['quantity'], $entry['labor_part_id']);
                        $flag =1;
                    }
                }
                if($tab=='tech' ){
                    //delete part in ACS if vendor=139
                    if($order_infor['invoice_number'] &&$order_infor['pending']==0 &&$order_infor['vendor_id']==139 && $flag!=1){
                        $objinventory->update_quantity_warehourse($entry['quantity'], $entry['labor_part_id']);
                        // echo $objinventory->sql;
                        // die;
                    }
                    //delete part into service ticket

                    //$ticket_id=($objticket->get_ticket_id_by_invoice($invoice));
                    $ticketid=$ticket_id[ticket_id];
                    $part_exists = $objticket->get_ticket_part_exists($order_infor['user_id'], $ticketid, $entry['labor_part_id']);
                    //echo $objticket->sql;
                    //var_dump($part_exists);
                    $invoice_numbers = $objticket->get_invoice_by_ticket_id($ticket_id);
                    $invoice_number = $invoice_numbers['invoice_number'];
                    $part_track_exists =$objticket->get_track_ticket_part_exits($invoice_number,$entry['labor_part_id']);

                    if ($part_exists){
                        $objticket->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] - $entry['quantity']),
                            ' ticket_part_id=' . $part_exists['ticket_part_id']);
                        $objticket->delete_quantity_zero();
                    }else{
                        if ($inventory)// if isset inventory true -> update
                        {
                            $objinventory->save('UPDATE', array('quantity' => $quantity_away, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);

                            //  $quantity_inventory = $inventory['quantity']-$entry[];
                            //  $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);

                        }

                    }
                    // die();
                }

            }
            $objorder->delete($id);
            $objpurchaseditem->deleteByOrder($id);
            if($page_manage)
            {
                redirect($_SERVER['HTTP_REFERER']);
            }
            $templates->setvar('delete_success', true);
        }
        break;

    case 'lookup';
        if ($item_number)
        {
            $part_infor = $objlaborsparts->get_part_by_item_number($item_number);
            if ($part_infor)
                echo $part_infor['description'] . ';' . $part_infor['uom'] . ';' . $part_infor['unit_cost'];
        }

        return;
        break;
    case "add_note_po":
        $notes = request_var('note_po','');
        $id_po = request_var('id','');
        $order_infor = $objorder->get_order_by_id($id_po);
        if (trim($notes) != ''){

            $note .=$order_infor['notes']. '<span>' . date('m/d/Y h:i A') .':'. '</span><div>' . $notes . '</div>';
        }
        $save_order=array('notes' => $note);
        $objorder->save('UPDATE', $save_order, " purchased_order_id = $id_po");
        //echo $id_po;
        break;
    case "save_note" :
        $text = request_var('text', '');
        $save_order = array('notes' => str_replace(array('[{1}]', '[{2}]'), array('#', '&') , $text) );
        $objorder->save('UPDATE', $save_order, " purchased_order_id = $id");

        return;
        break;
}

//show template
$templates->show('po.tpl');
?>