<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;
//define object class


//requets parameter
$user_name = request_var('user_name', '');
$password = request_var('password', '');

//if authenticated will redirect to dashboard.php
if ($authenticate->get_authentication() && request_var('permission', '') != 'false' && $pages_permission)
{
    redirect($authenticate->get_first_page_permission($pages_permission) );
}

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $user_infor = $objuser->get_user_by_user_name($user_name);
    
    if (md5($password) == $user_infor['password'])
    {
        //set authentication
        $session_id = session_id();
        $user_id = $user_infor['user_id'];
        $authenticate->set_authentication($user_id, $session_id);
        //update user login
        $save_user = array('is_login' => 1,
                           'last_login_date' => date('Y-m-d H:i:s'),
                           'session_id' => $session_id);
        
        $objuser->save('UPDATE', $save_user, "user_id = $user_id");
        
        $authenticate->get_main_menu($user_infor['role_id'], 0, $pages_permission);
        
        if ($pages_permission)
            redirect($authenticate->get_first_page_permission($pages_permission) );
    }
    else
    {
        $templates->setvar('error_login', 'Invalid user name or password. Please try again.');
    }
    
}


//show template
$templates->show('index.tpl');
?>