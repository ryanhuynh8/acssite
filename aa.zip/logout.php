<?php
require_once("includes/common.php");

//update user login
$user_id = $authenticate->get_user_id();
$save_user = array('is_login' => 0,
				   'session_id' => '');

$objuser->save('UPDATE', $save_user, "user_id = $user_id");

session_destroy();
redirect("index.php");
?>