<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $tax;


//define object class
$objtickets = new dbtickets();
$objlaborsparts = new dblabors_parts();
$objbuilders = new dbbuilders();
//requets parameter
$user = $authenticate->get_user_id();
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$builder = request_var('builder', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")

switch ($mode)
{
    case "view":
        get_date_month($start_date, $end_date);
        if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
        if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
        $templates->setvar('filter', array('from_date' => $from_date, 'to_date' => $to_date) );
        
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        //get all user for select
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        
        //get allbuilder for select
        $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
        $templates->setvar('builders', $builders);
        
        $tickets_tmp = $objtickets->get_tickets_report($user, $from_date, $to_date, $builder);
        
        $tickets = array();
        $results = array();
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $ticket)
            {
                $objtickets->get_ticket_report($ticket, $user);
                
                $tickets[] = $ticket;
            }
        }
        
        $current_date = '';
        $index = 0;
        $number_commission = 0;
        $number_ticket_worked = 0;
        $summary = array();
        if ($tickets)
        {
            foreach ($tickets as $row)
            {
                $results[] = $row;
                
                $summary['authorized_amount'] += $row['authoried_amount'];
                $summary['discount'] += $row['discount'];
                $summary['gross'] += $row['gross'];
                $summary['parts_tax_amount'] += $row['parts_tax_amount'];
                $summary['labor'] += $row['labor'];
                $summary['payment_amount'] += $row['payment_amount'];
                $summary['net'] += $row['net'];
                $summary['tech_income'] += number_format($row['tech_income'], 2, '.', '');
                $summary['acs_income'] += number_format($row['acs_income'], 2, '.', '');
                if ($row['commission'] > 0)
                    $number_commission++;
                $summary['commission'] += $row['commission'];
                
                if ($row['payment_method'] == 'cash')
                    $summary['cash'] += $row['payment_amount'];
                if ($row['payment_method'] == 'check')
                    $summary['check'] += $row['payment_amount'];
                if ($row['payment_method'] == 'credit_card')
                    $summary['credit_card'] += $row['payment_amount'];
                    
                if (!$row['seller'] && $row['assign_by'] == $user || $row['seller'] == $user)
                    $number_ticket_worked++;
            }
        }
        $summary['average_cost'] = $number_ticket_worked ? $summary['authorized_amount'] / $number_ticket_worked : 0;
        $summary['commission'] = $number_commission ? $summary['commission'] / $number_commission : 0;
        $summary['cash'] = $summary['cash'] ? $summary['cash'] : 0;
        $summary['check'] = $summary['check'] ? $summary['check'] : 0;
        $summary['credit_card'] = $summary['credit_card'] ? $summary['credit_card'] : 0;
        $templates->setvar('results', $results);
        $templates->setvar('summary', $summary);
        
    break;
}


//show template
$templates->show('incomereports.tpl');
?>