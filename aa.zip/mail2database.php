<?php
error_reporting(E_ALL);
set_time_limit(0);
/*
require_once("includes/config.php");
require_once("includes/constants.php");
require_once("includes/dbl.php");
require_once("dataaccessor/dbrealtime.php");
require_once("dataaccessor/dbyahooapi.php");
include_once("includes/class.emailtodb.php");
set_time_limit(0);

$dbrealtime = new dbrealtime();
$objyahoo = new dbyahooapi();
$yahoo_info = $objyahoo->get_yahoo_api();
$php_userid = $yahoo_info['user_name'];
$php_password = $yahoo_info['password'];

$cfg["db_host"] = $db_host;
$cfg["db_user"] = $db_usser;
$cfg["db_pass"] = $db_password;
$cfg["db_name"] = $db_name;

$mysql_pconnect = mysql_pconnect($cfg["db_host"], $cfg["db_user"], $cfg["db_pass"]);
if(!$mysql_pconnect){echo "Connection Failed"; exit; }
$db = mysql_select_db($cfg["db_name"], $mysql_pconnect);
if(!$db){echo"DB Select Failed"; exit;}

$edb = new EMAIL_TO_DB();

$edb->connect('imap.mail.yahoo.com', ':993/ssl/novalidate-cert', $php_userid, $php_password);
$edb->do_action();
*/

$mysqli = new mysqli('houstondienlanh.com','acsvn2014','acsVnP@ssw0rd','asccomfort_db');
$mysqli2 = new mysqli('localhost','root','P@ssw0rd600','asccomfort_db3');
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
transferMailRealtime();
function transferMailRealtime(){
    global $mysqli, $mysqli2;
    $sql = 'SELECT * FROM `tbl_realtime` WHERE status=1';
    $query = $mysqli->query($sql);
    if($query->num_rows > 0) {
        while($row = $query->fetch_assoc()) {
            $columns = '';
            $columnsVal = '';
            foreach ($row as $key => $value){
                if($key!='id' && $key !='transfered'){
                    $columns .= ($columns=='')?$key:','.$key;
                    $columnsVal .= ($columnsVal=='')?"'".$mysqli2->real_escape_string($value)."'":",'".$mysqli2->real_escape_string($value)."'";
                }
            }
            if($columns !='' && $columnsVal!=''){
                $sql2 = "INSERT INTO tbl_realtime ($columns) VALUES ($columnsVal)";
                echo $sql2;
                if($mysqli2->query($sql2)){
                    $sql3 = "UPDATE tbl_realtime SET status=2";
                    $mysqli->query($sql3);
                }
            }
        }
    }
}
function transfer_emailtodb_email(){
    global $mysqli, $mysqli2;
    $sql = 'SELECT * FROM `emailtodb_email`';
    $query = $mysqli->query($sql);
    if($query->num_rows > 0) {
        while($row = $query->fetch_assoc()) {
            $sql2 = "INSERT into emailtodb_email (IDEmail,EmailFrom,EmailFromP,EmailTo,DateE,DateDb,DateRead,DateRe,Status,Type,Del,Subject,Message,Message_xml,MsgSize,Kind,IDre)
            VALUES ('".$row['IDEmail']."','".$row['EmailFrom']."','".$row['EmailFromP']."','".$row['EmailTo']."','".$row['DateE']."',
            '".$mysqli2->real_escape_string($row['DateDb'])."'
            ,'".$mysqli2->real_escape_string($row['DateRead'])."'
            ,'".$mysqli2->real_escape_string($row['DateRe'])."',".$row['Status'].",".$row['Type'].",'".$row['Del']."'
            ,'".$mysqli2->real_escape_string($row['Subject'])."'
            ,'".$mysqli2->real_escape_string($row['Message'])."'
            ,'".$mysqli2->real_escape_string($row['Message_xml'])."'
            ,'".$row['MsgSize']."','".$row['Kind']."','".$row['IDre']."'
            )";
            if($mysqli2->query($sql2)){
                $sql3 = "DELETE FROM emailtodb_email WHERE ID=".$row['ID'];
                $mysqli->query($sql3);
            }
        }
    }
}
function myCurl($url){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    $content = curl_exec($ch);
    curl_close($ch);
    return $content;
}
?>