<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global;
$objrealtime = new dbrealtime();
$sortfield = request_var('sortfield', '');
$sortby = request_var('sortby', '');
$mode = request_var('mode', '');
$realtime_id = request_var('id', '');
$bsys = request_var('bsys', '1');
$myuserID =$authenticate->get_user_id();
$_SESSION["cURL"]=$_SERVER['REQUEST_URI'];
if($bsys==1)
{
    $templates->setvar("L_PAGETITLE_NAME", $lang['L_H_B_TICKET']);
    $templates->setvar("managermenu1", "tab_on");
}elseif($bsys==2)
{
    $templates->setvar("L_PAGETITLE_NAME", $lang['L_M_C_TICKET']);
    $templates->setvar("managermenu2", "tab_on");
}elseif($bsys==3)
{
    $templates->setvar("L_PAGETITLE_NAME", $lang['L_S_Q_TICKET']);
    $templates->setvar("managermenu3", "tab_on");
}
elseif($bsys==4)
{
    $templates->setvar("L_PAGETITLE_NAME", $lang['L_H_B_TICKET_MAP']);
    $templates->setvar("managermenu4", "tab_on");
}
switch($mode)
{
    //---------------Accept Real Time------------------------------------------------    
    case 'accept':
        if ($realtime_id)
        {
             $parameters = array('userID' => $myuserID,
                            'status' => 3);
        	$objrealtime->save('UPDATE', $parameters, "id = $realtime_id");
        }
    break;

    case 'refuse':
        if ($realtime_id)
        {
        $parameters = array('userID' => 0,
                            'status' => 1);
        $objrealtime->save('UPDATE', $parameters, "id = $realtime_id");
		redirect('realtime_manager.php?bsys='.$bsys);
        } 
    break;
}

$templates->setvar("sortfield", $sortfield);
$templates->setvar("sortby", $sortby);

$templates->show('realtime_manager.tpl');


?>