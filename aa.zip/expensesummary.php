<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();
$objexpense = new dbexpense();
$objlaborsparts = new dblabors_parts();
$objpaymenthistory = new dbpaymenthistory();

//requets parameter
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$summary = array();

//get_date_month($start_date, $end_date);
//if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
//if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
$templates->setvar('filter', array('from_date' => $from_date, 'to_date' => $to_date) );

$from_date = convert_to_standard_date($from_date);
$to_date = convert_to_standard_date($to_date);

//------------------
//get Total Misc. Expenses:
$where_clause = '1 = 1';
$where_clause .= $from_date ? " AND e.date >= '$from_date'" : '';
$where_clause .= $to_date ? " AND e.date <= '$to_date'" : '';
//$expenses = $objexpense->get_expenses($where_clause, 0, 0);
//echo $objexpense->sql;

$total_expenses = 0;
//if ($expenses)
//{
//    foreach ($expenses as $record)
//    {
//        $total_expenses += $record['amount'];
//    }
//}

$total_expenses = $objexpense->get_total_expenses($where_clause);

$summary['total_misc_expenses'] = number_format($total_expenses, 2, '.', '');
//------------------
//get total parts
$summary['total_parts'] = number_format($objlaborsparts->get_summary_parts($from_date, $to_date), 2, '.', '');
//------------------
//get total Total Paid out to Technicians
/*
//get al tickets
$tickets_tmp = $objtickets->get_tickets_report('', $from_date, $to_date);        
$tickets = array();
$total_paid_to_technicians = 0;
if ($tickets_tmp)
{
    foreach ($tickets_tmp as $ticket)
    {
        if ($ticket['paid'] == 1)
        {
            $objtickets->get_ticket_report($ticket, $user);                    
            $tickets[] = $ticket;
        }
    }
}
if ($tickets)
{
    foreach ($tickets as $record)
    {
        $total_paid_to_technicians += $record['tech_income'];
    }
}
*/

$total_paid_to_technicians = 0;
$total_prepaid = 0;
//$users_temp = $objuser->get_user_builder($builder);
$users_temp = $objuser->get_view_user_builder();


$tickets = array();

if ($users_temp)
{
    foreach ($users_temp as $user)
    {
        $tickets_tmp = $objtickets->get_tickets_report_optimize($user['user_id'], $from_date, $to_date, $builder);
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $ticket)
            {
                $objtickets->get_ticket_report($ticket, $user['user_id']);
                $tickets[] = $ticket;
            }
        }
    }
}
if ($tickets)
{
    foreach ($tickets as $record)
    {
        $total_paid_to_technicians += number_format($record['tech_income'], 2, '.', '');
        $total_prepaid += number_format($record['payment_amount'], 2, '.', '');
    }
}

$summary['total_paid_to_technicians'] = $total_paid_to_technicians;
//----------------------------
//get total
$summary['total_expenses'] = $summary['total_paid_to_technicians'] + $summary['total_parts'] + $summary['total_misc_expenses'];

//----------------------------
//----------------------------
//get Total Prepaid
$summary['total_prepaid'] = number_format($total_prepaid, 2, '.', '');
//----------------------------
//get Total Paid Invoice
$summary['total_paid_invoice'] = number_format($objtickets->get_total_paid_amount($from_date, $to_date), 2, '.', '');

$summary['total_income'] = $summary['total_paid_invoice'] + $summary['total_prepaid'];

//-------------
$summary['net_income'] = $summary['total_income'] - $summary['total_expenses'];

//----------------------
$total_potential = 0;
$where_clause = ' 1 = 1';
$where_clause .= $from_date ? " AND t.created_date >= '$from_date'" : '';
$where_clause .= $to_date ? " AND t.created_date <= '$to_date'" : '';

//$tickets= $objtickets->get_tickets_cashreceipt($where_clause,0,0);

$tickets = $objtickets->get_view_summary($where_clause);

if($tickets)
{
    foreach ($tickets as $record)
    {
        $record['builder_discount'] = number_format($record['builder_discount'] / 100 * $record['authoried_amount'], 2, '.', '');
        $record['invoice_amount'] = number_format($record['authoried_amount'] - $record['builder_discount'], 2, '.', '');
        
        //calculation total paid amount
        //$payments = $objpaymenthistory->get_payments("ticket_id = " . $record['ticket_id'], 0, 0);
       // $payment = $objpaymenthistory->get_sum_payments($record['ticket_id']);
        //echo $objpaymenthistory->sql;
        //die();
      //  $paid_amount = 0;
        //foreach ($payments as $payment)
       // {
         //   $paid_amount += $payment['received_amount'];
        //}
      //  $record['paid_amount'] = number_format($payment, 2, '.', '') + $record['payment_amount'];

        $total_potential += number_format($record['invoice_amount'] - $record['payment_amount'], 2, '.', '');
    }
}

$sum_payment=$objpaymenthistory->get_sum_view_payments($where_clause);

$total_potential=$total_potential-$sum_payment;
$summary['potential'] = $total_potential;

$templates->setvar('summary', $summary);
//show template
$templates->show('expensesummary.tpl');
?>