<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;


if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');
    
//define object class
$objtickets = new dbtickets();

//requets parameter

$ticket_id = request_var('ticketid', '');

$name = request_var('name', '');
$number = request_var('number', '');
$month = request_var('month', '');
$year = request_var('year', '');
$code = request_var('code', '');
$cardtype = request_var('card_type', '');
$ticketamount = request_var('ticketamount', '');

if($ticketamount<0)
	$ticketamount = $ticketamount*-1;
	
//get ticket information
$ticketinfo = $objtickets->get_ticket_by_id($ticket_id);
$ticketinfo['ticketamount'] = $ticketamount;

//get year for select
$year_date = date('Y');
$templates->setvar("year_start", (int)$year_date);
$templates->setvar("year_end", (int)$year_date + ($config->configurations['NUMBER_YEAR_CARD'] ? (int)$config->configurations['NUMBER_YEAR_CARD'] : 10) );

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
	$vlerror = true;
	
	if ($ticketamount == '')
	{
		$vlerror = false;
		$templates->setvar("error_amount", $lang['E_AMOUNT']);
	}
	elseif (!is_numeric($ticketamount) )
	{
		$vlerror = false;
		$templates->setvar("error_amount", $lang['E_AMOUNT_NUMBERIC']);
	}
	if ($cardtype == '')
	{
		$vlerror = false;
		$templates->setvar("error_card_type", $lang['E_CARD_TYPE']);
	}
	if ($name == '')
	{
		$vlerror = false;
		$templates->setvar("error_name", $lang['E_NAME']);
	}	
	if($month < date('m') && $year == date('Y'))
	{
		$templates->setvar("textErrorDate", $lang['L_EXP_DATE_ERROR']);
		$vlerror = false;
	}
	if ($code == '')
	{
		$vlerror = false;
		$templates->setvar("error_security_code", $lang['E_SECURITY_CODE']);
	}
	$fcheckCreditCard = checkCreditCard($number, $cardtype);
	if($fcheckCreditCard != -1)
	{
		$templates->setvar("textErrornumver", $lang['L_CARD_ERROR']."<br/>");
		$vlerror = false;
	}
	
	$save_ticket = array('card_name' => $name,
						 'card_number' => "xxxxxxxxx".substr($number,strlen($number)-4,4),
						 'card_expiration_date' => $year . '-' . $month . '-1',
						 'card_security_code' => $code);	
	
	if($vlerror)
	{
		$fpayment = payment_credit_card($number, $month, $year, $ticketamount, $ticketinfo);
		if($fpayment == 1)
		{
			$save_ticket['payment_method'] = 'credit_card';
			$save_ticket['payment_amount'] = $ticketamount;
			$save_ticket['check_number'] = '';
			
			$objtickets->save('UPDATE', $save_ticket, "ticket_id = $ticket_id");
			$templates->setvar('save_success', true);
			
			echo '<script type="text/javascript">window.top.document.getElementById("error_completed").parentNode.style.display = "none"</script>';
		}
		else
		{
			$templates->setvar("textErrornumver", $fpayment);
			$ticketinfo['ticketamount'] = $ticketamount;
			$ticketinfo['card_type'] = $cardtype;
			$ticketinfo['card_name'] = $save_ticket['card_name'];
			$ticketinfo['card_number'] = $save_ticket['card_number'];
			$ticketinfo['card_expiration_date'] = $save_ticket['card_expiration_date'];
		}	   
	}
	else
	{
		$ticketinfo['ticketamount'] = $ticketamount;
		$ticketinfo['card_type'] = $cardtype;
		$ticketinfo['card_name'] = $save_ticket['card_name'];
		$ticketinfo['card_number'] = $save_ticket['card_number'];
		$ticketinfo['card_expiration_date'] = $save_ticket['card_expiration_date'];
	}
}
$templates->setvar("ticketinfo", $ticketinfo);

$templates->show('processpayment.tpl');

function payment_credit_card($cardnumber, $month, $year, $ticketamount, $ticketinfo)
{
   $my_cardnumber = $cardnumber;
   $my_month = $month;
   $my_year = substr($year,2,2);
    $post_url = "https://secure.authorize.net/gateway/transact.dll";
    $post_values = array(
	"x_login"		=> "447AfUar",
	"x_tran_key"		=> "4bMjARP42PHr783W",
	"x_version"		=> "3.1",
	"x_delim_data"		=> "TRUE",
	"x_delim_char"		=> "|",
	"x_relay_response"	=> "FALSE",
	"x_type"		=> "AUTH_CAPTURE",
	"x_method"		=> "CC",
	"x_card_num"		=> $my_cardnumber,
	"x_exp_date"		=> $my_month.$my_year,
	"x_amount"		=> $ticketamount,
	"x_description"		=> "Work Order Entry",
	"x_first_name"		=> $ticketinfo['client_name'],
	"x_last_name"		=> '',
	"x_address"		=> $ticketinfo['client_address'],
	"x_state"		=> $ticketinfo['client_state'],
	"x_zip"			=> $ticketinfo['client_zip']
        );
        $post_string = "";
        foreach( $post_values as $key => $value )
                { $post_string .= "$key=" . urlencode( $value ) . "&"; }
        $post_string = rtrim( $post_string, "& " );
        $request = curl_init($post_url); // initiate curl object
                curl_setopt($request, CURLOPT_HEADER, 0); // set to 0 to eliminate header info from response
                curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); // Returns response data instead of TRUE(1)
                curl_setopt($request, CURLOPT_POSTFIELDS, $post_string); // use HTTP POST to send form data
                curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE); // uncomment this line if you get no gateway response.
                $post_response = curl_exec($request); // execute curl post and store results in $post_response
        curl_close ($request); // close curl object
        $response_array = explode($post_values["x_delim_char"],$post_response);
        $paymennumber = $response_array[2];
        if($paymennumber==1)
            return $paymennumber;
        else
            return $response_array[3];
}
?>