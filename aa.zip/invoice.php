<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;



//define object class
$objtickets = new dbtickets();
$objticketstatus = new dbticketstatus();
$objstates = new dbstates();
$objuser = new dbuser();
$objjobstatus = new dbjobstatus();
$objcustomers = new dbcustomers();
$objstatusservice = new dbstatusservice();
$objbuilders = new dbbuilders();
$objproblem = new dbproblem();
$objcompany = new dbcompany();
$objticketsequipments = new dbticketsequipments();
$objlabors_parts = new dblabors_parts();

//requets parameter
$page = request_var('page', 1);
$id = request_var('id', '');
$invoice = request_var('invoice_number', '');
$office = request_var('office_number', '');
$dispatch = request_var('dispatch_id', '');
$client_name = request_var('client_name', '');
$client_address = request_var('client_address', '');
$client_city = request_var('client_city', '');
$client_state = request_var('client_state', '');
$client_zip = request_var('client_zip', '');
$client_phone = request_var('client_phone', '');
$job_date = request_var('job_date', '');
$job_time_in = request_var('job_time_in', '');
$job_time_out = request_var('job_time_out', '');
$ticket_status = request_var('ticket_status', '3');
$status = request_var('status', '');
$assign = request_var('assign', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$paid = request_var('paid', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")
$member = $objuser->get_user_by_id($authenticate->get_user_id());
if($member){
    $templates->setvar('member', $member);
}

switch ($mode)
{
    case "view":          
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        
        //get all status ticket for select
        $ticket_statuses = $objticketstatus->get_ticketstatus('', 0, 0, 'id');
        
        //get all user for assign
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        
        //get all tickets
        $where_clause = ' 1 = 1';
        $where_clause .= " AND t.status_service_id = 3 ";    
        $where_clause .= $invoice ? " AND t.invoice_number like '%$invoice%'" : '';
        $where_clause .= $office ? " AND t.office_number like '%$office%'" : '';
        $where_clause .= $dispatch ? " AND t.dispatch_id like '%$dispatch%'" : '';
        $where_clause .= $client_name ? " AND t.client_name like '%$client_name%'" : '';
        $where_clause .= $client_phone ? " AND t.client_phone like '%$client_phone%'" : '';            
        $where_clause .= $assign ? " AND t.assign_by = " . ($assign == 'none' ? "''" : $assign) : '';
        $where_clause .= $from_date ? " AND t.created_date >= '$from_date'" : '';
        $where_clause .= $to_date ? " AND t.created_date <= '$to_date'" : '';
        $where_clause .= $paid != '' ? " AND t.paid = $paid" : '';
        
        if (!$client_name && !$client_phone && !in_array('see all records', $actionsPermission) )
            $where_clause .= " AND t.assign_by = " . $authenticate->get_user_id();
            
        $tickets = $objtickets->get_all_tickets($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 't.ticket_id'), request_var('sortby', 'desc') );
        $itemcount = $objtickets->get_all_tickets($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('tickets', $tickets);
        $templates->setvar('ticket_statuses', $ticket_statuses);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case "claim":
        
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);

        //get all status ticket for select
        $ticket_statuses = $objticketstatus->get_ticketstatus('', 0, 0, 'id');
        
        //get all user for assign
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        
        //get all tickets
        $where_clause = ' 1 = 1';
        $where_clause .= " AND t.status_service_id = 12 ";   
        $where_clause .= $invoice ? " AND t.invoice_number like '%$invoice%'" : '';
        $where_clause .= $office ? " AND t.office_number like '%$office%'" : '';
        $where_clause .= $dispatch ? " AND t.dispatch_id like '%$dispatch%'" : '';
        $where_clause .= $client_name ? " AND t.client_name like '%$client_name%'" : '';
        $where_clause .= $client_phone ? " AND t.client_phone like '%$client_phone%'" : '';
        $where_clause .= $assign ? " AND t.assign_by = " . ($assign == 'none' ? "''" : $assign) : '';
        $where_clause .= $from_date ? " AND t.created_date >= '$from_date'" : '';
        $where_clause .= $to_date ? " AND t.created_date <= '$to_date'" : '';
        $where_clause .= $paid != '' ? " AND t.paid = $paid" : '';
        
        if (!$client_name && !$client_phone && !in_array('see all records', $actionsPermission) )
            $where_clause .= " AND t.assign_by = " . $authenticate->get_user_id();
            
        $tickets = $objtickets->get_all_tickets($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 't.ticket_id'), request_var('sortby', 'desc') );
        $itemcount = $objtickets->get_all_tickets($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('tickets', $tickets);
        $templates->setvar('ticket_statuses', $ticket_statuses);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case "details":
        if ($id)
        {
            //get information company
            $company_infor = $objcompany->get_company();
            $templates->setvar('company_infor', $company_infor);
            
            //get equipments ticket
            $where_clause = " ticket_id = $id";
            $equipments = $objticketsequipments->get_ticketsequipments($where_clause, 0, 0);
            $templates->setvar('equipments', $equipments);
            
            //get ticket informtion
            $ticket_infor = $objtickets->get_ticket_by_id($id);
            
            $status_service = $objstatusservice->get_status_by_id($ticket_infor['status_service_id']);
            $ticket_infor['status_service_name'] = $status_service['status_service_name'];
            
            $builder = $objbuilders->get_builder_by_id($ticket_infor['builder_id']);
            $ticket_infor['builder_name'] = $ticket_infor['builder_id'] ? $builder['full_name'] : $lang['L_RESALES'];
            
            $status = $objticketstatus->get_status_by_id($ticket_infor['status']);
            $ticket_infor['ticket_status'] = $status['status_name'];
            
            $user = $objuser->get_user_by_id($ticket_infor['posted_by']);
            $ticket_infor['posted_by'] = $user['first_name'] . ' ' . $user['last_name'];
            
            $user = $objuser->get_user_by_id($ticket_infor['assign_by']);
            $ticket_infor['assign_by'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : '';
            
            $user = $objuser->get_user_by_id($ticket_infor['seller']);
            $ticket_infor['seller'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : '';
            
            
            $problems = $objtickets->get_problems_with_name_by_ticket($ticket_infor['ticket_id']);
            $ticket_infor['problems'] = $problems;
            
            //get labor and parts
            $parts_tmp = $objlabors_parts->get_labors_parts_by_ticket($id, request_var('sortfield', 'type') . ' ' . request_var('sortby', 'asc') );
            $parts = array();
            $labors = array();
            //calculator part and labor
            $total_parts = 0;
            $total_labor = 0;
            if ($parts_tmp)
            {
                foreach ($parts_tmp as $part)
                {
                    if ($part['type'] == 1)
                    {
                       $total_labor += $part['price'] * $part['quantity'];
                       $part['name'] = $ticket_infor['assign_by'];
                       
                       $part['ext_price'] = $part['price'] * $part['quantity'];
                       $labors[] = $part;
                    }
                    if ($part['type'] == 2)
                    {
                        $total_parts += $part['price'] * $part['quantity'];
                        $part['name'] = $ticket_infor['seller'];
                        
                        $part['ext_price'] = $part['price'] * $part['quantity'];
                        $parts[] = $part;    
                    }
                }
            }
            $ticket_infor['total_parts'] = $total_parts;
            $ticket_infor['total_labor'] = $total_labor;
            if ($ticket_infor['tax_included'])
                $tax = 0;
            $ticket_infor['tax'] = $total_parts * $tax;
            $ticket_infor['total'] = $ticket_infor['total_parts'] + $ticket_infor['total_labor'] + $ticket_infor['tax'];
            $ticket_infor['total_parts_labor'] = $total_parts + $total_labor;
            $ticket_infor['payment_amount'] = $ticket_infor['authoried_amount'] - $ticket_infor['discount'];
            
            $templates->setvar('parts', $parts);
            $templates->setvar('labors', $labors);
            $templates->setvar('ticket_infor', $ticket_infor);
        }
    break;
}

$templates->setvar('ticket_status', $ticket_status);
//show template
$templates->show('invoice.tpl');
?>