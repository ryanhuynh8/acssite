<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;


if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');
    
//define object class
$objtickets = new dbtickets();
$objlaborsparts = new dblabors_parts();
$objinventory = new dbinventory();

//requets parameter
$ticket_id = request_var('ticketid', '');
$item_number = request_var('item_number', '');
$description = request_var('description', '');
$quantity = request_var('quantity', '');
$type = request_var('type', '');
$page = request_var('page', 1);

if (trim($item_number) != '' || trim($description) != '')
{
    if ($type == 'labor')
    {
        //get all labor for grid view
        $where_clause = ' 1 AND is_availabled = 1 AND type = 1';
        $where_clause .= $item_number ? " AND item_number like '%$item_number%'" : '';
        $where_clause .= $description ? " AND description like '%$description%'" : '';
        
        $labors = $objlaborsparts->get_labors_parts($where_clause, 0, 0, request_var('sortfield', 'description'), request_var('sortby', 'asc') );
        
        $templates->setvar("labor_parts", $labors);
    }
    else
    {
        $where_clause = ' 1 AND lb.is_availabled = 1 AND lb.type = 2';
        //$where_clause .= " AND i.user_id = " . $assign;
        $where_clause .= " AND i.user_id = " . $authenticate->get_user_id();
        $where_clause .= " AND i.quantity > 0 ";
        $where_clause .= $item_number ? " AND lb.item_number like '%$item_number%'" : '';
        $where_clause .= $description ? " AND lb.description like '%$description%'" : '';
        
        $parts = $objinventory->get_inventories($where_clause, 0, 0, request_var('sortfield', 'description'), request_var('sortby', 'asc') );
       // echo $authenticate->get_user_id();
       // echo $objinventory->sql;
        $templates->setvar("labor_parts", $parts);
    }
}
//set number quantity for select
$templates->setvar("quantity", $config->configurations['QUANTITY_LABOR_PART'] ? $config->configurations['QUANTITY_LABOR_PART'] : 5);

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $not_selected = false;
    $error_quantity = true;
    
    foreach ($_POST as $key=>$value)
    {
        $checked = substr($key, 0, 9);
        
        if ($checked == 'checkbox_')
        {
            $not_selected = true;
            $labor_part_id = $value;
            
            $part_infor = $objlaborsparts->get_labor_part_by_id($labor_part_id);
            $customer_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['customer_mark_up'] / 100);
            $tech_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100);
            $assign = $objtickets->get_userid_by_ticketid($ticket_id);

            $save_ticket_part = array('ticket_id' => $ticket_id,
                                     // 'user_id' => $authenticate->get_user_id(),
                                       'user_id' => $assign ,
                                      'labor_part_id' => $labor_part_id,
                                      'quantity' => $quantity,
                                      'price' => $customer_price,
                                      'tech_price' => $tech_price,
                                      'created_date' => date('Y-m-d') );
            
            //validator quantity in inventory
            if ($type == 'part')
            {
                $inventory_quantity = $objinventory->get_quantity_in_inventory($save_ticket_part['user_id'], $save_ticket_part['labor_part_id']);
                if ($quantity > $inventory_quantity)
                {
                    $error_quantity = false;
                }
            }

            if ($error_quantity)
            {
                $part_exists = $objtickets->get_ticket_part_exists($assign, $ticket_id, $labor_part_id);
                if ($part_exists)
                    $objtickets->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] + $quantity),
                                                    ' ticket_part_id=' . $part_exists['ticket_part_id']);
                else
                    $objtickets->update_ticket_part('INSERT', $save_ticket_part);
                
                if ($type == 'part')
                {
                    //subtract quantity from inventory of user
                    $objinventory->subtract_quantity_of_user($assign, $labor_part_id, -$quantity);
                    //delete inventory if it is zero
                    //$objinventory->delete_inventory_zero();
                }
            }
        }
    }
    
    if ($not_selected && $error_quantity)
    {
        //redirect page under popup when added parts
        echo '<script type="text/javascript">window.top.location.href="ticketslaborsparts.php?ticketid='. $ticket_id .'"</script>';
    }
    else
    {

        if (!$not_selected)
            $templates->setvar("error_select", $type == 'labor' ? $lang['E_NO_SELECT_LABOR'] : $lang['E_NO_SELECT_PART']);
        else{
            $templates->setvar("error_select", $lang['E_SELECT_QUANTITY']);

        }

    }
}


$templates->show('selectpart.tpl');
?>