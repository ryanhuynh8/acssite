<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');

//define object class
$objticketstatus = new dbticketstatus();
$objtickets = new dbtickets();
$objjobstatus = new dbjobstatus();
$objticketsequipments = new dbticketsequipments();
$objlaborsparts = new dblabors_parts();
$objproblem = new dbproblem();

//requets parameter
$ticketid = request_var('ticketid', '');
$save = request_var('save_x', '');
$quantity = request_var('quantity', '');
$price = request_var('price', '');
$ticket_part_id = request_var('ticket_part_id', '');

switch($mode)
{
    case 'details':
        if ($ticketid)
        {
            //get all jobs status
            $jobstatuses = $objjobstatus->get_jobstatus('', 0, 0);
            $templates->setvar("jobstatus", $jobstatuses);
            
            //get all equipments
            $equipments = $objticketsequipments->get_ticketsequipments("ticket_id = $ticketid", 0, null);
            $templates->setvar("equipments", $equipments);
            
            $ticket_infor = $objtickets->get_ticket_by_id($ticketid);
                        
            $user = $objuser->get_user_by_id($ticket_infor['posted_by']);
            $ticket_infor['posted_by'] = $user['first_name'] . ' ' .  $user['last_name'];
            $user = $objuser->get_user_by_id($ticket_infor['assign_by']);
            $ticket_infor['assign_by'] = $user['first_name'] . ' ' .  $user['last_name'];
            $user = $objuser->get_user_by_id($ticket_infor['seller']);
            $ticket_infor['seller'] = $user['first_name'] . ' ' . $user['last_name'];
            
            $ticket_status = $objticketstatus->get_status_by_id($ticket_infor['status']);
            $ticket_infor['ticket_status'] = $ticket_status['status_name'];
            
            $job_status = $objjobstatus->get_jobstatus_by_id($ticket_infor['job_status']);
            $ticket_infor['job_status_name'] = $job_status['status_name'];

            $problems = $objproblem->getAllProblemsByParent();
            $ticketinfo['problems'] = $objtickets->get_ticket_problems($ticketid);
            $countProblems = count($objtickets->get_ticket_problems_by_parent($ticketid, 0) );
            
            $templates->setvar("ticket_infor", $ticket_infor);
            $templates->setvar("problems", $problems);
            $templates->setvar("size_problems", $countProblems);
        }
    break;
    case 'details_labor_part':
        if ($ticketid)
        {
            //update labor and parts
            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                if ($save)
                {
                    //check validator
                    $error_validator = true;
                    if (trim($quantity) == '')
                    {
                        $error_validator = false;
                        $templates->setvar('error_complete', $lang['E_QUANTITY']);
                    }
                    elseif (!is_numeric($quantity))
                    {
                        $error_validator = false;
                        $templates->setvar('error_complete', $lang['E_QUANTITY_NUMBERIC']);
                    }
                    elseif (trim($price) == '')
                    {
                        $error_validator = false;
                        $templates->setvar('error_complete', $lang['E_PRICE']);
                    }
                    elseif (!is_numeric($price))
                    {
                        $error_validator = false;
                        $templates->setvar('error_complete', $lang['E_PRICE_NUMBERIC']);
                    }
                    
                    
                    $save_ticket_part = array('quantity' => $quantity,
                                              'price' => $price);
                    if ($error_validator)
                    {                        
                        //update quantity and price labor or parts            
                        $objtickets->update_ticket_part('UPDATE', $save_ticket_part, "ticket_part_id = $ticket_part_id");
                        
                        redirect(get_page() . "?mode=details_labor_part&ticketid=$ticketid");
                    }
                    else
                    {            
                        $templates->setvar('labor_part_infor', $save_ticket_part);
                    }                    
                }                
            }
            
            //get ticket information
            $ticket_infor = $objtickets->get_ticket_by_id($ticketid);
            
            $user = $objuser->get_user_by_id($ticket_infor['posted_by']);
            $ticket_infor['posted_by'] = $user['first_name'] . ' ' .  $user['last_name'];
            $user = $objuser->get_user_by_id($ticket_infor['assign_by']);
            $ticket_infor['assign_by'] = $user['first_name'] . ' ' .  $user['last_name'];
            $user = $objuser->get_user_by_id($ticket_infor['seller']);
            $ticket_infor['seller'] = $user['first_name'] . ' ' . $user['last_name'];
            
            //get all parts
            $parts_tmp = $objlaborsparts->get_labors_parts_by_ticket($ticketid);
            $parts = array();
            //price total parts
            if ($parts_tmp)
            {
                foreach ($parts_tmp as $part)
                {
                    if ($part['type'] == 1)
                        $ticket_infor['labor_price'] += $part['price'] * $part['quantity'];
                    if ($part['type'] == 2)
                        $ticket_infor['part_price'] += $part['price'] * $part['quantity'];
                    
                    $part['ext_price'] = $part['price'] * $part['quantity'];
                    $parts[] = $part;
                }
            }
            
            $ticket_infor['sub_price'] = $ticket_infor['labor_price'] + $ticket_infor['part_price'];
            if ($ticket_infor['tax_included'])
                $tax = 0;
            $ticket_infor['tax_price'] = $ticket_infor['part_price'] * $tax;
            $ticket_infor['total_price'] = $ticket_infor['tax_price'] + $ticket_infor['sub_price'];            
            $ticket_infor['additional_charge'] = number_format($ticket_infor['authoried_amount'] - $ticket_infor['installation_charge'] - $ticket_infor['total_price'], '2', '.', '');
            
            //show template
            $templates->setvar('parts', $parts);
            $templates->setvar('ticket_infor', $ticket_infor);
        }
        
    break;

    
}



//show template
$templates->show('ticketdetails.tpl');
?>