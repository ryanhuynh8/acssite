<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();

//requets parameter
$ticket_id = request_var('ticketid', '');

//get information ticket
$ticket_infor = $objtickets->get_ticket_by_id($ticket_id);

$templates->setvar('ticket_infor', $ticket_infor);

//show template
$templates->show('viewbuildernotes.tpl');
?>