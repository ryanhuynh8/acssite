<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;



//define object class
$objtickets = new dbtickets();
$objuser = new dbuser();
$objsettletickets= new dbsettletickets();


//requets parameter
$page = request_var('page', 1);
$id_invoice_number = request_var('id', '');
$assign=request_var('assign', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');

$payment_method_cash=request_var('payment_method_cash','');
$payment_method_check=request_var('payment_method_check','');
$payment_method_credit=request_var('payment_method_credit','');
$payment_method_non=request_var('payment_method_non','');
$settle_status=request_var('settle_status', '0');
$received_by_initial=request_var('received_by_initial','');
$notes=request_var('notes','');
$received_date=request_var('received_date','');
$received_by_name=request_var('received_by_name', '');


//if ($_SERVER['REQUEST_METHOD'] == "POST")
$member = $objuser->get_user_by_id($authenticate->get_user_id());
if($member){
     $templates->setvar('member', $member);
}

switch ($mode)
{
    case "view":
    	get_date_month($start_date, $end_date);
        if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
        if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
        $templates->setvar('filter', array('from_date' => $from_date, 'to_date' => $to_date) );
        
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);   
        //get all user for select
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);

          //get all tickets
        $where_clause = ' 1 = 1';
        $where_clause .= " AND (t.status_service_id = 3 OR t.status_service_id = 12) ";
        $where_clause .= $assign ? " AND t.assign_by = '$assign'" : '';                                 
		$where_clause .= $from_date ? " AND DATE(t.complete_date) >= '$from_date'" : '';
        $where_clause .= $to_date ? " AND DATE(t.complete_date) <= '$to_date'" : '';
        $where_clause .= " AND t.invoice_number in (select s.ticket_invoice_id from ".TBL_SETTLED_TICKET." AS s)";
        $tickets_tmp = $objsettletickets->get_settled_ticket($where_clause, 0, 0,request_var('sortfield', 'twofiled'), request_var('sortby', 'asc') );                     
        $tickets = array();
        $results = array();       
        $complete_date = '';
        $index = 0;
        $number_commission = 0;
        $summary = array();
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $row)
            {
                if ($complete_date != $row['report_date'])
                {
                    $complete_date = $row['report_date'];
                    $index++;
                }
                $results[$index]['date'] = $complete_date;
                $results[$index]['tickets'][] = $row;
                
              	$summary['authorized_amount'] += $row['authoried_amount'];
                $summary['payment_amount'] += $row['payment_amount'];           
                
                if ($row['payment_method'] == 'cash')
                    $summary['cash'] += $row['payment_amount'];
                if ($row['payment_method'] == 'check')
                    $summary['check'] += $row['payment_amount'];
                if ($row['payment_method'] == 'credit_card')
                    $summary['credit_card'] += $row['payment_amount'];
				if ($row['payment_method'] == 'non_collected')
					    $summary['non_collected'] += $row['payment_amount'];				                    
                    
            }        
        
	        $summary['cash'] = $summary['cash'] ? $summary['cash'] : 0;
	        $summary['check'] = $summary['check'] ? $summary['check'] : 0;
	        $summary['credit_card'] = $summary['credit_card'] ? $summary['credit_card'] : 0;
	        $summary['non_collected'] = $summary['non_collected'] ? $summary['non_collected'] : 0;
			$summary['total_tickets'] = count($tickets_tmp);
	        $summary['avg_amount'] = ($summary['cash']+$summary['check']+$summary['credit_card']+$summary['non_collected']) / count($tickets_tmp);
	        $templates->setvar('results', $results);
	        $templates->setvar('tickets', $tickets_tmp);
	        $templates->setvar('summary', $summary);
        }
    break;       

}

//show template
$templates->show('settletickets_report.tpl');

?>