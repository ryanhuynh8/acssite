<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');

$objticketsequipments = new dbticketsequipments();

$ticketid = request_var('ticketid', '');
$smake = request_var('txtmake', '');
$smodel = request_var('txtmodel', '');
$sserial = request_var('txtserial', '');
$cURL = "tickets.php?ticketid=$ticketid";

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $error_validator = true;
    
    
    $ticketsequipments = array(
                       'ticket_id'         => $ticketid,
                       'made_by'           => $smake,
                       'model_number'      => $smodel,
                       'serial_number'     => $sserial
                       );
    
    if (trim($smake) == '')
    {
        $error_validator = false;
        $templates->setvar("error_make", $lang['E_MAKE']);
    }
    
    if (trim($smodel) == '')
    {
        $error_validator = false;
        $templates->setvar("error_model", $lang['E_MODEL']);
    }
    
    if (trim($sserial) == '')
    {
        $error_validator = false;
        $templates->setvar("error_serial", $lang['E_SERIAL']);
    }
    
    if ($error_validator)
    {
        $objticketsequipments->save_ticketsequipments('INSERT', $ticketsequipments);
        
        echo '<script language="javascript">top.window.location.href="'.$cURL.'"</script>';
    }
}

//show template
$templates->setvar("ticket_id", $ticketid);
$templates->setvar("ticketsequipmentsinfo", $ticketsequipments);
$templates->show('ticketsequipments.tpl');
?>