<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $actionsPermission;

//define object class
$objtickets = new dbtickets();
$objticketstatus = new dbticketstatus();
$objstates = new dbstates();
$objuser = new dbuser();
$objjobstatus = new dbjobstatus();
$objcustomers = new dbcustomers();
$objstatusservice = new dbstatusservice();
$objbuilders = new dbbuilders();
$objproblem = new dbproblem();
$objrole = new dbroles();
$objinventory = new dbinventory();
$objpurchaseditem = new dbpurchaseditems();
$objorder = new dbpurchasedorder();
$objvendors = new dbvendors();
$objlaborsparts = new dblabors_parts();
$objtype = new dbtype();
$objticketstype = new dbticketstype();
//requets parameter
$page = request_var('page', 1);
$id = request_var('id', '');
$invoice = request_var('invoice_number', '');
$office = request_var('office_number', '');
$dispatch = request_var('dispatch_id', '');
$type_id = request_var('type_id', '');
$client_name = request_var('client_name', '');
$client_address = request_var('client_address', '');
$client_city = request_var('client_city', '');
$client_state = request_var('client_state', '');
$client_zip = request_var('client_zip', '');
$client_phone = request_var('client_phone', '');
$client_builder = request_var('client_builder', '');
$job_date = request_var('job_date', '');
$job_time_in = request_var('job_time_in', '');
$job_time_out = request_var('job_time_out', '');
$ticket_status = request_var('ticket_status', '');
$status = request_var('status', '');
$assign = request_var('assign', '');
$seller = request_var('seller', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$from_promised_date = request_var('from_promised_date','');
$to_promised_date = request_var('to_promised_date','');
$status_service = request_var('status_service', '');
$promised_date = request_var('promised_date', '');
$promised_time_from = request_var('promised_time_from', '');
$promised_time_to = request_var('promised_time_to', '');
$note = request_var('note', '');
$po_id = request_var('po_id','');
$service_ticket = request_var('service_ticket ','');
$urgency = request_var('urgency','');

$builder = request_var('builder', '');
$customer = request_var('customer', '');
$keymap = request_var('keymap', '');
$office_notes = request_var('office_notes', '');
$ticket_id = request_var('ticket_id', '');
$invoice_id = request_var('invoice_id', '');
$back = request_var('back', '');
$bsys = request_var('bsys', '1');

$search_name = request_var('search_name', '');
$search_address = request_var('search_address', '');
$search_city = request_var('search_city', '');
$search_state = request_var('search_state', '');
$search_zip = request_var('search_zip', '');
$search_customers = request_var('search_customers', '');

$client_office_notes = request_var('client_office_notes', '');
$client_job_notes = request_var('client_job_notes', '');
if($bsys==1)
	$status_service = request_var('status_service', '');
else
	$status_service = implode(',', $_GET['status_service']);
//if ($_SERVER['REQUEST_METHOD'] == "POST")
$templates->setvar("selected_status", $status_service); 
if($bsys==1)
{
    $templates->setvar("managermenu1", "tab_on");
}elseif($bsys==2)
{
    $templates->setvar("managermenu2", "tab_on");
}

switch ($mode)
{
    case "view":
    	if ($_SERVER['REQUEST_METHOD'] == "POST")
    	{
    		$ticket_id_action = $_POST["ticket_id_action"];
    		$status_service_action = $_POST['status_service_action'];
            //var_dump($status_service_action);
    		$promised_date = $_POST['promised_date'];
    		$promised_time_from = $_POST["promised_time_from"];
    		$promised_time_to = $_POST["promised_time_to"];
			$technician = $_POST["technician"];
			$problem = $_POST["problem"];
			$builder = $_POST["builder"];
            $checksave = $_POST["checksave"];

    		if (is_array($ticket_id_action) && count($ticket_id_action) > 0)
    		{
    			$i = 0;
    			foreach($ticket_id_action as $ticket)
    			{
    				$updateArr = array("status_service_id" => $status_service_action[$i]);
    				if (trim($promised_date[$i]) != "")
    					$updateArr["promised_date"] = convert_to_standard_date($promised_date[$i]);
    				
    				if (trim($promised_time_from[$i]) != "" && is_valid_time_custom($promised_time_from[$i]))	
    					$updateArr["promised_time_from"] = date('H:i:s', strtotime($promised_time_from[$i]));
    				
    				if (trim($promised_time_to[$i]) != "" && trim($promised_time_from[$i]) != "" && is_valid_time_custom($promised_time_to[$i]) && strtotime($promised_time_from[$i]) < strtotime($promised_time_to[$i]))	
    					$updateArr["promised_time_to"] = date('H:i:s', strtotime($promised_time_to[$i]));
            		
					if (trim($technician[$i]) != "")
						$updateArr["assign_by"] = $technician[$i];
						
					if (trim($builder[$i]) != "")
						$updateArr["builder_id"] = $builder[$i];

                    if ($status_service_action[$i] == 3 && $checksave[$i] == 1){
                        $updateArr["complete_date"] = date("Y-m-d");
                    }
					//update commission
					$ticketInfo = $objtickets->get_ticket_by_id($ticket);
                    if($status_service_action[$i]==2&& $ticketInfo['status_service_id']!=2 &&$ticketInfo['assign_by']){

                        $ticket_infor = $objtickets->get_ticket_by_id($ticket);
                        $user_infor = $objuser->get_user_by_id($ticket_infor['assign_by']);
                        $subject = "ACS ticket #". $ticket_infor['ticket_id'] ." is assigned to you" .
                            ($ticket_infor['job_date'] == '0000-00-00' ? '' : ' on ' . date('m/d/Y', strtotime($ticket_infor['job_date']) ) );
                        $msgbody = get_email_body($ticket_infor);
                        $email = $user_infor['email'];
                        $from = $config->configurations["ADMIN_EMAIL"];
                        send_mail($from, $email, $subject, $msgbody, true);
                    }
					if ($updateArr['assign_by'] != '' && $updateArr['assign_by'] != $ticketInfo['assign_by'])
					{
						$ticketInfo['status_service_id'] = $updateArr['status_service_id'];
						$ticketInfo['assign_by'] = $updateArr['assign_by'];
						$objtickets->updateCommission($ticketInfo);
                        $objtickets->update_assign_ticket_part($ticket,$updateArr['assign_by']);

					}
					$objtickets->save("UPDATE", $updateArr, " ticket_id = " . $objtickets->escape($ticket));
					
					/*--update problem--*/
					//delete old problem
                    $objtickets->delete_problem($ticket);
                    //insert problem by ticket
					if ($problem[$ticket])
					{
						foreach ($problem[$ticket] as $value)
							$objtickets->save_problem($ticket, $value);
					}
					
					$i++; 				
    			}
    		}

    	}
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        $from_promised_date = convert_to_standard_date($from_promised_date);
        $to_promised_date = convert_to_standard_date($to_promised_date);
        //get all status service for filter
        $stauses_service = array();
        if($bsys == 1)
        	$stauses_service_tmp = $objstatusservice->get_statuses('', 0, 0, 'status_service_name');
        else //don't display  Completed, Cancelled ticket
			$stauses_service_tmp = $objstatusservice->get_statuses(' status_service_id  not in(3,8)', 0, 0, 'status_service_name');
        
        $total_tickets_status = 0;
        if ($stauses_service_tmp)
        {
            foreach ($stauses_service_tmp as $record)
            {
                if ($record['status_service_id'] != 12)
                {
                    $where_clause = " t.status_service_id = " . $record['status_service_id'];

                    if (!in_array('see all records', $actionsPermission) )
                    {
                        $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
                    }
                    $total_tickets = $objtickets->get_all_tickets($where_clause, 0, 0, '', '', true);
                    $record['total'] = $total_tickets;
                    $stauses_service[] = $record;
                    $total_tickets_status += $total_tickets;
                }
            }
        }
        
        $templates->setvar('total_tickets_status', $total_tickets_status);
        
        //get all tickets
        $where_clause = ' 1 = 1';        
        $where_clause .= $client_name ? " AND t.client_name like \"%$client_name%\" " : '';
        $where_clause .= $client_phone ? " AND t.client_phone like \"%$client_phone%\" " : '';
        $where_clause .= $client_address ? " AND t.client_address like \"%$client_address%\" " : '';
		$where_clause .= $dispatch ? " AND t.dispatch_id like \"%$dispatch%\" " : '';
		$where_clause .= $invoice ? " AND t.invoice_number like \"%$invoice%\" " : '';
		$where_clause .= $urgency ? " AND t.urgency like \"%$urgency%\" " : '';
        $where_clause .= $from_promised_date ? " AND t.promised_date >= '$from_promised_date 00:00:00'" : '';
        $where_clause .= $to_promised_date ? " AND t.promised_date <= '$to_promised_date 23:59:59'" : '';
        if($bsys == 1)
        	$where_clause .= $status_service ? " AND t.status_service_id = $status_service" : " AND t.status_service_id <> 12";
        else 
        	$where_clause .= $status_service ? " AND t.status_service_id in ($status_service)" : " AND t.status_service_id <> 12";	

        if (!in_array('see all records', $actionsPermission) )
        {
            $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
        }
        else 
        {
        	if ($assign != "")
        		$where_clause .= " AND  t.assign_by = " . $objtickets->escape($assign);
        }
        
        
        //for gridview
        if ($bsys == 1)
        	$tickets_tmp = $objtickets->get_service_tickets($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 't.ticket_id'), request_var('sortby', 'desc') );
        else 
			$tickets_tmp = $objtickets->get_service_tickets($where_clause . " and t.status_service_id not in (8,3)", null, null, null, null, false);        		
		//
        $itemcount = $objtickets->get_service_tickets($where_clause, 0, 0, '', '', true);
        $tickets = array();
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $item)
            {
                $item['problem_name'] = $objtickets->get_first_problems_with_name_by_ticket($item['ticket_id']);

				$item['problems'] = $objtickets->get_ticket_problems($item['ticket_id']);
				
				$builders = array();
				if ($item['customer_id'])
				{
					$customer = $objcustomers->get_customer_by_id($item['customer_id']);
					
					$builder_1 = $objbuilders->get_builder_by_id($customer['builder_id_1']);
					$builder_2 = $objbuilders->get_builder_by_id($customer['builder_id_2']);
					$builder_3 = $objbuilders->get_builder_by_id($customer['builder_id_3']);
					$builder_4 = $objbuilders->get_builder_by_id($customer['builder_id_4']);
					if (is_array($builder_1) ) $builders[] = $builder_1;
					if (is_array($builder_2) ) $builders[] = $builder_2;
					if (is_array($builder_3) ) $builders[] = $builder_3;
					if (is_array($builder_4) ) $builders[] = $builder_4;
				}
				$item['builders'] = $builders;
				
				
                $tickets[] = $item;
            }
        }
		
		//get all problem for select
		$problems = $objproblem->getAllProblemsByParent(' actived = 1', 'ordered', 'asc');
		$templates->setvar('problems', $problems);
		
		//get all role for filter assign user
		$roles = $objrole->get_roles('');

		$templates->setvar('roles', $roles);
		
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);

		$listUserArrayJavascript = array();
		foreach ($users as $user)
		{
			$listUserArrayJavascript[] = "[{$user['role_id']}, {$user['user_id']}, '{$user['first_name']} {$user['last_name']}']";
		}
		$templates->setvar('listUserArrayJavascript', implode(',', $listUserArrayJavascript) );
		
        $templates->setvar('tickets', $tickets);
        $templates->setvar("bsys", $bsys);
        
        $templates->setvar('stauses_service', $stauses_service);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    case "refreshmap":
    	$from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        
        //get all status service for filter
        $stauses_service = array();
        $stauses_service_tmp = $objstatusservice->get_statuses(' status_service_id  not in(3,8)', 0, 0, 'status_service_name');
        
        $total_tickets_status = 0;
        if ($stauses_service_tmp)
        {
            foreach ($stauses_service_tmp as $record)
            {
                if ($record['status_service_id'] != 12)
                {
                    $where_clause = " t.status_service_id = " . $record['status_service_id'];

                    if (!in_array('see all records', $actionsPermission) )
                    {
                        $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
                    }
                    $total_tickets = $objtickets->get_all_tickets($where_clause, 0, 0, '', '', true);
                    $record['total'] = $total_tickets;
                    $stauses_service[] = $record;
                    $total_tickets_status += $total_tickets;
                }
            }
        }
        
        
        
        $templates->setvar('total_tickets_status', $total_tickets_status);
        
        //get all tickets
        $where_clause = ' 1 = 1';        
        $where_clause .= $client_name ? " AND t.client_name like \"%$client_name%\" " : '';
        $where_clause .= $client_phone ? " AND t.client_phone like \"%$client_phone%\" " : '';
        $where_clause .= $client_address ? " AND t.client_address like \"%$client_address%\" " : '';
        $where_clause .= $from_date ? " AND t.created_date >= '$from_date 00:00:00'" : '';
        $where_clause .= $to_date ? " AND t.created_date <= '$to_date 23:59:59'" : '';
        $where_clause .= $status_service ? " AND t.status_service_id in ($status_service)" : " AND t.status_service_id <> 12";	

        if (!in_array('see all records', $actionsPermission) )
        {
            $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
        }
        else 
        {
        	if ($assign != "")
        		$where_clause .= " AND  t.assign_by = " . $objtickets->escape($assign);
        }

        $tickets_tmp = $objtickets->get_service_tickets($where_clause . " and t.status_service_id not in (8,3)", null, null, null, null, false);        		
        $tickets = array();
        $sql = $objtickets->sql;
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $item)
            {
                $problems = $objtickets->get_problems_with_name_by_ticket($item['ticket_id']);
                $item['problem_name'] = $problems[0]['problem_name'];
                $tickets[] = $item;
            }
        }
        
       	echo refeshGoogleMap($tickets, $stauses_service);
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        $templates->setvar("bsys", $bsys);
        exit;
    break;		
	
    case "refreshstatus":
		//get all status service for filter
        $stauses_service = array();
        $stauses_service_tmp = $objstatusservice->get_statuses(' status_service_id  not in(3,8)', 0, 0, 'status_service_name');
        
        $total_tickets_status = 0;
        if ($stauses_service_tmp)
        {
            foreach ($stauses_service_tmp as $record)
            {
                if ($record['status_service_id'] != 12)
                {
                    $where_clause = " t.status_service_id = " . $record['status_service_id'];
                    if (!in_array('see all records', $actionsPermission) )
                    {
                        $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
                    }
                    $total_tickets = $objtickets->get_all_tickets($where_clause, 0, 0, '', '', true);
                    $record['total'] = $total_tickets;
                    $stauses_service[] = $record;
                    $total_tickets_status += $total_tickets;
                }
            }
        }
        $html = '<ul class="filter_radio">';
		foreach ($stauses_service as $status)
		{
			$html .= '<li><input type="checkbox" id="status_service_' . $status['status_service_id'] .'" value="' . $status['status_service_id'] .'" name="status_service[]" '; 
			if (in_array($status['status_service_id'], $_GET['status_service']))
				$html .= ' checked="checked" '; 
			$html .= '/><label for="status_service_' . $status['status_service_id'] .'"> <img src="imagegen.php?src=images%2F' . $status['status_service_id'] .'.png&character=' . $status['total'] .'"> ' . $status['status_service_name'] . ' (' . $status['total'] . ')</label></li>';
			if ($status['status_service_name'] == 'Accepted')
			{
				$html .= '<li><input type="checkbox" id="status_service_0" value="" name="status_service" ';
				if (!$_GET['status_service'])
					$html .= ' checked="checked" ';
				 $html .= '/><label for="status_service_0"> ' . $lang['L_ALL'] . '(' . $total_tickets_status . ')</label></li>';
			}
				
		}
		$html .= "</ul>";
		echo $html;
		exit;
    break;
    case "claim":

        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        $from_promised_date = convert_to_standard_date($from_promised_date);
        $to_promised_date = convert_to_standard_date($to_promised_date);
        //get all builder for select
        $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
        $templates->setvar('builders', $builders);
        //get all tickets
        $where_clause = ' 1 = 1';        
        $where_clause .= $client_name ? " AND t.client_name like \"%$client_name%\" " : '';
        $where_clause .= $client_phone ? " AND t.client_phone like \"%$client_phone%\" " : '';
        $where_clause .= $client_address ? " AND t.client_address like \"%$client_address%\" " : '';
		$where_clause .= $dispatch ? " AND t.dispatch_id like \"%$dispatch%\" " : '';
//        $where_clause .= $invoice ? " AND t.invoice_number like \"%$invoice%\" " : '';
        $where_clause .= $from_promised_date ? " AND t.promised_date >= '$from_promised_date 00:00:00'" : '';
        $where_clause .= $to_promised_date ? " AND t.promised_date <= '$to_promised_date 23:59:59'" : '';
        $where_clause .= $client_builder ? " AND t.builder_id = $client_builder " : '';
        $where_clause .= " AND t.status_service_id = 12";
        
        if (!in_array('see all records', $actionsPermission) )
        {
            $where_clause .= " AND (t.posted_by = ". $user_global['user_id'] ." OR t.assign_by = ". $user_global['user_id'] .")";
        }

        $tickets_tmp = $objtickets->get_service_tickets($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 't.ticket_id'), request_var('sortby', 'desc') );
        $itemcount = $objtickets->get_service_tickets($where_clause, 0, 0, '', '', true);
        $tickets = array();
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $item)
            {
                $problems = $objtickets->get_problems_with_name_by_ticket($item['ticket_id']);
                $item['problem_name'] = $problems[0]['problem_name'];
                $tickets[] = $item;
            }
        }
        
        $templates->setvar('tickets', $tickets);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case "edit":
        //get all problems
        $problems_tmp = $objproblem->get_problems(' actived = 1', 0, 0);
        
        //get service statuses
        $statuses_services = $objstatusservice->get_statuses('', 0, 0, 'status_service_name');
        $templates->setvar('statuses_services', $statuses_services);
        
        //get all builder for select
        $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
        $templates->setvar('builders', $builders);
        $templates->setvar('builders2', $builders);
        
        //get all customers
        if ($search_customers)
        {
            $whereClause = ' 1 ';
            $whereClause .= $search_name ? " AND c.full_name like \"%$search_name%\" " : '';
            $whereClause .= $search_address ? " AND c.address like \"%$search_address%\" " : '';
            $whereClause .= $search_city ? " AND c.city like \"%$search_city%\" " : '';
            $whereClause .= $search_state ? " AND c.state = '$search_state' " : '';
            $whereClause .= $search_zip ? " AND c.zip like \"%$search_zip%\" " : '';
            $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
            $templates->setvar('customers', $customers);
        }
        else
        {
            if ($id)
            {
                //get ticket informtion
                $ticket_infor = $objtickets->get_ticket_by_id($id);
                $whereClause = ' 1 ';
                $whereClause = " customer_id = " . $ticket_infor['customer_id'];
                $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
                $templates->setvar('customers', $customers);
                if(isset($customers[0]['state']) && trim($customers[0]['state'])!='')
                    $templates->setvar('customer_state', trim($customers[0]['state']));
            }
        }
        //get job status
        $jobstatuses = $objjobstatus->get_jobstatus("", 0, null);
        $templates->setvar('jobstatuses', $jobstatuses);
        
        //get all status ticket for select
        $ticket_statuses = $objticketstatus->get_ticketstatus('', 0, 0, 'id');
        $templates->setvar('ticket_statuses', $ticket_statuses);
        
        //get state for select
        $states = $objstates->get_states('', 0, 0, 'state_code');
        $templates->setvar('states', $states);
        
        //get all user for assign
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);

        //get all ticket type for assign
        $type = $objtype->get_type('', 0, 0, 'type_name');
        $templates->setvar('type', $type);

        //get all ticket type
        $ticketstype = $objticketstype->get_ticketstype("t.ticket_id={$id}",0, 0,'created_date');
        $templates->setvar('ticketstype', $ticketstype);

        if ($id)
        {
            //get ticket informtion
            $ticket_infor = $objtickets->get_ticket_by_id($id);
            $ticket_infor['job_date'] = ($ticket_infor['job_date'] == '0000-00-00' ? date('Y-m-d') : $ticket_infor['job_date']);
            $ticket_infor['promised_date'] = ($ticket_infor['promised_date'] == '0000-00-00' ? date('Y-m-d') : $ticket_infor['promised_date']);
            $templates->setvar('ticket_infor', $ticket_infor);
            
            //get problem of ticket
            $problems = $objproblem->getAllProblemsByParent(' actived=1', 'ordered', 'asc');
            $templates->setvar('problems', $problems);
            $ticket_problems = $objtickets->get_ticket_problems($id);
            $templates->setvar('ticket_problems', $ticket_problems);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $customer_infor = $objcustomers->get_customer_by_id($ticket_infor['customer_id']);
                if ($customer_infor)
                {                
                    $builder_1 = $objbuilders->get_builder_by_id($customer_infor['builder_id_1']);
                    $builder_2 = $objbuilders->get_builder_by_id($customer_infor['builder_id_2']);
					$builder_3 = $objbuilders->get_builder_by_id($customer_infor['builder_id_3']);
					$builder_4 = $objbuilders->get_builder_by_id($customer_infor['builder_id_4']);

                    $builders = array();
                    if ($builder_1)
                        $builders[] = $builder_1;
                    if ($builder_2)
                        $builders[] = $builder_2;
					if ($builder_3)
                        $builders[] = $builder_3;
                    if ($builder_4)
                        $builders[] = $builder_4;
                    
                    $templates->setvar('builders', $builders);
                }
            }
            else
            {
                $validator_error = true;
                if (!$ticketstype && $type_id != 1)
                {
                    $templates->setvar('error_tickettype', $lang['E_TICKETTYPE']);
                    $validator_error = false;
                }
                
                if (trim($invoice) == '')
                {
                    $templates->setvar('error_invoice', $lang['E_INVOICE']);
                    $validator_error = false;
                }
                else
                {
                    $tickets = $objtickets->get_tickets("invoice_number = '$invoice' AND invoice_number <> '". $ticket_infor['invoice_number'] ."'", 0, 0);
                    if ($tickets)
                    {
                        $templates->setvar('error_invoice', $lang['E_INVOICE_EXISTS']);
                        $validator_error = false;
                    }
                }
                
                if (trim($office) == '')
                {
                    $templates->setvar('error_office', $lang['E_OFFICE']);
                    $validator_error = false;
                }
                
                if (trim($dispatch) == '')
                {
                    $templates->setvar('error_dispatch', $lang['E_DISPATCH']);
                    $validator_error = false;
                }
                if ($builder == '')
                {
                    $templates->setvar('error_builder', $lang['E_SELECT_BUILDER']);
                    $validator_error = false;
                }
                if (trim($client_name) == '')
                {
                    $templates->setvar('error_client_name', $lang['E_CLIENT_NAME']);
                    $validator_error = false;
                }
                
                if (trim($client_address) == '')
                {
                    $templates->setvar('error_client_address', $lang['E_CLIENT_ADDRESS']);
                    $validator_error = false;
                }
                if (trim($job_date) && !is_valid_date($job_date) )
                {
                    $templates->setvar('error_job_date_time', $lang['E_DATE']);
                    $validator_error = false;
                }
                if (trim($job_time_in) && !is_valid_time_custom($job_time_in) )
                {
                    $templates->setvar('error_job_date_time', $lang['E_TIME']);
                    $validator_error = false;
                }
                if (trim($job_time_out) )
                {
                    if (!is_valid_time_custom($job_time_out))
                    {
                        $templates->setvar('error_job_date_time', $lang['E_TIME']);
                        $validator_error = false;
                    }
                    else if (trim($job_time_in) && is_valid_time_custom($job_time_in) && strtotime($job_time_in) > strtotime($job_time_out) )
                    {
                        $templates->setvar('error_job_date_time', $lang['E_TIME_LESS_THAN']);
                        $validator_error = false;
                    }
                }
                if (trim($promised_date) && !is_valid_date($promised_date) )
                {
                    $templates->setvar('error_promised_date', $lang['E_DATE']);
                    $validator_error = false;
                }
                if (trim($promised_time_from) && !is_valid_time_custom($promised_time_from) )
                {
                    $templates->setvar('error_promised_time', $lang['E_TIME']);
                    $validator_error = false;
                }
                if (trim($promised_time_to) )
                {
                    if (!is_valid_time_custom($promised_time_to))
                    {
                        $templates->setvar('error_promised_time', $lang['E_TIME']);
                        $validator_error = false;
                    }
                    else if (trim($promised_time_from) && is_valid_time_custom($promised_time_from) && strtotime($promised_time_from) > strtotime($promised_time_to) )
                    {
                        $templates->setvar('error_promised_time', $lang['E_TIME_LESS_THAN_PROMISED']);
                        $validator_error = false;
                    }
                }
                if(strlen(trim($keymap))>6){
                    $templates->setvar('error_keymap', $lang['E_KEYMAP_MESSAGE']);
                    $validator_error = false;
                }
                $time_in ;
                if($job_time_in == ''){
                    $time_in = "";
                }else{
                    $time_in = date('H:i:s', strtotime($job_time_in));
                }
                $time_out ;
                if($job_time_out == ''){
                    $time_out = "";
                }else{
                    $time_out = date('H:i:s', strtotime($job_time_out));
                }
                $time_from ;
                if($promised_time_from == ''){
                    $time_from = "";
                }else{
                    $time_from = date('H:i:s', strtotime($promised_time_from));
                }
                $time_to ;
                if($promised_time_to == ''){
                    $time_to = "";
                }else{
                    $time_to = date('H:i:s', strtotime($promised_time_to));
                }
                
                if (trim($client_office_notes) != '')
                    $office_notes .= '<span>' . date('m/d/Y h:i A') . '</span><div>' . $client_office_notes . '</div>';
                if (trim($client_job_notes) != '')
                    $note .= '<span>' . date('m/d/Y h:i A') . '</span><div>' . $client_job_notes . '</div>';


                $save_ticket = array('status_service_id' => $status_service,
                                    'builder_id' => $builder,
                                    'type_id' => $type_id,
                                    'invoice_number' => $invoice,
                                    'office_number' => $office,
                                    'dispatch_id' => $dispatch,
                                    'job_date' => convert_to_standard_date($job_date),
                                    'job_time_in' => $time_in,
                                    'job_time_out' =>  $time_out,
                                    'keymap'  =>  $keymap,
                                    'assign_by' => $assign,
                                    'seller' => $seller,
                                    'client_name' =>$client_name,
                                    'client_address' =>$client_address,
                                    'client_city' =>$client_city,
                                    'client_state' =>$client_state,
                                    'client_zip' =>$client_zip,
                                    'client_phone' =>$client_phone,
                                    'field_notes' => $note,
                                    'office_notes'    =>  $office_notes,
                                    'promised_date' => convert_to_standard_date($promised_date),
                                    'promised_time_from' => $time_from ,
                                    'promised_time_to' => $time_to,
                                    'urgency'=>$urgency
                                    );
                if ($save_ticket['status_service_id'] == 3)
                {
                    $save_ticket['complete_date'] = date("Y-m-d");
                }
                $save_customer = array('full_name' => $client_name,
                                       'address' => $client_address,
                                       'city' => $client_city,
                                       'state' => $client_state,
                                       'zip' => $client_zip,
                                       'phone1' => $client_phone);
                
                
                
                if ($validator_error)
                {
                    //map customer to ticket
                    if (!$customer)
                    {
                        $customer_id = 0;
                        $customers = $objcustomers->check_exist_customer($save_customer);
                        if ($customers)
                        {
                            //customer exists
                            $customer_id = $customers[0]['customer_id'];
                        }
                        else
                        {
                            //insert new customer
                            $customer_id = $objcustomers->save('INSERT', $save_customer);
                        }
                        $save_ticket['customer_id'] = $customer_id;
                    }
                    else
                    {
                        $save_ticket['customer_id'] = $customer;
                        $objcustomers->save('UPDATE', $save_customer, " customer_id = $customer");
                    }
                    //get client email
                    $customer_infor = $objcustomers->get_customer_by_id($save_ticket['customer_id']);
                    $save_ticket['client_email'] = $customer_infor['email'];
                    //endmap customer to ticket
                    
					//update commission
					if ($ticket_infor['assign_by'] != $save_ticket['assign_by'] || $ticket_infor['seller'] != $save_ticket['seller'])
					{
                        //change user_id of ticket part
                        $objtickets->update_assign_ticket_part($id,$save_ticket['assign_by']);

                        $save_ticket['ticket_id'] = $id;
						$objtickets->updateCommission($save_ticket);
					}
                    //update ticket
                    $objtickets->save('UPDATE', $save_ticket, "ticket_id = $id");

                    //delete old problem
                    $objtickets->delete_problem($id);
                    //insert problem by ticket
                    if (isset($_POST['ticket_problem']) && $_POST['ticket_problem']) {
                        foreach ($_POST['ticket_problem'] as $problem)
                        {
                            $objtickets->save_problem($id, $problem);
                        }
                    }

                    if ($save_ticket['type_id'] == 1)
                    {
                        $objticketstype->deleteAll("ticket_id = $id");
                    }

                    
                    $templates->setvar('save_success', true);
                    
                    //send email to tech that assigned
                    if ($save_ticket['status_service_id'] == 2 && $save_ticket['assign_by'])
                    {
                        $ticket_infor = $objtickets->get_ticket_by_id($id);
                        $user_infor = $objuser->get_user_by_id($ticket_infor['assign_by']);
                        $subject = "ACS ticket #". $ticket_infor['ticket_id'] ." is assigned to you" .
                                        ($ticket_infor['job_date'] == '0000-00-00' ? '' : ' on ' . date('m/d/Y', strtotime($ticket_infor['job_date']) ) );
                        $msgbody = get_email_body($ticket_infor);
                        $email = $user_infor['email'];
                        $from = $config->configurations["ADMIN_EMAIL"];
                        send_mail($from, $email, $subject, $msgbody, true);
                    }
                    else if ($save_ticket['status_service_id'] == 16)
                    {
                        $from = $config->configurations["ADMIN_EMAIL"];
                        
                        $ticket_infor = $objtickets->get_ticket_by_id($id);                        
                        $subject = "ACS ticket #". $ticket_infor['ticket_id'] ." has been cashed out" .
                                        ($ticket_infor['job_date'] == '0000-00-00' ? '' : ' on ' . date('m/d/Y', strtotime($ticket_infor['job_date']) ) );
                        $msgbody = get_email_body($ticket_infor);
                        
                        //email to technician
                        $user_infor = $objuser->get_user_by_id($ticket_infor['assign_by']);
                        $email = $user_infor['email'];                        
                        send_mail($from, $email, $subject, $msgbody, true);
                        
                        //email to seller
                        if ($ticket_infor['seller'])
                        {
                            $user_infor = $objuser->get_user_by_id($ticket_infor['seller']);
                            $email = $user_infor['email'];
                            send_mail($from, $email, $subject, $msgbody, true);
                        }
                    }
                }
                else
                {
                    if ($customer)
                    {
                        $customer_infor = $objcustomers->get_customer_by_id($customer);
                        $builder_1 = $objbuilders->get_builder_by_id($customer_infor['builder_id_1']);
                        $builder_2 = $objbuilders->get_builder_by_id($customer_infor['builder_id_2']);
						$builder_3 = $objbuilders->get_builder_by_id($customer_infor['builder_id_3']);
						$builder_4 = $objbuilders->get_builder_by_id($customer_infor['builder_id_4']);

                        $builders = array();
                        if ($builder_1)
                            $builders[] = $builder_1;
                        if ($builder_2)
                            $builders[] = $builder_2;
						if ($builder_3)
                            $builders[] = $builder_3;
                        if ($builder_4)
                            $builders[] = $builder_4;
                        $templates->setvar('builders', $builders);
                    }
                    $save_ticket['customer_id'] = $customer;
                    $templates->setvar('ticket_infor', $save_ticket);
                }
            }
        }
    break;

    case "add":
        //get all problems
        $problems = $objproblem->getAllProblemsByParent(' actived=1', 'ordered', 'asc');
        $templates->setvar('problems', $problems);
        $templates->setvar('ticket_problems', array());
        
        //get service statuses
        $statuses_services = $objstatusservice->get_statuses('', 0, 0, 'status_service_name');
        $templates->setvar('statuses_services', $statuses_services);
        
        //get all builder for select
        $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
        $templates->setvar('builders', $builders);

        //get all ticket type
        $ticketstype = $objticketstype->get_ticketstype("t.ticket_id=0 AND t.created_by = {$user_global['user_id']}",0, 0,'created_date');
        $templates->setvar('ticketstype', $ticketstype);

        //get all customers
        if ($search_customers)
        {
            $whereClause = ' 1 ';
            $whereClause .= $search_name ? " AND c.full_name like \"%$search_name%\" " : '';
            $whereClause .= $search_address ? " AND c.address like \"%$search_address%\" " : '';
            $whereClause .= $search_city ? " AND c.city like \"%$search_city%\" " : '';
            $whereClause .= $search_state ? " AND c.state = '$search_state' " : '';
            $whereClause .= $search_zip ? " AND c.zip like \"%$search_zip%\" " : '';
            $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
            $templates->setvar('customers', $customers);
        }
        
        //get job status
        $jobstatuses = $objjobstatus->get_jobstatus("", 0, null);
        $templates->setvar('jobstatuses', $jobstatuses);
        //get state for select
        $states = $objstates->get_states('', 0, 0, 'state_code');
        $templates->setvar('states', $states);
        //get all user for assign
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);

        //get all ticket type for assign
        $type = $objtype->get_type('', 0, 0, 'type_name');
        $templates->setvar('type', $type);

        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            $objtickets->get_auto_office_id($office_id);
            $objtickets->get_auto_invoice_no_manual($invoice_number);

            $objticketstype->deleteAll("ticket_id = 0 AND created_by = {$user_global['user_id']}");
            
            $templates->setvar('ticket_infor', array('office_number' => $office_id,
                                                     'invoice_number' => 'R'.$invoice_number,
                                                     'job_date' => date('Y-m-d'),
                                                     'promised_date' => date('Y-m-d') ) );
        }
        else
        {
            $validator_error = true;
            if($builder == 20 || $builder == 33)
            //	$dispatch = $config->get_configuration("CURRENT_DISPATCH_ID") + 1;
            if($builder == 41 || $builder == 42){
            //	$dispatch = $config->get_configuration("CURRENT_DISPATCH_FINANCE_32_15") + 1;
              //  $dispatch = 'F'.$dispatch;
            }
            if($builder == 40 ){
            //	$dispatch = $config->get_configuration("CURRENT_DISPATCH_ACS_RETAIL18") + 1;
              //  $dispatch = 'A'.$dispatch;
            }
            if (!$ticketstype && $type_id != 1)
            {
                $templates->setvar('error_tickettype', $lang['E_TICKETTYPE']);
                $validator_error = false;
            }

            if (trim($invoice) == '')
            {
                $templates->setvar('error_invoice', $lang['E_INVOICE']);
                $validator_error = false;
            }
            else
            {
                $tickets = $objtickets->get_tickets("invoice_number = '$invoice'", 0, 0);
                if ($tickets)
                {
                    $templates->setvar('error_invoice', $lang['E_INVOICE_EXISTS']);
                    $validator_error = false;
                }
            }
            
            if (trim($office) == '')
            {
                $templates->setvar('error_office', $lang['E_OFFICE']);
                $validator_error = false;
            }
            
            if (trim($dispatch) == '')
            {
                $templates->setvar('error_dispatch', $lang['E_DISPATCH']);
                $validator_error = false;
            }
            //else{
//                $check_dispatch=$objtickets->check_dispatch_id($dispatch);
//                if($check_dispatch){
//                    $templates->setvar('error_dispatch_duplicate', $lang['E_DISPATCH_DUPLICATE']);
//                    $validator_error = false;
//                }
         //   }
            if ($builder == '')
            {
                $templates->setvar('error_builder', $lang['E_SELECT_BUILDER']);
                $validator_error = false;
            }
            if (trim($client_name) == '')
            {
                $templates->setvar('error_client_name', $lang['E_CLIENT_NAME']);
                $validator_error = false;
            }
            
            if (trim($client_address) == '')
            {
                $templates->setvar('error_client_address', $lang['E_CLIENT_ADDRESS']);
                $validator_error = false;
            }
            
            if (trim($job_date) && !is_valid_date($job_date) )
            {
                $templates->setvar('error_job_date_time', $lang['E_DATE']);
                $validator_error = false;
            }
            elseif (trim($job_time_in) && !is_valid_time($job_time_in) )
            {
                $templates->setvar('error_job_date_time', $lang['E_TIME']);
                $validator_error = false;
            }
            elseif (trim($job_time_out) )
            {
                if (!is_valid_time($job_time_out))
                {
                    $templates->setvar('error_job_date_time', $lang['E_TIME']);
                    $validator_error = false;
                }
                else if (trim($job_time_in) && is_valid_time($job_time_in) && strtotime($job_time_in) > strtotime($job_time_out) )
                {
                    $templates->setvar('error_job_date_time', $lang['E_TIME_LESS_THAN']);
                    $validator_error = false;
                }
            }
            
            if (trim($promised_date) && !is_valid_date($promised_date) )
            {
                $templates->setvar('error_promised_date', $lang['E_DATE']);
                $validator_error = false;
            }
            elseif (trim($promised_time_from) && !is_valid_time($promised_time_from) )
            {
                $templates->setvar('error_promised_time', $lang['E_TIME']);
                $validator_error = false;
            }
            elseif (trim($promised_time_to) )
            {
                if (!is_valid_time($promised_time_to))
                {
                    $templates->setvar('error_promised_time', $lang['E_TIME']);
                    $validator_error = false;
                }
                else if (trim($promised_time_from) && is_valid_time($promised_time_from) && strtotime($promised_time_from) > strtotime($promised_time_to) )
                {
                    $templates->setvar('error_promised_time', $lang['E_TIME_LESS_THAN_PROMISED']);
                    $validator_error = false;
                }
            }
           
            if(strlen(trim($keymap))>6){
                $templates->setvar('error_keymap', $lang['E_KEYMAP_MESSAGE']);
                $validator_error = false;
            }
            
            $time_in ;
            if($job_time_in == ''){
                $time_in = "";
            }else{
                $time_in = date('H:i:s', strtotime($job_time_in));
            }
            $time_out ;
            if($job_time_out == ''){
                $time_out = "";
            }else{
                $time_out = date('H:i:s', strtotime($job_time_out));
            }
            $time_from ;
            if($promised_time_from == ''){
                $time_from = "";
            }else{
                $time_from = date('H:i:s', strtotime($promised_time_from));
            }
            $time_to ;
            if($promised_time_to == ''){
                $time_to = "";
            }else{
                $time_to = date('H:i:s', strtotime($promised_time_to));
            }
            
            if (trim($client_office_notes) != '')
                $office_notes .= '<span>' . date('m/d/Y h:i A') . '</span><div>' . $client_office_notes . '</div>';
            if (trim($client_job_notes) != '')
                $note .= '<span>' . date('m/d/Y h:i A') . '</span><div>' . $client_job_notes . '</div>';

            $save_ticket = array('status_service_id' => $status_service,
                                'builder_id' => $builder,
                                'type_id' => $type_id,
                                'invoice_number' => $invoice,
                                'office_number' => $office,
                                'dispatch_id' => $dispatch,
                                'job_date' => convert_to_standard_date($job_date),
                                'job_time_in' => $time_in,
                                'job_time_out' => $time_out ,
                                'status' => 1,
                                'keymap'  =>  $keymap,
                                'created_date' => date('Y-m-d H:i:s'),
                                'posted_by' => $authenticate->get_user_id(),
                                'assign_by' => $assign,
                                'seller' => $seller,
                                'client_name' =>$client_name,
                                'client_address' =>$client_address,
                                'client_city' =>$client_city,
                                'client_state' =>$client_state,
                                'client_zip' =>$client_zip,
                                'client_phone' =>$client_phone,
                                'field_notes' => $note,
                                'office_notes'  =>  $office_notes,
                                'promised_date' => convert_to_standard_date($promised_date),
                                'promised_time_from' =>  $time_from,
                                'promised_time_to' => $time_to,
                                 'urgency'=>$urgency
                                );
            if ($save_ticket['status_service_id'] == 3)
            {
                $save_ticket['complete_date'] = date("Y-m-d");
            }
            	
            $save_customer = array(
                                   'full_name' => $client_name,
                                   'address' => $client_address,
                                   'city' => $client_city,
                                   'state' => $client_state,
                                   'zip' => $client_zip,
                                   'phone1' => $client_phone);
            
            if ($validator_error)
            {
                //////
                if($builder == 20 || $builder == 33)
                {
                    $updateCurrentDispatch = array("value" => $config->get_configuration("CURRENT_DISPATCH_ID") + 1);
                    $config->save_config("UPDATE", $updateCurrentDispatch, " config_key = 'CURRENT_DISPATCH_ID'");
                }
                if($builder == 41 || $builder == 42)
                {
                   // $check_dispatch=$objtickets->check_dispatch_id($dispatch);
                    $updateCurrentDispatch = array("value" => $config->get_configuration("CURRENT_DISPATCH_FINANCE_32_15") + 1);
                    $config->save_config("UPDATE", $updateCurrentDispatch, " config_key = 'CURRENT_DISPATCH_FINANCE_32_15'");
                }
                if($builder == 40)
                {
                    $updateCurrentDispatch = array("value" => $config->get_configuration("CURRENT_DISPATCH_ACS_RETAIL18") + 1);
                    $config->save_config("UPDATE", $updateCurrentDispatch, " config_key = 'CURRENT_DISPATCH_ACS_RETAIL18'");
                }
                /////
                //map customer to ticket
                if (!$customer)
                {
                    $customer_id = 0;
                    $customers = $objcustomers->check_exist_customer($save_customer);
                    if ($customers)
                    {
                        //customer exists
                        $customer_id = $customers[0]['customer_id'];
                    }
                    else
                    {
                        //insert new customer
                        $save_customer['builder_id_1'] = $builder;
                        $customer_id = $objcustomers->save('INSERT', $save_customer);
                    }
                    $save_ticket['customer_id'] = $customer_id;
                }
                else
                {
                    $save_ticket['customer_id'] = $customer;
                    $objcustomers->save('UPDATE', $save_customer, " customer_id = $customer");
                }
                //get client email
                $customer_infor = $objcustomers->get_customer_by_id($save_ticket['customer_id']);
                $save_ticket['client_email'] = $customer_infor['email'];
                //endmap customer to ticket
                
                //insert new ticket                
                $ticket_id = $objtickets->save('INSERT', $save_ticket);

                $objticketstype->updateRecallInfo($ticket_id,$save_ticket);

                $objticketstype->save("UPDATE",array("ticket_id"=>$ticket_id),"ticket_id = 0 AND created_by = {$user_global['user_id']}");

                //set user ticket part
                $objtickets->update_assign_ticket_part($ticket_id,$save_ticket['assign_by']);


                //update commission
				$save_ticket['ticket_id'] = $ticket_id;
				$objtickets->updateCommission($save_ticket);
					
                //insert problem by ticket
                if ($_POST['ticket_problem'])
                    foreach ($_POST['ticket_problem'] as $problem)
                        $objtickets->save_problem($ticket_id, $problem);
                
                $templates->setvar('save_success', true);
                
                //send email to tech that assigned
                if ($save_ticket['status_service_id'] == 2 && $save_ticket['assign_by'])
                {
                    $ticket_infor = $objtickets->get_ticket_by_id($ticket_id);
                    $user_infor = $objuser->get_user_by_id($ticket_infor['assign_by']);
                    $subject = "ACS ticket #". $ticket_infor['ticket_id'] ." is assigned to you" .
                                ($ticket_infor['job_date'] == '0000-00-00' ? '' : ' on ' . date('m/d/Y', strtotime($ticket_infor['job_date']) ) );
                    $msgbody = get_email_body($ticket_infor);
                    $email = $user_infor['email'];
                    $from = $config->configurations["ADMIN_EMAIL"];
                    send_mail($from, $email, $subject, $msgbody, true);
                }

            }
            else
            {
                if ($customer)
                {
                    $customer_infor = $objcustomers->get_customer_by_id($customer);
                    $builder_1 = $objbuilders->get_builder_by_id($customer_infor['builder_id_1']);
                    $builder_2 = $objbuilders->get_builder_by_id($customer_infor['builder_id_2']);
					$builder_3 = $objbuilders->get_builder_by_id($customer_infor['builder_id_3']);
					$builder_4 = $objbuilders->get_builder_by_id($customer_infor['builder_id_4']);

                    $builders = array();
                    if ($builder_1)
                        $builders[] = $builder_1;
                    if ($builder_2)
                        $builders[] = $builder_2;
                    if ($builder_3)
                        $builders[] = $builder_3;
				    if ($builder_4)
                        $builders[] = $builder_4;

                    $templates->setvar('builders', $builders);
                }
                $save_ticket['customer_id'] = $customer;
                $templates->setvar('ticket_infor', $save_ticket);
            }
        }
    break;

    case "details":
        if ($id)
        {
            //get ticket informtion
            $ticket_infor = $objtickets->get_ticket_by_id($id);
            
            $status_service = $objstatusservice->get_status_by_id($ticket_infor['status_service_id']);
            $ticket_infor['status_service_name'] = $status_service['status_service_name'];
            
            $builder = $objbuilders->get_builder_by_id($ticket_infor['builder_id']);
            $ticket_infor['builder_name'] = $ticket_infor['builder_id'] ? $builder['full_name'] : $lang['L_RESALES'];
            
            $status = $objticketstatus->get_status_by_id($ticket_infor['status']);
            $ticket_infor['ticket_status'] = $status['status_name'];
            
            $user = $objuser->get_user_by_id($ticket_infor['posted_by']);
            $ticket_infor['posted_by'] = $user['first_name'] . ' ' . $user['last_name'];
            
            $user = $objuser->get_user_by_id($ticket_infor['assign_by']);
            $ticket_infor['assign_by'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : $lang['L_NONE'];
            
            $user = $objuser->get_user_by_id($ticket_infor['seller']);
            //get ticket type for assign
            $ticket_infor['seller'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : $lang['L_NONE'];
            $ticket_infor['type_name'] = $objtype->get_type_by_id($ticket_infor['type_id']);
            $ticket_infor['type_name'] = $ticket_infor['type_name']['type_name'];

            //get all ticket type
            $ticketstype = $objticketstype->get_ticketstype("t.ticket_id={$id}",0, 0,'created_date');
            $templates->setvar('ticketstype', $ticketstype);

            //get problem of ticket
            $problems = $objproblem->getAllProblemsByParent();
            $templates->setvar('problems', $problems);
            $ticket_infor['problems'] = $objtickets->get_ticket_problems($id);
            $countProblems = count($objtickets->get_ticket_problems_by_parent($myticketid, 0) );

            
            $templates->setvar('ticket_infor', $ticket_infor);
            $templates->setvar("size_problems", $countProblems);

        }
    break;
    case "manage_po":
        $invoice = $objtickets->get_invoice_by_ticket_id2($id);
        $orders = $objtickets->get_po_by_invoice_sort($invoice,request_var('sortfield','purchased_order_id'), request_var('sortby', 'desc'));
        foreach($orders as $entry){
            if($entry['pending']==1){
                $templates->setvar('pending_po',1);
            }
        }
        $where_clause = "po.invoice_number = '".$invoice ."'";
        $templates->setvar('total_po', $objlaborsparts->get_summary_po($where_clause));
        $templates->setvar('orders', $orders);
        //$templates->setvar('back_page',$_SERVER['HTTP_REFERER']);

    break;
    case "detail_po":

        $po_parts=$objpurchaseditem->get_items_by_order($po_id);
        $templates->setvar('po_parts',$po_parts);
        $order_infor = $objorder->get_order_by_id($po_id);
        $total_part="";
        foreach ($po_parts as $entry)
        {
            $entry['unit_cost'] = $entry['price'];
            $total_part+=$entry['price']*$entry['quantity'];
        }
        $received_date_edit = date('m/d/Y', strtotime(str_replace('-', '/', $order_infor['received_date'])));
        $templates->setvar('po_id',$po_id);
        $templates->setvar('received_date',$received_date_edit);
        $templates->setvar('purchase_by',$objuser->get_username_by_id($order_infor['purchased_by_id']));
        $templates->setvar('approved_by',$objuser->get_username_by_id($order_infor['approved_by_id']));
        $templates->setvar('load_to',$objuser->get_username_by_id($order_infor['user_id']));
        $templates->setvar('order_infor', $order_infor);
        $templates->setvar('vendor',$objvendors->get_vendor_name_by_id($order_infor['vendor_id']));
        $templates->setvar('total_part',$total_part);
        $templates->setvar('back_page',$_SERVER['HTTP_REFERER']);



        break;
    case "submit_po":

        $objorder->update_pending(0,$po_id);
        $order = $objorder->get_order_by_id($po_id);
        $user = $order['user_id'];

        $invoice= $objorder->get_invoice_by_po($po_id);
        $ticketid = $objtickets->get_ticket_id_by_invoice2($invoice);
        $po_parts = $objpurchaseditem->get_items_by_order($po_id);

        $total_part="";
        foreach ($po_parts as $entry)
        {
            $entry['unit_cost'] = $entry['price'];

            $total_part+=$entry['price']*$entry['quantity'];

            if($order['vendor_id']==139){
                $objinventory->update_quantity_warehourse(-$entry['quantity'], $entry['labor_part_id']);
            }
            $part_infor = $objlaborsparts->get_labor_part_by_id($entry['labor_part_id']);
            $customer_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['customer_mark_up'] / 100);
            $tech_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100);
            $save_ticket_part = array('ticket_id' => $ticketid,
                'user_id' => $user,
                'labor_part_id' => $entry['labor_part_id'],
                'quantity' => $entry['quantity'],
                'price' => $customer_price,
                'tech_price' => $tech_price,
                'purchased_item_id' => $entry['purchased_item_id'],
                'created_date' => date('Y-m-d') );
            $part_exists = $objtickets->get_ticket_part_exists($user, $ticketid, $entry['labor_part_id']);

            if ($part_exists)
                $objtickets->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] + $entry['quantity']),
                    ' ticket_part_id=' . $part_exists['ticket_part_id']);
            else
                $objtickets->update_ticket_part('INSERT', $save_ticket_part);
        }
       // die();

        redirect('createtickets.php?mode=manage_po&id='.$ticketid);

        break;
    case "commitall":
        $invoice = $objtickets->get_invoice_by_ticket_id2($id);
        $po = $objorder->get_po_by_invoice($invoice,'S',1);


        foreach ($po as $entry_po)
        {
            $objorder->update_pending(0,$entry_po['purchased_order_id']);
            $po_parts = $objpurchaseditem->get_items_by_order($entry_po['purchased_order_id']);
            $user = $entry_po['user_id'];
            $ticketid=$id;
            $total_part="";
            foreach ($po_parts as $entry)
            {
                $entry['unit_cost'] = $entry['price'];

                $total_part+=$entry['price']*$entry['quantity'];

                if($entry_po['vendor_id']==139){
                    $objinventory->update_quantity_warehourse(-$entry['quantity'], $entry['labor_part_id']);
                }
                $part_infor = $objlaborsparts->get_labor_part_by_id($entry['labor_part_id']);
                $customer_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['customer_mark_up'] / 100);
                $tech_price = $part_infor['unit_cost'] + ($part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100);
                $save_ticket_part = array('ticket_id' => $ticketid,
                    'user_id' => $user,
                    'labor_part_id' => $entry['labor_part_id'],
                    'quantity' => $entry['quantity'],
                    'price' => $customer_price,
                    'tech_price' => $tech_price,
                    'purchased_item_id' => $entry['purchased_item_id'],
                    'created_date' => date('Y-m-d') );
                $part_exists = $objtickets->get_ticket_part_exists($user, $ticketid, $entry['labor_part_id']);

                if ($part_exists)
                    $objtickets->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] + $entry['quantity']),
                        ' ticket_part_id=' . $part_exists['ticket_part_id']);
                else
                    $objtickets->update_ticket_part('INSERT', $save_ticket_part);
            }

        }

        redirect('createtickets.php?mode=manage_po&id='.$id);
        break;
    case "delete_po":
        $objorder->delete($po_id);
        $objpurchaseditem->deleteByOrder($po_id);
        redirect($_SERVER['HTTP_REFERER']);
        //delete part into service ticket
        /*
        $po_parts = $objpurchaseditem->get_items_by_order($po_id);
        $invoice= $objorder->get_invoice_by_po($po_id);
        $ticketid = $objtickets->get_ticket_id_by_invoice2($invoice);

        foreach($po_parts as $entry)
        {

            $part_exists = $objticket->get_ticket_part_exists($user, $ticketid, $entry['labor_part_id']);
            // var_dump($ticket_id);
            $invoice_numbers = $objticket->get_invoice_by_ticket_id($ticket_id);
            $invoice_number = $invoice_numbers['invoice_number'];
            $part_track_exists =$objticket->get_track_ticket_part_exits($invoice_number,$entry['labor_part_id']);

            if ($part_exists){
                $objticket->update_ticket_part('UPDATE', array('quantity' => $part_exists['quantity'] - $entry['quantity']),
                    ' ticket_part_id=' . $part_exists['ticket_part_id']);
                $objticket->delete_quantity_zero();
            }else{
                if ($inventory)// if isset inventory true -> update
                {
                    $objinventory->save('UPDATE', array('quantity' => $quantity_away, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);

                    //  $quantity_inventory = $inventory['quantity']-$entry[];
                    //  $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);

                }

            }
        }*/
        break;
    case "add_note_po":
        $notes = request_var('note_po','');
        $id_po = request_var('id','');
        $order_infor = $objorder->get_order_by_id($id_po);
        if (trim($notes) != ''){

            $note .=$order_infor['notes']. '<span>' . date('m/d/Y h:i A') .':'. '</span><div>' . $notes . '</div>';
        }
        $save_order=array('notes' => $note);
        $objorder->save('UPDATE', $save_order, " purchased_order_id = $id_po");
        //echo $id_po;
        break;
    case "save_note_po" :
        $text = request_var('text', '');
        $save_order = array('notes' => str_replace(array('[{1}]', '[{2}]'), array('#', '&') , $text) );
        $objorder->save('UPDATE', $save_order, " purchased_order_id = $id");

        return;
        break;
    case "delete":
        if ($id)
        {
            $part_info = $objtickets->get_ticket_part_by_ticket_id($id);

            foreach($part_info as $key)
            {
                $ticket_part = $objtickets->get_ticket_part_by_id($key['ticket_part_id']);
               // var_dump($ticket_part);
                $new_quantity = $ticket_part['quantity'];
                $user_tech_ids=$objtickets->get_user_tech_by_ticket_id($id);
                //echo $objtickets->sql;
                $user_tech_id =$user_tech_ids['user_id'];

                $where_clause = " 1 AND i.labor_part_id = ". $ticket_part['labor_part_id'] ." and i.user_id = " . $user_tech_id;

               // var_dump($user_tech_ids);
                $inventories = $objinventory->get_inventories($where_clause, 0, 0);

                $inventory = $inventories[0];
               // var_dump($inventories);
                if ($inventory)// if isset inventory true -> update
                {
                    $quantity_inventory = $new_quantity + $inventory['quantity'];
                    $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);

                }
                else// if isset inventory false -> add
                {

                    $save_inventory = array('user_id' => $user_tech_id,
                        'labor_part_id' => $ticket_part['labor_part_id'],
                        'quantity' => $new_quantity,
                        'actived_date' => date('Y-m-d') );

                    $objinventory->save('INSERT', $save_inventory);

                }

            }


        	//delete settle
        	$ticket_infor = $objtickets->get_ticket_by_id($id);
        	$objsettletickets= new dbsettletickets();        	
        	$objsettletickets->delete($ticket_infor["invoice_number"]);

            //delete track part
            $objinventory->delete_track_part($ticket_infor["invoice_number"]);

            //delete order by invoice
            $orders = $objorder->getOrdersByInvoice($ticket_infor["invoice_number"]);
            foreach ($orders as $order)
            {
                $objorder->delete($order['purchased_order_id']);
                $objpurchaseditem->deleteByOrder($order['purchased_order_id']);
            }

            //delete ticket            
            $objtickets->delete($id);            
            $templates->setvar('delete_success', true);
        }
    break;

    case "get_information_customer":
        $customer_id = request_var('customer_id', '');
		$builders = array();
        if ($customer_id)
        {
            $customer = $objcustomers->get_customer_by_id($customer_id);
            
            $builder_1 = $objbuilders->get_builder_by_id($customer['builder_id_1']);
            $builder_2 = $objbuilders->get_builder_by_id($customer['builder_id_2']);
			$builder_3 = $objbuilders->get_builder_by_id($customer['builder_id_3']);
			$builder_4 = $objbuilders->get_builder_by_id($customer['builder_id_4']);
			if ($builder_1) $builders[] = $builder_1;
			if ($builder_2) $builders[] = $builder_2;
			if ($builder_3) $builders[] = $builder_3;
			if ($builder_4) $builders[] = $builder_4;
        }
        
        $string_builder = '';
        if (count($builders) > 1)
            $string_builder .= '<option value="">'. $lang['L_SELECT_A_BUILDER'] .'</option>';
			
		foreach ($builders as $entry)
			$string_builder .= '<option value="'. $entry['builder_id'] .'">'. $entry['full_name'] .'</option>';
        
        if (!$string_builder && $customer_id == '')
        {
            $string_builder .= '<option value="">'. $lang['L_SELECT_A_BUILDER'] .'</option>';            
            $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
            foreach ($builders as $builder)
            {
                $string_builder .= '<option value="'. $builder['builder_id'] .'">'. $builder['full_name'] .'</option>';
            }
        }
        
        echo htmlspecialchars_decode(trim($customer['full_name']) . ';' . trim($customer['address']) . ';' . trim($customer['city']) . ';' .
                trim($customer['state']) . ';' . trim($customer['zip']) . ';' . trim($customer['phone1']) . ';' . $string_builder);
        
        return;
    break;

    case "get_information_builder":
        $builder_id = request_var('builder_id', '');
        $action = request_var('action', '');
        $id = request_var('id', '');
        if ($action == 'get_dispatch')
        {
            
            if (!$id)
            {
                if ($builder_id == 20 || $builder_id == 33)
                {
                    $dispatch_id = $config->get_configuration("CURRENT_DISPATCH_ID") + 1;                
                    echo $dispatch_id;
                }elseif($builder_id== 41|| $builder_id==42)
                {
                    $dispatch_id = $config->get_configuration("CURRENT_DISPATCH_FINANCE_32_15") + 1;
  //                  $F_dispatch = 'F'.$dispatch_id;
//                    $check_dispatch=$objtickets->check_dispatch_id($F_dispatch);
//                    if($check_dispatch){
//                        $dispatch_id =$dispatch_id +1;
//                        $config->save_config("UPDATE",  array("value" =>$dispatch_id), " config_key = 'CURRENT_DISPATCH_FINANCE_32_15'");
//                    }
                    echo 'F'.$dispatch_id;

                }elseif($builder_id==40){
                    $dispatch_id = $config->get_configuration("CURRENT_DISPATCH_ACS_RETAIL18") + 1;
                    echo 'A'.$dispatch_id;

                }
            }
            else
            {
                $ticket_info = $objtickets->get_ticket_by_id($id);
                
            	if ($builder_id == 20 || $builder_id == 33)
                {
                    $dispatch_id = $config->get_configuration("CURRENT_DISPATCH_ID") + 1;
                    echo $dispatch_id;
                }
                elseif($builder_id== 41|| $builder_id==42)
                {
                    $dispatch_id = $config->get_configuration("CURRENT_DISPATCH_FINANCE_32_15") + 1;
                    echo 'F'.$dispatch_id;

                }elseif($builder_id==40){
                    $dispatch_id = $config->get_configuration("CURRENT_DISPATCH_ACS_RETAIL18") + 1;
                    echo 'A'.$dispatch_id;

                }else
                {
                    echo $ticket_info['dispatch_id'];
                }
            }
            
        }
        else
        {
            if ($builder_id)
            {
                $builder = $objbuilders->get_builder_by_id($builder_id);
                echo $builder['office_number'];
            }
            else
            {
                $objtickets->get_auto_office_id($office_id);
                echo $office_id;
            }
        }
        return;
    break;

    case "get_customers" :
        $whereClause = ' 1 ';
        $whereClause .= $search_name ? " AND c.full_name like \"%$search_name%\" " : '';
        $whereClause .= $search_address ? " AND c.address like \"%$search_address%\" " : '';
        $whereClause .= $search_city ? " AND c.city like \"%$search_city%\" " : '';
        $whereClause .= $search_state ? " AND c.state = '$search_state' " : '';
        $whereClause .= $search_zip ? " AND c.zip like \"%$search_zip%\" " : '';
        $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
        $html = '<select id="customer" name="customer" class="select" style="width:100%" onchange="get_information_customer(this)">';
        $html .= '<option value="">'. $lang['L_SELECT_A_CUSTOMER_NAME'] .'</option>';
        if ($customers)
        {
            foreach ($customers as $customer)
            {
                $html .= '<option value="'. $customer['customer_id'] .'">'.
                                truncate_text($customer['full_name'], 50) . ' ('. $customer['address'] . ', ' . $customer['city'] . ', ' . $customer['state'] . ', ' . $customer['phone1'] .')' .
                         '</option>'; 
            }
        }
        $html .= '</select>';
        echo $html;
        return;
    break;

    case "save_note" :
        $text = request_var('text', '');
        $type = request_var('type', '');
        if ($type == 'note') $type = 'field_notes';
        
        $save_ticket = array($type => str_replace(array('[{1}]', '[{2}]'), array('#', '&') , $text) );
        $objtickets->save('UPDATE', $save_ticket, " ticket_id = $ticket_id");
        
        return;
    break;
    case "changeticketstatus":
    	$ticketname = request_var("ticketname", "");
    	$statusid = request_var("statusid", "");
    	if ($ticketname != "" && $statusid != "")
    	{
    		$tempID = substr($ticketname, strpos($ticketname, 'action'));
    		$ticketid = substr($tempID, strpos($ticketname, '_') + 1 );
    		$updateArr = array("status_service_id" => $statusid);
			$objtickets->save("UPDATE", $updateArr, " ticket_id = " . $objtickets->escape($ticketid)); 
			echo $objtickets->sql;
    	}	
    break;

    case "save_type" :
        $ticket_id = request_var('ticket_id', '');
        $user_id = request_var('user_id', '');
        $date_recall = request_var('date_recall', '');
        $history = request_var('history', '');

        $save_type = array(
            'ticket_id'=>$ticket_id,
            'user_id'=>$user_id,
            'date_recall'=>convert_to_standard_date($date_recall),
            'history'=>$history,
            'created_by'=>$user_global['user_id'],
            'created_date'=>date("Y-m-d H:I:F")

        );

        echo $objticketstype->save('INSERT', $save_type);

        return;
        break;

    case "delete_type" :
        $id = request_var('id', '');
        $objticketstype->delete($id);

        return;
        break;
}
$templates->setvar('ticket_status', $ticket_status);
//show template
$templates->show('createtickets.tpl');
//echo $objtickets->sql;

function get_email_body($ticket_infor)
{
    global $objbuilders, $objuser, $objtickets, $objproblem;
    
    $builder = $objbuilders->get_builder_by_id($ticket_infor['builder_id']);
    $ticket_infor['builder_name'] = $ticket_infor['builder_id'] ? $builder['full_name'] : $lang['L_RESALES'];
        
    $user = $objuser->get_user_by_id($ticket_infor['assign_by']);
    $ticket_infor['assign_by'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : $lang['L_NONE'];
    
    $user = $objuser->get_user_by_id($ticket_infor['seller']);
    $ticket_infor['seller'] = $user ? $user['first_name'] . ' ' . $user['last_name'] : $lang['L_NONE'];    
    
    $problems = $objtickets->get_problems_with_name_by_ticket($ticket_infor['ticket_id']);
    $ticket_infor['problems'] = $problems;

    $problems = $objproblem->getAllProblemsByParent();
    $ticket_infor['problems'] = $objtickets->get_ticket_problems($ticket_infor['ticket_id']);
    
    $body = '';
    
    $body .= '
        <table width="100%" border="0" cellpadding="5" cellspacing="1">
            <tr>
                <td style="background-color:#eee;padding:0 5px;width:140px"><div style="white-space:nowrap">Ticket Created Date</div></td>
                <td colspan="5">'. date('m/d/Y', strtotime($ticket_infor['created_date'])) .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Invoice #:</td>
                <td colspan="5">'. $ticket_infor['invoice_number'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Office #:</td>
                <td colspan="5">'. $ticket_infor['office_number'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Dispatch ID:</td>
                <td colspan="5">'. $ticket_infor['dispatch_id'] .'&nbsp;</td>
            </tr>
            <tr><td colspan="6"><hr style="margin:1px 0;border-color: #CFCFCF;" /></td></tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Builder:</td>
                <td colspan="5">'. $ticket_infor['builder_name'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Customer Name:</td>
                <td colspan="5">'. $ticket_infor['client_name'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Customer Address:</td>
                <td colspan="5">'. $ticket_infor['client_address'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Customer City:</td>
                <td>'. $ticket_infor['client_city'] .'</td>
                <td style="background-color:#eee;padding:0 5px;width:50px">State:</td>
                <td>'. $ticket_infor['client_state'] .'</td>
                <td style="background-color:#eee;padding:0 5px;width:50px">Zip:</td>
                <td>'. $ticket_infor['client_zip'] .'</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Customer Phone:</td>
                <td colspan="5">'. $ticket_infor['client_phone'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Keymap number:</td>
                <td colspan="5">'. $ticket_infor['keymap'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Problems:</td>
                <td colspan="5">';

            if ($ticket_infor['problems'])
            {
                foreach ($problems as $problem)
                {
                    if (in_array($problem['problem_id'], $ticket_infor['problems']) )
                    {
                        $body .= '<div>';
                        $body .= $problem['problem_name'];
                        $index = 0;
                        foreach ($problem['sub'] as $problem_sub)
                        {
                            if (in_array($problem_sub['problem_id'], $ticket_infor['problems']) )
                            {
                                $body .= ($index > 0 ? ', ' : ' ') . $problem_sub['problem_name'];
                                $index++;
                            }
                        }
                        $body .= '</div>';
                    }
                }
            }

            $body .= '&nbsp;</td>
            </tr>
            <tr><td colspan="6"><hr style="margin:1px 0;border-color: #CFCFCF;" /></td></tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Job notes:</td>
                <td colspan="5">';
                
            $fieldNotes = html_entity_decode($ticket_infor['field_notes']);
            $fieldNotes = str_replace('<span>', '<span style="float:left;font-weight:bold;">', $fieldNotes);
            $fieldNotes = str_replace('<div>', '<div style="padding-left:150px;color:#444;padding-bottom:5px;">', $fieldNotes);
            
            $body .= $fieldNotes;
                
            $body .= '&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Job Date:</td>
                <td colspan="5">'. ($ticket_infor['job_date'] == '0000-00-00' ? '' : date('m/d/Y', strtotime($ticket_infor['job_date'])) ) .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Assigned Tech:</td>
                <td colspan="5">'. $ticket_infor['assign_by'] .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Reseller:</td>
                <td colspan="5">'. $ticket_infor['seller'] .'&nbsp;</td>
            </tr>
            <tr><td colspan="6"><hr style="margin:1px 0;border-color: #CFCFCF;" /></td></tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px">Promised Date:</td>
                <td colspan="5">'. ($ticket_infor['promised_date'] == '0000-00-00' ? '' : date('m/d/Y', strtotime($ticket_infor['promised_date'])) ) .'&nbsp;</td>
            </tr>
            <tr>
                <td style="background-color:#eee;padding:0 5px"><div style="white-space:nowrap">Promised Time From:</div></td>
                <td>'. ($ticket_infor['promised_time_from'] == '00:00:00' ? '' : date('h:i A', strtotime($ticket_infor['promised_time_from']) ) ) .'</td>
                <td colspan="4">To: '. ($ticket_infor['promised_time_to'] == '00:00:00' ? '' : date('h:i A', strtotime($ticket_infor['promised_time_to']) ) ) .'&nbsp;</td>
            </tr>
        </table>
    ';
    return $body;
}

function refeshGoogleMap($ticketList, $statusList)
{
	global $configuration, $lang, $objstatusservice;
	//var_dump($ticketList);
	$script = "<script type=\"text/javascript\">

			function load() 
			{
			    if (GBrowserIsCompatible())
			    {
			        var map = new GMap2(document.getElementById(\"map\"));
			        map.addControl(new GSmallMapControl());
			        map.addControl(new GMapTypeControl());
			        map.setCenter(new GLatLng(29.7601927, -95.3693896), 10); 
			
			        // Creates a marker at the given point with the given number label
			        function createMarker(point, StoreInfo, type, char) {
			        	var baseurl = 'imagegen.php?src=';	
			        	var baseIcon = new GIcon(G_DEFAULT_ICON);
				       	var letteredIcon = new GIcon(baseIcon);
				       	letteredIcon.iconSize = new GSize(27, 27);
					    letteredIcon.image = baseurl + \"images%2F\" + type + \".png&character=\" + char;
					    //letteredIcon.image = \"images/\" + type + \".png\";
				   	 	// Set up our GMarkerOptions object
				   	  	markerOptions = { icon:letteredIcon };
			       		var marker = new GMarker(point, markerOptions);
		        		GEvent.addListener(marker, \"mouseover\", function() {
				        	marker.openInfoWindowHtml(StoreInfo);
			        	});
			        	return marker;
			        }
			        var point;";
					
			       foreach ($ticketList as $entry)
			       {
				       $script .= "         
				        var address = '<b>Dispatch No.: " . $entry['dispatch_id'] ."<br />Customer: " .$entry['customer_name'] . "<br />' +
				        			'Phone: " . $entry['customer_phone'] . "<br /><span style=\"color: #ff0000\">Status: " . ServiceStatusDropdown($entry['status_service_id'], $entry['ticket_id']) . "</span></b> &nbsp; ' + 
				        			'<a href=\"tickets.php?ticketid=" . $entry['ticket_id'] . "\"><img src=\"templates/default/fe/images/select.png\" alt=\"Select\" title=\"Select Ticket\" /></a> ' +
				        	        '<a href=\"createtickets.php?mode=details&id=" . $entry['ticket_id']  . "\"><img src=\"templates/default/fe/images/view.png\" alt=\"Details\" title=\"Details\" /></a> ' +
				        	        '<a href=\"createtickets.php?mode=edit&id=" . $entry['ticket_id']  . "\"><img src=\"templates/default/fe/images/edit.png\" alt=\"Edit\" title=\"Edit\" /></a> ' +";
				       
				        	        if ($entry['assign_name'] != "") 
				        	        	$script .= "'<br><b>Assigned to:  " . $entry['assign_name'] . "</b>' + ";

				        	        	
				        	        if ($entry['promised_time_from']) 
				        	        	$script .= "'<br /><b>Promised Time:</b>" . date("h:i A", strtotime($entry['promised_time_from'])). " - ' + ";
				        	        else 
				        	        	$script .= "'<br /><b>Promised Time:</b>" . $lang['L_NONE2'] . " - ' + ";
									
				        	        if ($entry['promised_time_to']) 
				        	        	$script .= "'" . date("h:i A", strtotime($entry['promised_time_to'])) . "' + ";
				        	        else 
			        	        		$script .= "'" . $lang['L_NONE2'] . "' + ";    
				        	        $script .= "'<br>" . $entry['customer_address'] . ", " . $entry['customer_city']. ", " . $entry['customer_state'] . " " . $entry['customer_zip'] . "';";
				        if ($entry['map_point'] != "" && $entry['map_point'] == '29.7601927, -95.3693896')
				        	$script .= "address += '<span style=\"color: #ff0000\">Cannot find out the address on Google map</span><br />' +  address;";
	
				    	if ($entry['map_point'] != "")	
				    		$script .= "point = new GLatLng(" . $entry['map_point'] . ");";
				    	else
				        	$script .= "point = new GLatLng(" . getMapPoint($entry['fulladdress'], $entry['ticket_id']) . ");";
	
				        $script .= "var char='';";
				        foreach ($statusList as $status)
				        {
				        	if ($entry['status_service_id'] == $status['status_service_id'])
				        	  $script .= "char = '" . $status['total'] . "';";
				        }    
				        $script .= "map.addOverlay(createMarker(point, address, '" .$entry['status_service_id'] . "', char));";
			       }
			    $script .= "}";
			$script .= "}";

				 $script .= "load() ;";


		$script .= "</script>";
		return $script;
}

function ServiceStatusDropdown($ticketStatusId, $ticketid)
{
	global $configuration, $lang, $objstatusservice;
	$stauses_service_tmp = $objstatusservice->get_statuses('', 0, 0, 'status_service_name');
	$dropdownbox = '<select id="status_service_' . $ticketStatusId . '" name="status_service_action_' . $ticketid . '" onchange="changestickettatus(this)" class="select">';

	foreach($stauses_service_tmp as $status) 
	{
		if ($status["status_service_id"] == $ticketStatusId)
			$dropdownbox .= '<option value="' . $status["status_service_id"] . '" selected >' . $status['status_service_name'] . '</option>';
		else 
			$dropdownbox .= '<option value="' . $status["status_service_id"] . '">' . $status['status_service_name'] . '</option>';	
	}
	$dropdownbox .= '</select>';
	return $dropdownbox;
}

?>