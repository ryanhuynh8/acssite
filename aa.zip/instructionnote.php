<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objdbinstructionnotes= new dbinstructionnotes();
//$objuser = new dbuser();

//requets parameter
$page = request_var('page', '1');
$id = request_var('id', '');
$note_description = request_var('note_description', '');
$note_title = request_var('note_title', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")

switch ($mode)
{
    case "view":       

        

       
        //get all note

        $where_clause = ' 1 = 1';
        if ($note_description)
            $where_clause .= " AND t.note_description like '%$note_description%'";
        if ($note_title)
            $where_clause .= " AND t.note_title like '%$note_title%'";

        $notes = $objdbinstructionnotes->get_note($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'note_id'), request_var('sortby', 'desc'));

        $itemcount = $objdbinstructionnotes->get_note($where_clause, 0, 0, '', '', true);

        $templates->setvar('notes', $notes);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", false, false) : "");
    break;
    
    

    
    case "details":
        if ($id)
        {

            //get note information
            $note_infor = $objdbinstructionnotes->get_note_by_id($id);

            $templates->setvar('note_infor', $note_infor);
        }
    break;


    case "delete":
        if ($id)
        {
            //delete announcement
            $objdbinstructionnotes->delete($id);

            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {

        

            
            //get note information
            $note_infor = $objdbinstructionnotes->get_note_by_id($id);

            $templates->setvar('note_infor', $note_infor);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
            
            }
            else
            {
                $validator = true;
                if (trim($note_title) == '')
                {
                    $validator = false;
                    $templates->setvar('error_note_title', 'Title field cannot be blank.');
                }
                if (trim($note_description) == '')
                {
                    $validator = false;
                    $templates->setvar('error_note_description', 'Description field cannot be blank.');
                }
                

                $save_note = array('note_title'=> $note_title,
                                   'note_description' => $note_description);
                
                if ($validator)
                {
                    $objdbinstructionnotes->save('UPDATE', $save_note, " note_id = $id");

                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('note_infor', $save_note);
                }
            }
        }
    break;
    
    case "add":


        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
             $templates->setvar('task_infor', array('due_date' => date('Y-m-d')));                                                    
        }
        else
        {
                                 
            $validator = true;

            if (trim($note_title) == '')
            {
                $validator = false;
                $templates->setvar('error_note_title', 'Title field cannot be blank');
            }
            if (trim($note_description) == '')
            {
                $validator = false;
                $templates->setvar('error_note_description', 'Description field cannot be blank');
            }


            $save_note = array('note_title'=> $note_title,
                'note_description' => $note_description);
            
            if ($validator)
            {
                $objdbinstructionnotes->save('INSERT', $save_note);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('note_infor', $save_note);
            }
        }
    break;
}


//show template
$templates->show('instructionnote.tpl');
?>