<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $actionsPermission;



//define object class
$objtickets = new dbtickets();
$objuser = new dbuser();
$objsettletickets= new dbsettletickets();


//requets parameter
$page = request_var('page', 1);
$id_invoice_number = request_var('id', '');
$assign=request_var('assign', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');

$payment_method_cash=request_var('payment_method_cash','');
$payment_method_check=request_var('payment_method_check','');
$payment_method_credit=request_var('payment_method_credit','');
$payment_method_non=request_var('payment_method_non','');
$settle_status=request_var('settle_status', '0');
$received_by_initial=request_var('received_by_initial','');
$notes=request_var('notes','');
$received_date=request_var('received_date','');
$received_by_name=request_var('received_by_name', '');
$m=request_var('m', '');
$list_id=request_var('list_id', '');


//if ($_SERVER['REQUEST_METHOD'] == "POST")
$member = $objuser->get_user_by_id($authenticate->get_user_id());
if($member){
     $templates->setvar('member', $member);
}

switch ($mode)
{
     case "archived":
     case "view":
	  //$start_date=date('m/d/Y');
	  //$end_date =date('Y-m-d',time() + (2*7 * 24 * 60 * 60));
	  $start_date =date('Y-m-d',time() - (2*7 * 24 * 60 * 60));
		  $end_date=date('m/d/Y');
	  if($mode == 'archived') 
	  {
		  $start_date =date('Y-m-d',time() - (4*7 * 24 * 60 * 60)-( 24 * 60 * 60));
			  $end_date=date('Y-m-d',time() - (2*7 * 24 * 60 * 60)-( 24 * 60 * 60));
			  $settle_status=1;
	  }		          	     
	  if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
	  if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
	  $templates->setvar('filter', array('from_date' => $from_date, 'to_date' => $to_date) );
	  
	  $from_date = convert_to_standard_date($from_date);
	  $to_date = convert_to_standard_date($to_date);     
	 
	  //get all user for assign
	  $users = $objuser->get_users('', 0, 0, 'name');
	  $templates->setvar('users', $users);
							  
	  //get all tickets
	  $where_clause = ' 1 = 1';
	  $where_clause .= " AND (t.status_service_id = 3 OR t.status_service_id = 12) ";
	  if (!in_array('see all records', $actionsPermission) )
		  $where_clause .= " AND t.assign_by = " . $authenticate->get_user_id();
	  else
		  $where_clause .= $assign ? " AND t.assign_by = '$assign'" : '';
	  $where_clause .= $from_date ? " AND DATE(t.complete_date) >= '$from_date'" : '';
	  $where_clause .= $to_date ? " AND DATE(t.complete_date) <= '$to_date'" : '';		
	  // filler payment_method
	  if (!$payment_method_cash && !$payment_method_check && !$payment_method_non && !$payment_method_credit )
	  {   
		  if($m)     	
		  {           		
			  $payment_method_non_payment ="non_payment";
		  }
		  else 
		  {
			  $payment_method_cash="cash";
			  $payment_method_check="check";
			  $payment_method_non="non_collected";
			  $payment_method_credit="credit_card";
		  }
	  }        	
	  $list_payment = array(1 => $payment_method_non_payment,$payment_method_cash,$payment_method_check,$payment_method_non,$payment_method_credit);
	  $flag=0;
	  foreach ($list_payment as &$value)
	  {
	       if($value)
	       {
		    if($flag==0)
		    {
			    $where_clause .= $value? " AND ((t.payment_method= '$value')" : '';
			    $flag=1;
		    }
		    else				
		    $where_clause .= $value? " OR(t.payment_method= '$value')" : '';
	       }		    	
	  }		
	  if($flag==1)
		   $where_clause .=")";   
	   // fillter settle status			 
	  if($settle_status==0)			          	
	       $where_clause .= " AND t.invoice_number not in (select s.ticket_invoice_id from ".TBL_SETTLED_TICKET." AS s)";
	  else 
	       $where_clause .= " AND t.invoice_number in (select s.ticket_invoice_id from ".TBL_SETTLED_TICKET." AS s)";								
	  $settle_tickets = $objsettletickets->get_settled_ticket($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'twofiled'), request_var('sortby', 'desc') );		                
	  
	  $itemcount = $objsettletickets->get_settled_ticket($where_clause, 0, 0, '', '', true);                      
	  $templates->setvar('settle_tickets', $settle_tickets);
	  
	  //paging
	  $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case settle:    	
    	    	      
    	  //get all user for received by name
	  $where_clause = ' 1 = 1';    	 
	  $where_clause .= " and (u.role_id=2 or u.role_id=1 or u.role_id=26 or u.role_id = 24 ) ";
	  $users = $objuser->get_users($where_clause, 0, 0, 'name');    	 
	  $templates->setvar('users', $users);
       
	 
	  //get all tickets
	  $where_clause = ' 1 = 1';
	  $where_clause .= " AND (t.status_service_id = 3 OR t.status_service_id = 12) ";  
	  
	  /////   View Settle when click checkbox at settletickets 
	  $flag=0;       	               
	  $str_sql="";
	  if ($_SERVER['REQUEST_METHOD'] != "POST")
	  {
	    $array_id=split(',',$list_id);
	    foreach ($array_id as $key=>$value)
	    {                
		 if($value!="")
		 {
			 $str_sql .="t.invoice_number=". $value. " OR ";
			 $flag=1;        		
		 }
	    }
	  }
        // Get list invoice when submit Print receipt and complete
	  else
	  {
	       foreach ($_POST as $key=>$value)
	       {                  	     
		   $hidden = substr($key, 0, 15);                             
		   if ($hidden == 'invoice_number_') 
		   {
			    $str_sql .="t.invoice_number=". $value. " OR ";
			    $flag=1;
		   }                	                
	       }
	       if($flag==0)
	       {		     	
		    $list_id=request_var('list_id', '');
		    $array_id=split(',',$list_id);
		    foreach ($array_id as $key=>$value)
		    {                
			 if($value!="")
			 {
				 $str_sql .="t.invoice_number=". $value. " OR ";		        			
			 }
		    }
	       }
	  }					
	  if($str_sql != "")
	  {
	       $str_sql=substr($str_sql,0, $str_sql.length-4);		              
	       $where_clause .= " AND ".$str_sql;
	  }		             
			 
	  if ($_SERVER['REQUEST_METHOD'] != "POST")
	  {
	       $templates->setvar('filter', array('received_date' => date('Y-m-d')));              	  
	  }
	  else
	  {            	
	      $validator = true;
	      
	       if (trim($received_by_name) == '')
	       {
		  $validator = false;
		  $templates->setvar('error_assign', $lang['E_ASSIGN']);
	       }
	       if (trim($received_by_initial) == '')
	       {
		  $validator = false;
		  $templates->setvar('error_initial', $lang['E_INITIAL']);
	       }
	       if($flag==0)
	       {					
		    $validator = false;
		    $templates->setvar('error_please_select_ticket', $lang['E_PLEASE_SELECT_TICKET']);
			      }                               		                                        
		    if ($validator)
		    {	            	
			 foreach ($_POST as $key=>$value)
			 {                  	     
			      $hidden = substr($key, 0, 15);                             
			      if ($hidden == 'invoice_number_')
			      { 
				   $id_invoice_number .=$value. ",";
				   $save_settle_tikets = array('ticket_invoice_id' => $value,
					'received_by_name' => $received_by_name,                                                                 
					'received_by_initial' => $received_by_initial,                                       
					'received_date' => convert_to_standard_date($received_date),
					'receipt_printed'=> 1,
					'notes' => $notes);                                                      	             	            	
				   $objsettletickets->save('INSERT', $save_settle_tikets);	                
			      }
			 }					
			 $templates->setvar('save_success', true);
			 redirect("settletickets.php?mode=print&list_id=".$id_invoice_number);
		    }
		    else
		    {
			 $templates->setvar('filter', array('received_date' => date('Y-m-d')));   
			 $templates->setvar('settle_tickets', $save_settle_tikets);  
		    }	               
	  }
	  $settle_tickets = $objsettletickets->get_settled_ticket($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'twofiled'), request_var('sortby', 'desc') );            
	  $templates->setvar('settle_tickets', $settle_tickets);
	  $templates->setvar('settle_tickets_info', $settle_tickets[0]);	  
    break;
    
    case'detail':
    case 'print':
    	//get all tickets		
	  $where_clause = ' 1 = 1';
	  $where_clause .= " AND (t.status_service_id = 3 OR t.status_service_id = 12) ";
	  
		  $array_id=split(',',$list_id);
	  $str_sql="";
	  foreach ($array_id as $key=>$value)
	  {        	
		  if($value!="")
			  $str_sql .="t.invoice_number=". $value. " OR ";
	  }
		  if($str_sql != "")
	  {
		  $str_sql=substr($str_sql,0, $str_sql.length-4);		              
		  $where_clause .= " AND ".$str_sql;
	  }           
	  $settle_tickets = $objsettletickets->get_settled_ticket($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'twofiled'), request_var('sortby', 'desc') );                
	  $templates->setvar('settle_tickets', $settle_tickets);	
	  $templates->setvar('settle_tickets_info', $settle_tickets[0]);
    break;

}

//show template
$templates->show('settletickets.tpl');

?>