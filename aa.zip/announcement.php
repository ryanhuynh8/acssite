<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objannouncement= new dbannouncements();

//requets parameter
$page = request_var('page', '1');
$id = request_var('id', '');
$expired_date = request_var('expired_date', '');
$post_on_date = request_var('post_on_date', '');
$from_expired_date = request_var('from_expired_date', '');
$to_expired_date = request_var('to_expired_date', '');
$create_on = request_var('create_on', '');
$from_create_on = request_var('from_create_on', '');
$to_create_on = request_var('to_create_on', '');
$announcements_description = request_var('announcements_description', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")

switch ($mode)
{
    case "view":
        //get all announcement
        $where_clause = " 1 = 1";
        if ($announcements_description)
            $where_clause .= " AND announcements_description like '%$announcements_description%'";        
        $announcement = $objannouncement->get_announcements($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'announcements_id'), request_var('sortby', 'desc'));        
        $itemcount = $objannouncement->get_announcements($where_clause, 0, 0, '', '', true);
        $templates->setvar('announcement', $announcement);            
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "details":
        if ($id)
        {
            //get announcement information
            $announcement_infor = $objannouncement->get_announcement_by_id($id);            
            
            $templates->setvar('announcement_infor', $announcement_infor);       
        }
    break;

    case "delete":
        if ($id)
        {
            //delete announcement
            $objannouncement->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {                        
            //get employee information
            $announcement_infor = $objannouncement->get_announcement_by_id($id); 
            $templates->setvar('announcement_infor', $announcement_infor);    
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
            
            }
            else
            {
                $validator = true;
                
                if (trim($announcements_description) == '')
                {
                    $validator = false;
                    $templates->setvar('error_announcements_description', $lang['E_ANNOUNCEMENT_DESCRIPTION']);
                }
               $post_on_date = convert_to_standard_date($post_on_date);
                $expired_date = convert_to_standard_date($expired_date);
                if(trim($post_on_date)=='')
                {
                    $validator = false;
                    $templates->setvar('error_post_on_date', $lang['E_POST_ON_DATE']);
                }
                else if(trim($expired_date!='')&& strtotime($post_on_date) > strtotime($expired_date))
                {
                    $validator = false;
                    $templates->setvar('error_post_on_date_expired', $lang['E_POST_ON_DATE_EXPIRED']);
                }           
                $save_announcement = array(
                                           'post_on_date' => $post_on_date,
                                           'expired_date' => $expired_date,                                                                                                                        
                                           'announcements_description' => $announcements_description);                                      
                
                if ($validator)
                {
                    $objannouncement->save('UPDATE', $save_announcement, " announcements_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('announcement_infor', $save_announcement);  
                }
            }
        }
    break;
    
    case "add":       
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            $nextWeek = time() + (7 * 24 * 60 * 60);
            $templates->setvar('announcement_infor', array('expired_date' => date('Y-m-d', $nextWeek),
                                                           'post_on_date' => date('Y-m-d')));  
        }
        else
        {
            $validator = true;
            
            if (trim($announcements_description) == '')
            {
                $validator = false;
                $templates->setvar('error_announcements_description', $lang['E_ANNOUNCEMENT_DESCRIPTION']);
            }
            $post_on_date = convert_to_standard_date($post_on_date);
            $expired_date = convert_to_standard_date($expired_date);
            if(trim($post_on_date)=='')
            {
                $validator = false;
                $templates->setvar('error_post_on_date', $lang['E_POST_ON_DATE']);
            }
            else if(trim($expired_date!='')&& strtotime($post_on_date) > strtotime($expired_date))
            {
                $validator = false;
                $templates->setvar('error_post_on_date_expired', $lang['E_POST_ON_DATE_EXPIRED']);
            }
            
            $save_announcement = array('create_on' => date('Y-m-d'),
                                       'post_on_date' => $post_on_date,
                                       'expired_date' => $expired_date,                                                                            
                                       'announcements_description' => $announcements_description); 
            
            if ($validator)
            {
                $objannouncement->save('INSERT', $save_announcement);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('announcement_infor', $save_announcement);  
            }
        }
    break;
}


//show template
$templates->show('announcement.tpl');
?>