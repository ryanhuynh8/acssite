<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objdefineexpense = new dbdefineexpense();
$objexpense = new dbexpense();

//requets parameter
$define_expense = request_var('define_expense', '');
$amount = request_var('amount', '');
$date = request_var('date', '');
$payment = request_var('payment', '');
$notes = request_var('notes', '');

//get for select
$define_expenses = $objdefineexpense->get_defineexpenses('', 0, 0, 'description');
$templates->setvar('define_expenses', $define_expenses);

switch ($mode)
{
    case 'view':
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $validator_error = true;
            
            if (trim($define_expense) == '')
            {
                $validator_error = false;
                $templates->setvar('error_expense', $lang['E_EXPENSE']);
            }
            if  (trim($amount) != '' && ( !is_numeric($amount) || $amount < 0) )
            {
                $validator_error = false;
                $templates->setvar('error_amount', $lang['E_AMOUNT']);
            }
            if (trim($date) != '' && !is_valid_date($date))
            {
                $validator_error = false;
                $templates->setvar('error_date', $lang['E_DATE']);
            }
            
            $save_expense = array('define_expense_id' => $define_expense,
                                  'amount' => $amount,
                                  'date' => convert_to_standard_date($date),
                                  'payment' => $payment,
                                  'notes' => $notes
                                  );
            
            if ($validator_error)
            {
                $objexpense->save('INSERT', $save_expense);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('expense_infor', $save_expense);
            }
        }
    break;

    case 'get_define_expense';
        if ($define_expense)
        {
            $define_expense_infor = $objdefineexpense->get_define_expense_by_id($define_expense);
            
            echo strtoupper($define_expense_infor['type'] == 1 ? $lang['L_BUSSINESS'] : $lang['L_PERSONAL']) . ';' . $define_expense_infor['fixed_amount'];            
        }
        return;
    break;
}

//show template
$templates->show('enternewexpenses.tpl');
?>