<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objproblem = new dbproblem();

//requets parameter
$page = request_var('page', '1');
$parent = request_var('parent', 0);
$problem_name = request_var('problem_name', '');
$actived = request_var('actived', '');
$id = request_var('id', '');


switch ($mode)
{
    case "view":
        //get all problemss
        $where_clause = " 1 = 1";
        if ($problem_name)
            $where_clause .= " AND problem_name like '%$problem_name%'";
        
        $problems = $objproblem->getAllProblemsByParent($where_clause);
        
        $templates->setvar('problems', $problems);
        
        //paging
        $templates->setvar("PAGING", $itemcount > 5 ? paging($page, 5, $itemcount, "page","", true, false) : "");
    break;

    case "delete":
        if ($id)
        {
            //delete problems
            $objproblem->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $problem_infor = $objproblem->get_problem_by_id($id);
                $templates->setvar('problem_infor', $problem_infor);
            }
            else
            {
                $validator = true;
                
                if (trim($problem_name) == '')
                {
                    $validator = false;
                    $templates->setvar('error_problem_name', $lang['E_PROBLEM_NAME']);
                }
                
                $save_problem = array('parent' => $parent,
                                      'problem_name' => $problem_name,
                                      'actived' => $actived ? 1 : 0);
                
                if ($validator)
                {
                    $objproblem->save('UPDATE', $save_problem, "problem_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('problem_infor', $save_problem);
                    
                }
            }

            $problems = $objproblem->get_problems(' 1 AND parent = 0', 0, 0, 'problem_name', 'asc');
            $templates->setvar('problems', $problems);
        }
    break;
    
    case "add":
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $validator = true;
            
            if (trim($problem_name) == '')
            {
                $validator = false;
                $templates->setvar('error_problem_name', $lang['E_PROBLEM_NAME']);
            }
            
            $save_problem = array('parent' => $parent,
                                  'problem_name' => $problem_name,
                                  'actived' => $actived ? 1 : 0);
            if ($validator)
            {
                $objproblem->save('INSERT', $save_problem);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('problem_infor', $save_problem);
            }
        }
        $problems = $objproblem->get_problems(' parent=0', 0, 0, 'problem_name', 'asc');
        $templates->setvar('problems', $problems);
    break;
}



//show template
$templates->show('repairproblem.tpl');
?>