<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objuser = new dbuser();

//requets parameter
$email = request_var('email', '');
$old_password = request_var('old_password', '');
$new_password = request_var('new_password', '');
$confirm_password = request_var('confirm_password', '');

//get user information
$user_infor = $objuser->get_user_by_id($authenticate->get_user_id() );

if($user_infor == null){
  redirect("index.php");
}

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $error_validator = true;
    
    if (trim($email) == '')
    {
        $error_validator = false;
        $templates->setvar('error_email', $lang['E_EMAIL']);
    }
    else
    {
        if (!is_valid_email($email))
        {
            $error_validator = false;
            $templates->setvar('error_email', $lang['E_EMAIL_INVALID']);
        }
        else
        {
            $user = $objuser->get_user_by_email($email, "email <> '". $user_infor['email'] ."'");
            if ($user)
            {
                $error_validator = false;
                $templates->setvar('error_email', $lang['E_EMAIL_EXISTS']);
            }
        }
    }
    
    if (trim($old_password) == '')
    {
        $error_validator = false;
        $templates->setvar('error_old_password', $lang['E_OLD_PASSWORD']);
    }
    else
    {
        if (md5($old_password) != $user_infor['password'])
        {
            $error_validator = false;
            $templates->setvar('error_old_password', $lang['E_WRONG_PASSWORD']);
        }
    }
    if (trim($new_password) == '')
    {
        
    }
    else
    {
        if (strlen($new_password) < 6)
        {
            $error_validator = false;
            $templates->setvar('error_new_password', $lang['E_CHARACTERS_PASSWORD']);
        }
        elseif ($new_password != $confirm_password)
        {
            $error_validator = false;
            $templates->setvar('error_confirm_password', $lang['E_CONFIRM_PASSWORD']);
        }
    }
    
    if ($error_validator)
    {
        $save_user = array('email' => $email);
        
        if (trim($new_password) != '')
            $save_user['password'] = md5($new_password);
        
        $objuser->save('UPDATE', $save_user, 'user_id = ' . $user_infor['user_id']);
        
        $templates->setvar('save_success', true);
    }
    else
    {
        $user_infor['email'] = $email;
    }
}

$templates->setvar('user_infor', $user_infor);

//show template
$templates->show('myaccount.tpl');
?>