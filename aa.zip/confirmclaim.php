<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;


if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');


$objtickets = new dbtickets();

$user = request_var('user', '');
$ticket_id = request_var('ticketid', '');
    
//get all user for select
$users = $objuser->get_users('', 0, 0, 'name');
$templates->setvar('users', $users);

//get ticket information
$ticket_info = $objtickets->get_ticket_by_id($ticket_id);

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $error_validator = true;
    if ($user == "")
    {
        $error_validator = false;
        $templates->setvar('error_user', $lang['E_USER']);
    }
    
    if ($error_validator)
    {
        $save_ticket = array('assign_by' => $user);
        $objtickets->save('UPDATE', $save_ticket, " ticket_id = $ticket_id");
        
        echo '<script type="text/javascript">window.top.location.href="dashboard.php?mode=claim&ticketid='. $ticket_id .'"</script>';
    }
    else
    {
        $ticket_info['assign_by'] = $user;
    }
}

$templates->setvar('ticket_info', $ticket_info);

$templates->show('confirmclaim.tpl');
?>