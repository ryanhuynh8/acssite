<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $actionsPermission;

//define object class
$objproposals = new dbproposals();
$objproposalparts = new dbproposalparts();
$objcustomers = new dbcustomers();
$objstates = new dbstates();
$objcompany = new dbcompany();

//requets parameter
$id = request_var('id', '');
$user = request_var('user', '');
$customer_id = request_var('customer_id', '');
$customer_name = request_var('customer_name', '');
$address = request_var('address', '');
$city = request_var('city', '');
$state = request_var('state', '');
$zip = request_var('zip', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$page = request_var('page', 1);
$list = request_var('list', '');

$search_name = request_var('search_name', '');
$search_address = request_var('search_address', '');
$search_city = request_var('search_city', '');
$search_state = request_var('search_state', '');
$search_zip = request_var('search_zip', '');
$search_customers = request_var('search_customers', '');

switch ($mode)
{
    case 'view':
        $_SESSION['selfURL'] = selfURL();
        
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        if ($list != 'all')
        {
            $prev_month = date('Y') . '-' . (date('m')-1) . '-01';
            
            $from_date = $prev_month;
        }
        
        //get all user for select
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);
        
        //get all proposal
        $where_clause = ' 1 = 1';
        
        if (!in_array('see all records', $actionsPermission) )
            $where_clause .= " AND pp.user_id = " . $authenticate->get_user_id();
        else
            $where_clause .= $user ? " AND pp.user_id = $user" : '';
        
        $where_clause .= $customer_name ? " AND c.full_name like \"%$customer_name%\" " : '';
        $where_clause .= $from_date ? " AND pp.created_date >= '$from_date' " : '';
        $where_clause .= $to_date ? " AND pp.created_date <= '$to_date' " : '';
        
        $proposals = $objproposals->get_proposals($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'created_date'), request_var('sortby', 'desc') );
        
        $itemcount = $objproposals->get_proposals($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('proposals', $proposals);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case 'edit':
        if ($id)
        {
            //get all customers for select
            $whereClause = ' 1 ';
            if ($search_customers)
            {
                $whereClause .= $search_name ? " AND c.full_name like \"%$search_name%\" " : '';
                $whereClause .= $search_address ? " AND c.address like \"%$search_address%\" " : '';
                $whereClause .= $search_city ? " AND c.city like \"%$search_city%\" " : '';
                $whereClause .= $search_state ? " AND c.state = '$search_state' " : '';
                $whereClause .= $search_zip ? " AND c.zip like \"%$search_zip%\" " : '';
            }
            else
            {
                if ($id)
                {
                    $proposal_infor = $objproposals->get_proposal_by_id($id);
                    $whereClause = " customer_id = " . $proposal_infor['customer_id'];
                }
            }
            
            $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
            $templates->setvar('customers', $customers);
            //get all states for select
            $states = $objstates->get_states('', 0, 0, 'state_code');
            $templates->setvar('states', $states);
            
            //get all categories
            $categories = array();
            $categories_tmp = $objproposals->get_categories('', 0, 0, 'ordering');
            foreach ($categories_tmp as $category)
            {
                $category['parts'] = $objproposalparts->get_parts_by_category_with_proposal($category['proposal_category_id'], $id);
                $categories[] = $category;
            }
            $templates->setvar('categories', $categories);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $proposal_infor = $objproposals->get_proposal_by_id($id);
                $templates->setvar('proposal_infor', $proposal_infor);
            }
            else
            {
                $error_validator = true;
                if (trim($customer_name) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_customer_name', $lang['E_CUSTOMER_NAME']);
                }
                if (trim($address) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_address', $lang['E_ADDRESS']);
                }
                //validator quantity is numeric
                foreach ($categories as $category)
                {
                    foreach ($category['parts'] as $part)
                    {
                        $quantity = request_var("quantity_" . $part['proposal_part_id'], '');
                        if ($quantity && !is_numeric($quantity) )
                        {
                            $error_validator = false;
                            $templates->setvar('error_list_charge', $lang['E_QUANTITY']);
                        }
                    }
                }
                
                $save_proposal = array('customer_id' => $customer_id);
                
                $save_customer = array('full_name' => $customer_name,
                                       'address' => $address,
                                       'city' => $city,
                                       'state' => $state,
                                       'zip' => $zip);
                
                if ($error_validator)
                {
                    //map customer
                    if (!$customer_id)
                    {
                        $customer_id = $objcustomers->map_customer($save_customer);
                        $save_proposal['customer_id'] = $customer_id;
                    }
                    else
                    {
                        $objcustomers->save('UPDATE', $save_customer, " customer_id = $customer_id");
                    }
                    
                    $objproposals->save('UPDATE', $save_proposal, " proposal_id = $id");
                    
                    $templates->setvar('save_success', true);
                    
                    //delete old part
                    $objproposals->delete_proposal_parts($id);
                    //insert part to proposal
                    foreach ($_POST as $key=>$value)
                    {
                        $checked = substr($key, 0, 15);                     
                        if ($checked == 'check_proposal_')
                        {
                            $checked = $value;
                            $quantity = request_var("quantity_$value", '');
                            $price = request_var("price_$value", '');
                            
                            $save_proposal_part = array('proposal_id' => $id,
                                                        'proposal_part_id' => $checked,
                                                        'quantity' => $quantity,
                                                        'price' => $price);
                            
                            $objproposals->save_proposal_part("INSERT", $save_proposal_part);
                        }
                    }
                }
                else
                {
                    $new_categories = array();
                    foreach ($categories as $category)
                    {
                        $new_parts = array();
                        foreach ($category['parts'] as $part)
                        {
                            $checked = request_var("check_proposal_" . $part['proposal_part_id'], '');
                            $quantity = request_var("quantity_" . $part['proposal_part_id'], '');
                            
                            $part['proposal_id'] = $checked;
                            $part['quantity'] = $quantity;
                            $new_parts[] = $part;
                        }
                        $category['parts'] = $new_parts;
                        $new_categories[] = $category;
                    }
                    
                    $templates->setvar('categories', $new_categories);
                    $save_customer['customer_id'] = $save_proposal['customer_id'];
                    $templates->setvar('proposal_infor', $save_customer);
                }
            }
        }
    break;

    case 'add':
        //get all customers for select
        $whereClause = ' 1 ';
        if ($search_customers)
        {
            $whereClause .= $search_name ? " AND c.full_name like \"%$search_name%\" " : '';
            $whereClause .= $search_address ? " AND c.address like \"%$search_address%\" " : '';
            $whereClause .= $search_city ? " AND c.city like \"%$search_city%\" " : '';
            $whereClause .= $search_state ? " AND c.state = '$search_state' " : '';
            $whereClause .= $search_zip ? " AND c.zip like \"%$search_zip%\" " : '';
            
            $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
            $templates->setvar('customers', $customers);
        }
        
        
        //get all states for select
        $states = $objstates->get_states('', 0, 0, 'state_code');
        $templates->setvar('states', $states);
        
        //get all categories
        $categories = array();
        $categories_tmp = $objproposals->get_categories(' actived = 1', 0, 0, 'ordering');
        foreach ($categories_tmp as $category)
        {
            $parts = $objproposalparts->get_parts_by_category($category['proposal_category_id']);
            $new_part = array();
            foreach ($parts as $part)
            {
                $part['quantity'] = 1;
                $part['price'] = $part['proposal_part_price'];
                $new_part[] = $part;
            }
            $category['parts'] = $new_part;
            $categories[] = $category;
        }
        $templates->setvar('categories', $categories);
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $error_validator = true;
            if (trim($customer_name) == '')
            {
                $error_validator = false;
                $templates->setvar('error_customer_name', $lang['E_CUSTOMER_NAME']);
            }
            if (trim($address) == '')
            {
                $error_validator = false;
                $templates->setvar('error_address', $lang['E_ADDRESS']);
            }
            //validator quantity is numeric
            foreach ($categories as $category)
            {
                foreach ($category['parts'] as $part)
                {
                    $quantity = request_var("quantity_" . $part['proposal_part_id'], '');
                    $price = request_var("price_" . $part['proposal_part_id'], '');
                    if ($quantity && !is_numeric($quantity) )
                    {
                        $error_validator = false;
                        $templates->setvar('error_list_charge', $lang['E_QUANTITY']);
                    }
                }
            }
            
            
            $save_proposal = array('customer_id' => $customer_id,
                                   'user_id' => $authenticate->get_user_id(),
                                   'created_date' => date('Y-m-d') );
            
            $save_customer = array('full_name' => $customer_name,
                                   'address' => $address,
                                   'city' => $city,
                                   'state' => $state,
                                   'zip' => $zip);
            
            if ($error_validator)
            {
                //map customer
                if (!$customer_id)
                {
                    $customer_id = $objcustomers->map_customer($save_customer);
                    $save_proposal['customer_id'] = $customer_id;
                }
                else
                {
                    $objcustomers->save('UPDATE', $save_customer, " customer_id = $customer_id");
                }
                
                $proposal_id = $objproposals->save('INSERT', $save_proposal);
                
                $templates->setvar('save_success', true);
                
                //insert part to proposal
                foreach ($_POST as $key=>$value)
                {
                    $checked = substr($key, 0, 15);                     
                    if ($checked == 'check_proposal_')
                    {
                        $checked = $value;
                        $quantity = request_var("quantity_$value", '');
                        $price = request_var("price_$value", '');
                        
                        $save_proposal_part = array('proposal_id' => $proposal_id,
                                                    'proposal_part_id' => $checked,
                                                    'quantity' => $quantity,
                                                    'price' => $price);
                        
                        $objproposals->save_proposal_part("INSERT", $save_proposal_part);
                    }
                }
            }
            else
            {
                $new_categories = array();
                foreach ($categories as $category)
                {
                    $new_parts = array();
                    foreach ($category['parts'] as $part)
                    {
                        $checked = request_var("check_proposal_" . $part['proposal_part_id'], '');
                        $quantity = request_var("quantity_" . $part['proposal_part_id'], '');
                        
                        $part['proposal_id'] = $checked;
                        $part['quantity'] = $quantity;
                        $new_parts[] = $part;
                    }
                    $category['parts'] = $new_parts;
                    $new_categories[] = $category;
                }
                
                $templates->setvar('categories', $new_categories);
                $save_customer['customer_id'] = $save_proposal['customer_id'];
                $templates->setvar('proposal_infor', $save_customer);
            }
        }
    break;

    case 'details':
        if ($id)
        {
            //get company information
            $company_infor = $objcompany->get_company();
            $templates->setvar('company_infor', $company_infor);
            
            $results = array();
            $parts_selected = $objproposals->get_parts_selected($id);
            $index = 0;
            $category_id = '';
            $total_price = 0;
            foreach($parts_selected as $part)
            {                
                if ($part['proposal_category_id'] != $category_id)
                {
                    $category_id = $part['proposal_category_id'];                    
                    $results[$index]['category_name'] = $part['category_name'];
                    $results[$index]['parts'][] = $part;
                    $index++;
                }
                else
                {
                    $results[$index - 1]['parts'][] = $part;
                }
                $total_price += $part['price'] * $part['quantity'];
            }            
            
            $proposal_infor = $objproposals->get_proposal_by_id($id);
            $proposal_infor['categories'] = $results;
            $proposal_infor['total_price'] = $total_price;
            $templates->setvar('id', $id);
            $templates->setvar('proposal_infor', $proposal_infor);
        }
    break;

    case "delete":
        if ($id)
        {
            $objproposals->delete_proposal_parts($id);
            $objproposals->delete($id);
            
            $templates->setvar('delete_success', true);
        }
    break;

    case "get_information_customer":
        $customer_id = request_var('customer_id', '');
        if ($customer_id)
        {
            $customer = $objcustomers->get_customer_by_id($customer_id);
            
            echo htmlspecialchars_decode(trim($customer['full_name']) . ';@' . trim($customer['address']) . ';@' . trim($customer['city']) . ';@' .
                trim($customer['state']) . ';@' . trim($customer['zip']) . ';@' . trim($customer['phone1']) );
        }
        
        return;
    break;

    case "get_customers" :
        $whereClause = ' 1 ';
        $whereClause .= $search_name ? " AND c.full_name like \"%$search_name%\" " : '';
        $whereClause .= $search_address ? " AND c.address like \"%$search_address%\" " : '';
        $whereClause .= $search_city ? " AND c.city like \"%$search_city%\" " : '';
        $whereClause .= $search_state ? " AND c.state = '$search_state' " : '';
        $whereClause .= $search_zip ? " AND c.zip like \"%$search_zip%\" " : '';
        $customers = $objcustomers->get_customers($whereClause, 0, 0, 'full_name');
        $html = '<select id="customer_id" name="customer_id" class="select" style="width:800px;" onchange="get_information_customer(this)">';
        $html .= '<option value="">'. $lang['L_SELECT_A_CUSTOMER'] .'</option>';
        if ($customers)
        {
            foreach ($customers as $customer)
            {
                $html .= '<option value="'. $customer['customer_id'] .'">'.
                                truncate_text($customer['full_name'], 50) . ' ('. $customer['address'] . ', ' . $customer['city'] . ', ' . $customer['state'] . ', ' . $customer['phone1'] .')' .
                         '</option>'; 
            }
        }
        $html .= '</select>';
        echo $html;
        return;
    break;

    case "print_pdf":
        $html = $_POST["pdfContent"];
        require_once("includes/dompdf/dompdf_config.inc.php");

        //$contents .= "<link href='templates/default/fe/css/screen.css' rel='stylesheet' type='text/css' media='screen' />";
        $contents .= "<link href='templates/default/fe/css/printpdf.css' rel='stylesheet' type='text/css' media='screen' />";


        $contents .= "<body style='font-family: arial;'><div style='text-align: left; font-family: arial;' class='proposal_details'>";
        $contents .= $html;
        $contents .= "</div></body>";

        ini_set('max_execution_time', 300);
        $dompdf = new DOMPDF();

        $dompdf->set_paper("A4","portrait");

        try {
            $dompdf->load_html($contents);
            $dompdf->render();
            $dompdf->stream("dompdf_out.pdf", array("Attachment" => true));
            $dompdf->save('php://output');
        }catch (Exception $e){
            var_dump($e); exit();
        }


        break;
    case "print_excel":


        $company_infor = $objcompany->get_company();


        error_reporting(E_ALL);
        ini_set('display_errors', TRUE);
        ini_set('display_startup_errors', TRUE);
        require_once("includes/PHPExcel.php");

        $objPHPExcel = new PHPExcel();

        $styleArrayHeader = array(
            'font'  => array(
                'size'  => 16,
                'bold' => true
            ));
        $styleArray = array(
            'font'  => array(
                'size'=>11,
                'bold' => true
            ));
        $styleBold = array(
            'font'  => array(
                'size'=>11,
                'bold' => true
            ));
        $objPHPExcel->getProperties()->setCreator("ACS Report")
            ->setLastModifiedBy("ACS Report")
            ->setTitle("ACS Report")
            ->setSubject("ACS Report")
            ->setDescription("ACS Report")
            ->setKeywords("ACS Report")
            ->setCategory("ACS Report");

        $objDrawing = new PHPExcel_Worksheet_Drawing();
        $objDrawing->setName('PHPExcel logo');
        $objDrawing->setDescription('PHPExcel logo');
        $objDrawing->setPath('./images/acslogo.png');       // filesystem reference for the image file
        $objDrawing->setHeight(140);                 // sets the image height to 36px (overriding the actual image height);
        $objDrawing->setCoordinates('A1');    // pins the top-left corner of the image to cell D24
        $objDrawing->setOffsetX(40);                // pins the top left corner of the image at an offset of 10 points horizontally to the right of the top-left corner of the cell
        $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());

$L_PROPOSAL_DETAILS_TEXT = "The following is a list of charges that are covered and not covered by your home warranty. Included are upgrades that are highly recommended or required in order to bring your equipment up to current codes and regulations required by EPA guidelines for handling refrigerants. ACS Absolute Comfort suggests that all ciphers that violating safety of the home owner as well as our technicians must be repaired before performing any repair to your air conditioning or heating system. Other charges include maintenance required to properly diagnose your system and charge related to the installation of new equipment. If you disagree with the non cover charges, our best advice will be call to your insurance provider and ask for a second opinion or cash out.";

        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('C1', htmlspecialchars_decode ($company_infor["name"]))
            //->setCellValue('C2', htmlspecialchars_decode ($company_infor["address"]))
            ->setCellValue('C2', "12102 5th St Houston \nHouston, TX 77072")
            ->setCellValue('C4', '281-495-2013 Office | 1888-6307801 Fax')
            ->setCellValue('C5', 'Web: www.acscomfort.com')
            ->setCellValue('C6', 'Email: acsabsolutecomfort@yahoo.com')
            ->setCellValue('C7', 'License #: TACLB023232C.')
            ->setCellValue('A9', $L_PROPOSAL_DETAILS_TEXT);
        $objPHPExcel->getActiveSheet()->getStyle('C2')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('C2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $objPHPExcel->getActiveSheet()->getStyle('C2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A9')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A9')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
        $objPHPExcel->getActiveSheet()->getStyle('A9')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);


        $objPHPExcel->getActiveSheet()->getStyle('C1')->applyFromArray($styleArrayHeader);


        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:B7');
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('C1:E1');
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('C2:E3');
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('C4:E4');
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('C5:E5');
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('C6:E6');
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('C7:E7');

        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A9:E16');
        //$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A14:D14');
 if ($id)
        {
            //get company information

            $templates->setvar('company_infor', $company_infor);
            $results = array();
            $parts_selected = $objproposals->get_parts_selected($id);
            $i = 17;
            $index = 0;
            $category_id = '';
            $total_price = 0;
            foreach($parts_selected as $part)
            {
                if ($part['proposal_category_id'] != $category_id)
                {
                    $category_id = $part['proposal_category_id'];
                    $results[$index]['category_name'] = $part['category_name'];
                    $results[$index]['parts'][] = $part;
                    $index++;
                }
                else
                {
                    $results[$index - 1]['parts'][] = $part;
                }
                $total_price += $part['price'] * $part['quantity'];
            }

            $proposal_infor = $objproposals->get_proposal_by_id($id);
            $proposal_infor['categories'] = $results;
            $proposal_infor['total_price'] = $total_price;
            $first = true;
            foreach($proposal_infor['categories'] as $item)
            {
                $i++;
                if ($first == true)
                {
                    $x = $i+1;
                    $first = false;
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$i, $item['category_name'])
                        ->setCellValue('C'.$i, "Qty")
                        ->setCellValue('D'.$i, "Unit Price")
                        ->setCellValue('E'.$i, "Amount");

                    $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$i.':B'.$i);
                    $objPHPExcel->getActiveSheet()->getStyle('A'.$i.':E'.$i)->applyFromArray(
                        array(
                            'fill' => array(
                                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                'color' => array('rgb' => 'E6E6FA')
                            )
                        )
                    );
                }else{
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$i, $item['category_name'])
                        ->setCellValue('C'.$i, "")
                        ->setCellValue('D'.$i, "")
                        ->setCellValue('E'.$i, "");

                    $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$i.':B'.$i);
                    $objPHPExcel->getActiveSheet()->getStyle('A'.$i.':E'.$i)->applyFromArray(
                        array(
                            'fill' => array(
                                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                                'color' => array('rgb' => 'E6E6FA')
                            )
                        )
                    );
                }
                foreach ($item['parts'] as $item) {
                    $i++;
                    $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'.$i, htmlspecialchars_decode($item['proposal_part_name']))
                        ->setCellValue('C'.$i, $item['quantity'])
                        ->setCellValue('D'.$i, $item['price'])
                        ->setCellValue('E'.$i,"=C$i*D$i");

                    $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->getNumberFormat()
                        ->setFormatCode('0.00');
                    $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->getNumberFormat()
                        ->setFormatCode('0.00');
                    $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$i.':B'.$i);
                    $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
                }

            }
            $y = $i;
            $i++;
            $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('C'.$i, "Total Balance:")
                ->setCellValue('E'.$i, "=SUM(E$x:E$y)");
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->getNumberFormat()
                ->setFormatCode('#,##0.00');
            $objPHPExcel->setActiveSheetIndex(0)->mergeCells("C$i:D$i");
            $objPHPExcel->getActiveSheet()->getStyle('E'.$i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
            $objPHPExcel->getActiveSheet()->getStyle('C'.$i)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

            $proposal_infor = $objproposals->get_proposal_by_id($id);
            $proposal_infor['categories'] = $results;
            $proposal_infor['total_price'] = $total_price;
        }

            $i++;
            $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "Customer Information");
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($styleArray);
            $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "Customer Name:")
            ->setCellValue('B'.$i, htmlspecialchars_decode ($proposal_infor['full_name']));
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('B'.$i.':E'.$i);
        //
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => 'E6E6FA')
                )
            )
        );
            $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "Address:")
            ->setCellValue('B'.$i, $proposal_infor['address']);
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('B'.$i.':E'.$i);
        //
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => 'E6E6FA')
                )
            )
        );
            $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "City:")
            ->setCellValue('B'.$i, $proposal_infor['city'])
            ->setCellValue('D'.$i, "State: ". $proposal_infor['state'])
            ->setCellValue('E'.$i, "Zip: ".$proposal_infor['zip']);

        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray(
            array(
                'fill' => array(
                    'type' => PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => 'E6E6FA')
                )
            )
        );


        $i++;
        $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "HOMEOWNER AUTHORIZATION");
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($styleArray);
        $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "All charge outlined above have been explained by the technician. PAYMENT FOR ALL HOMEOWNER CHARGES IS DUE PRIOR TO PERFORMING WORK ");
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$i.':E'.($i+1));
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->getAlignment()->setWrapText(true);
        $i++;
        $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "Total Homeowner Charges:");
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($styleArray);
        $i++;
        $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "I _____________________, homeowner, authorize ACS Absolute Comfort to proceed with the above repairs. ");
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$i.':E'.($i+1));
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->getAlignment()->setWrapText(true);

        $i++;
        $i++;
        $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "Regulated by The Texas Department of Licensing and Regulation, \nP.O. Box 12157, Austin, Texas 78711\n1-800-803-9202, 512-463-6599,\nwww.license.state.tx.us");
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$i.':E'.($i+3));
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->getAlignment()->setWrapText(true);
/*
        $i++;
        $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "P.O. Box 12157, Austin, Texas 78711\n1-800-803-9202, 512-463-6599,\nwww.license.state.tx.us ");
        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A'.$i.':C'.($i+2));
        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->getAlignment()->setWrapText(true);
*/
        $i++;
        $i++;
        $i++;
        $i++;
        $i++;
        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A'.$i, "Signature")
            ->setCellValue('D'.$i, "Date");

        $objPHPExcel->getActiveSheet()->getStyle('A'.$i)->applyFromArray($styleBold);
        $objPHPExcel->getActiveSheet()->getStyle('D'.$i)->applyFromArray($styleBold);


                    $objPHPExcel->getActiveSheet()
            ->getColumnDimension('A')
            ->setWidth(25);
        $objPHPExcel->getActiveSheet()
            ->getColumnDimension('B')
            ->setWidth(23);
        $objPHPExcel->getActiveSheet()
            ->getColumnDimension('C')
            ->setWidth(5);
        $objPHPExcel->getActiveSheet()
            ->getColumnDimension('D')
            ->setWidth(15);
        $objPHPExcel->getActiveSheet()
            ->getColumnDimension('E')
            ->setWidth(25);

        $objPHPExcel->getActiveSheet()->setTitle('ACS Report');

        $objPHPExcel->setActiveSheetIndex(0);

        ob_end_clean();
        ob_start();
        $file_name = 'ACSReport_'.date('Y-m-d[H-i-s]').'.xls';
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.$file_name.'"');
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');

        break;
}



//show template
$templates->show('proposal.tpl');
?>