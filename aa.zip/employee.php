<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objstates = new dbstates();

//requets parameter
$page = request_var('page', '1');
$id = request_var('id', '');
$first_name = request_var('first_name', '');
$last_name = request_var('last_name', '');
$middle_name = request_var('middle_name', '');
$address = request_var('address', '');
$city = request_var('city', '');
$state = request_var('state', '');
$zip = request_var('zip', '');
$phone1 = request_var('phone1', '');
$phone2 = request_var('phone2', '');
$email = request_var('email', '');
$ss_number = request_var('ss_number', '');
$dob = request_var('dob', '');
$sex = request_var('sex', '');
$date_hired = request_var('date_hired', '');
$commission = request_var('commission', '');
$builder_deduction = request_var('builder_deduction', '');
$status = request_var('status', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")

switch ($mode)
{
    case "view":
        //get all employees
        $where_clause = " 1 = 1 AND status = 1 ";
        if ($first_name)
            $where_clause .= " AND first_name like '%$first_name%'";
        if ($last_name)
            $where_clause .= " AND last_name like '%$last_name%'";
            
        $employees = $objuser->get_users($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', ''), request_var('sortby', 'asc'));
        $itemcount = $objuser->get_users($where_clause, 0, 0, '', '', true);
        $templates->setvar('employees', $employees);
        
        
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "details":
        if ($id)
        {
            //get employee information
            $employee_infor = $objuser->get_user_by_id($id);            
            
            $templates->setvar('employee_infor', $employee_infor);       
        }
    break;

    case "delete":
        if ($id)
        {
            //delete employee
            $objuser->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {
            //get state for select
            $states = $objstates->get_states('', 0, 0, 'state_code');
            $templates->setvar('states', $states);
            
            //get employee information
            $employee_infor = $objuser->get_user_by_id($id); 
            $templates->setvar('employee_infor', $employee_infor);    
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
            
            }
            else
            {
                $validator = true;
                
                if (trim($first_name) == '')
                {
                    $validator = false;
                    $templates->setvar('error_first_name', $lang['E_FIRST_NAME']);
                }
                if (trim($last_name) == '')
                {
                    $validator = false;
                    $templates->setvar('error_last_name', $lang['E_LAST_NAME']);
                }
                if (trim($address) == '')
                {
                    $validator = false;
                    $templates->setvar('error_address', $lang['E_ADDRESS']);
                }
                if (trim($email) == '')
                {
                    $validator = false;
                    $templates->setvar('error_email', $lang['E_EMAIL']);
                }
                else
                {
                    if (!is_valid_email($email))
                    {
                        $validator = false;
                        $templates->setvar('error_email', $lang['E_INVAID_EMAIL']);
                    }
                    else
                    {
                        $employee = $objuser->get_user_by_email($email, " email <> '". $employee_infor['email'] ."'");
                        if ($employee)
                        {
                            $validator = false;
                            $templates->setvar('error_email', $lang['E_EXIST_EMAIL']);
                        }
                    }
                }
                
                $save_employee = array('first_name' => $first_name,
                                       'middle_name' => $middle_name,
                                       'last_name' => $last_name,
                                       'address' => $address,
                                       'email' => $email,
                                       'city' => $city,
                                       'state' => $state,
                                       'zip' => $zip,
                                       'phone1' => $phone1,
                                       'phone2' => $phone2,
                                       'ss_number' => $ss_number,
                                       'dob' => convert_to_standard_date($dob),
                                       'sex' => $sex,
                                       'date_hired' => convert_to_standard_date($date_hired),
                                       'commission' => $commission,
                                       'builder_deduction' => $builder_deduction,
                                       'status' => $status);
                
                if ($validator)
                {
                    $objuser->save('UPDATE', $save_employee, " user_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('employee_infor', $save_employee);  
                }
            }
        }
    break;
    
    case "add":
        //get state for select
        $states = $objstates->get_states('', 0, 0, 'state_code');
        $templates->setvar('states', $states);
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $validator = true;
            
            if (trim($first_name) == '')
            {
                $validator = false;
                $templates->setvar('error_first_name', $lang['E_FIRST_NAME']);
            }
            if (trim($last_name) == '')
            {
                $validator = false;
                $templates->setvar('error_last_name', $lang['E_LAST_NAME']);
            }
            if (trim($address) == '')
            {
                $validator = false;
                $templates->setvar('error_address', $lang['E_ADDRESS']);
            }
            if (trim($email) == '')
            {
                $validator = false;
                $templates->setvar('error_email', $lang['E_EMAIL']);
            }
            else
            {
                if (!is_valid_email($email))
                {
                    $validator = false;
                    $templates->setvar('error_email', $lang['E_INVAID_EMAIL']);
                }
                else
                {
                    $employee = $objuser->get_user_by_email($email);
                    if ($employee)
                    {
                        $validator = false;
                        $templates->setvar('error_email', $lang['E_EXIST_EMAIL']);
                    }
                }
            }
            
            $save_employee = array('first_name' => $first_name,
                                   'middle_name' => $middle_name,
                                   'last_name' => $last_name,
                                   'address' => $address,
                                   'email' => $email,
                                   'city' => $city,
                                   'state' => $state,
                                   'zip' => $zip,
                                   'phone1' => $phone1,
                                   'phone2' => $phone2,
                                   'ss_number' => $ss_number,
                                   'dob' => convert_to_standard_date($dob),
                                   'sex' => $sex,
                                   'date_hired' => convert_to_standard_date($date_hired),
                                   'commission' => $commission,
                                   'builder_deduction' => $builder_deduction,
                                   'status' => $status);
            
            if ($validator)
            {
                $objuser->save('INSERT', $save_employee);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('employee_infor', $save_employee);  
            }
        }
    break;
}


//show template
$templates->show('employee.tpl');
?>