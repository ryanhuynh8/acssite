<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objproposals = new dbproposals();
$objproposalparts = new dbproposalparts();
$objlaborsparts = new dblabors_parts();

//requets parameter
$id = request_var('id', '');
$category = request_var('category', '');
$proposal_part_name = request_var('proposal_part_name', '');
$proposal_part_price = request_var('proposal_part_price', '');
$page = request_var('page', 1);


switch ($mode)
{
    case 'view':
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $search = request_var('search', '');
            $clear = request_var('clear', '');
            
            if ($search)
            {
                $_SESSION['category'] = $category;
                $_SESSION['proposal_part_name'] = $proposal_part_name;
            }
            if ($clear)
            {
                $_SESSION['category'] = '';
                $_SESSION['proposal_part_name'] = '';
            }
        }
        
        //get all categories proposal for select
        $categories = $objproposals->get_categories('', 0, 0, 'name');
        $templates->setvar('categories', $categories);
        //get all proposal parts
        $where_clause = ' 1 = 1';
        $where_clause .= $_SESSION['proposal_part_name'] ? " AND pp.proposal_part_name like '%". $_SESSION['proposal_part_name'] ."%'" : '';
        $where_clause .= $_SESSION['category'] ? " AND pp.proposal_category_id = " . $_SESSION['category'] : '';
        
        $parts = $objproposalparts->get_parts($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'proposal_part_id'), request_var('sortby', 'desc') );
        $itemcount = $objproposalparts->get_parts($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('parts', $parts);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case 'edit':
        if ($id)
        {
            //get all categories proposal for select
            $categories = $objproposals->get_categories('', 0, 0, 'name');
            $templates->setvar('categories', $categories);
            
            
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $part_infor = $objproposalparts->get_part_by_id($id);
                $templates->setvar('part_infor', $part_infor);
            }
            else
            {
                $error_validator = true;
                
                if ($category == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_category', $lang['E_CATEGORY']);
                }
                if ($proposal_part_name == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_part_name', $lang['E_PART_NAME']);
                }
                if ($proposal_part_price && !is_numeric($proposal_part_price) || floatval($proposal_part_price) < 0)
                {
                    $error_validator = false;
                    $templates->setvar('error_price', $lang['E_PRICE']);
                }
                
                $save_part = array('proposal_category_id' => $category,
                                   'proposal_part_name' => $proposal_part_name,
                                   'proposal_part_price' => $proposal_part_price);
                
                if ($proposal_part_price == '')
                    $save_part['proposal_part_price'] = 'NULL';
                
                if ($error_validator)
                {
                    $objproposalparts->save('UPDATE', $save_part, "proposal_part_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('part_infor', $save_part);
                }
            }
        }
    break;

    case 'add':
        //get all categories proposal for select
        $categories = $objproposals->get_categories('', 0, 0, 'name');
        $templates->setvar('categories', $categories);
        
        
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $error_validator = true;
            
            if ($category == '')
            {
                $error_validator = false;
                $templates->setvar('error_category', $lang['E_CATEGORY']);
            }
            if ($proposal_part_name == '')
            {
                $error_validator = false;
                $templates->setvar('error_part_name', $lang['E_PART_NAME']);
            }
            if ($proposal_part_price && !is_numeric($proposal_part_price) || floatval($proposal_part_price) < 0)
            {
                $error_validator = false;
                $templates->setvar('error_price', $lang['E_PRICE']);
            }
            
            $save_part = array('proposal_category_id' => $category,
                               'proposal_part_name' => $proposal_part_name);
            
            if ($proposal_part_price != '')
                $save_part['proposal_part_price'] = $proposal_part_price;
            
            if ($error_validator)
            {
                $objproposalparts->save('INSERT', $save_part);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('part_infor', $save_part);
            }
        }
    break;

    case 'details':
        if ($id)
        {            
            $part_infor = $objproposalparts->get_parts("proposal_part_id = $id", 0, 0);
            $templates->setvar('part_infor', $part_infor[0]);
        }
    break;

    case "delete":
        if ($id)
        {
            $objproposalparts->delete($id);
            
            $templates->setvar('delete_success', true);
        }
    break;
}



//show template
$templates->show('proposalparts.tpl');
?>