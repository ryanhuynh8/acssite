<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objNotification = new dbnotification();

//requets parameter
$emails = $_POST['email'];

switch ($mode)
{
    case "view":
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            $notifications = $objNotification->getNotifications();
			
			$templates->setvar('notifications', $notifications);
        }
        else
        {
            $validator = true;
            $errors = array();
			if ($emails)
			{
				foreach ($emails as $key=>$value)
				{
					if (!$value)
					{					
						$validator = false;
						$errors[$key] = $lang['E_EMAIL_REQUIRED'];
					}
					elseif (!is_valid_email($value))
					{
						$validator = false;
						$errors[$key] = $lang['E_EMAIL_INVALID'];
					}
				}
			}
			
			if ($validator)
			{
				//delete old records
				$objNotification->delete();
				if ($emails)
				{
					foreach ($emails as $entry)
						$objNotification->save('INSERT', array('email'=>$entry) );
				}
				
				$templates->setvar('save_success', true);
			}
			else
			{
				$templates->setvar('notifications', $emails);
				$templates->setvar('error_email', $errors);
			}
		}
    break;
}



//show template
$templates->show('inventory_notification.tpl');
?>