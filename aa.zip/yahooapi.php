<?php
session_start();
ob_start();
/*
require_once("/var/www/html/includes/config.php");
require_once("/var/www/html/includes/constants.php");

require_once("/var/www/html/includes/dbl.php");
require_once("/var/www/html/dataaccessor/dbrealtime.php");
require_once("/var/www/html/dataaccessor/dbbuilders.php");
require_once("/var/www/html/includes/xmltoarrayparser.php");
require_once("/var/www/html/dataaccessor/dbyahooapi.php");
*/

require_once("includes/config.php");
require_once("includes/constants.php");
require_once("includes/dbl.php");
require_once("dataaccessor/dbrealtime.php");
require_once("dataaccessor/dbbuilders.php");
require_once("includes/xmltoarrayparser.php");
require_once("dataaccessor/dbyahooapi.php");

set_time_limit(0);
$dbrealtime = new dbrealtime();

$objyahoo = new dbyahooapi();
$yahoo_info = $objyahoo->get_yahoo_api();
//var_dump($yahoo_info);
$php_userid = $yahoo_info['user_name'];//'acsabsolutecomfort@yahoo.com';//
$php_password = $yahoo_info['password'];//'summer2007';
//$php_userid = 'acsabsolutecomfort@yahoo.com';//
//$php_password = 'summer2007';


$cookie_file_path = "./cookie.txt"; // Please set your Cookie File path


$fp = fopen($cookie_file_path,'wb'); 
fclose($fp);
$agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.4) Gecko/20030624 Netscape/7.1 (ax)";
$agent = "Mozilla/5.0 (X11; Linux i686; rv:6.0) Gecko/20100101 Firefox/6.0";
$reffer = "http://mail.yahoo.com/";

// log out.
$LOGINURL = "http://us.ard.yahoo.com/SIG=12hoqklmn/M=289534.5473431.6553392.5333790/D=mail/S=150500014:HEADR/Y=YAHOO/EXP=1135053978/A=2378664/R=4/SIG=133erplvs/*http://login.yahoo.com/config/login?logout=1&.done=http://mail.yahoo.com/&.src=ym&.lg=us&.intl=us";
//$LOGINURL = "https://login.yahoo.com/config/login?.src=oauth2&.partner=&.pd=c%3DmZmAFpe.2e7WuWzcHD2ZPYQ-%26ockey%3Ddj0yJmk9M2ZCTHVhRDdNanNBJmQ9WVdrOWFtVndabWMxTm5NbWNHbzlNVFUxT0RJME1EUTJNZy0tJnM9Y29uc3VtZXJzZWNyZXQmeD03Yw--&.intl=us&.done=https%3A%2F%2Fapi.login.yahoo.com%2Foauth%2Fv2%2Frequest_auth%3Foauth_token%3Dkszadbv%26.intl%3Dus%26crumb%3D&rl=1";
//echo $LOGINURL . "<br />"; 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL,$LOGINURL);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
$result = curl_exec ($ch);
curl_close ($ch);

//1. Get first login page to parse hash_u,hash_challenge

$LOGINURL = "http://mail.yahoo.com"; 
//echo $LOGINURL . "<br />";
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL,$LOGINURL);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
$loginpage_html = curl_exec ($ch);
curl_close ($ch); 
//echo $loginpage_html;

preg_match_all("/name=\".u\" value=\"(.*?)\"/", $loginpage_html, $arr_hash_u);
preg_match_all("/name=\".challenge\" value=\"(.*?)\"/", $loginpage_html, $arr_hash_challenge);

//var_dump($arr_hash_u);
//var_dump($arr_hash_challenge);
$hash_u = $arr_hash_u[1][0];
$hash_challenge = $arr_hash_challenge[1][0];

// 2- Post Login Data to Page https://login.yahoo.com/config/login?

$LOGINURL = "https://login.yahoo.com/config/login?";
$POSTFIELDS = '.tries=1&.src=ym&.md5=&.hash=&.js=&.last=&promo=&.intl=us&.bypass=&.partner=&.u='.$hash_u.'&.v=0&.challenge='.$hash_challenge.'&.yplus=&.emailCode=&pkg=&stepid=&.ev=&hasMsgr=0&.chkP=Y&.done=http%3A%2F%2Fmail.yahoo.com&login='.$php_userid.'&passwd='.$php_password;
//echo $LOGINURL . $POSTFIELDS. "<br />";
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL,$LOGINURL);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_POST, 1); 
curl_setopt($ch, CURLOPT_POSTFIELDS,$POSTFIELDS); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_REFERER, $reffer);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file_path);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file_path);
$result = curl_exec ($ch);
curl_close ($ch); 

$myFile = "welcomecontent.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
fwrite($fh, $result);
fclose($fh);

preg_match_all("/replace\(\"(.*?)\"/", $result, $arr_url); 
//var_dump($arr_url);
$WelcomeURL = $arr_url[1][0];

$mailBoxUrl =$WelcomeURL;// substr($WelcomeURL, 0, strpos($WelcomeURL, "/welcome"));
//var_dump($arr_url);
$WelcomeURL =$WelcomeURL;// substr($WelcomeURL, 0, strpos($WelcomeURL, "/welcome"));
// 3- Redirect to Welcome page. (Login Success)
//echo $WelcomeURL . "<br />";
$result = wrapcontent($WelcomeURL, $cookie_file_path);

$regexp = '/(href)=("showFolder\?fid=Inbox[^"]*")/i';
preg_match_all("$regexp", $result, $matches);
var_dump($matches);
$inboxUrl = str_replace('"', "", $matches[0][0]);
$inboxUrl = str_replace("href=", "/", $inboxUrl);

//get email detail link
//$addressURL = substr($WelcomeURL, 0, strpos($WelcomeURL, "/welcome")) . $inboxUrl;
$addressURL=$WelcomeURL.$inboxUrl;
$result = wrapcontent($addressURL, $cookie_file_path);

echo ($addressURL);
$regexp = '/(href)=("showMessage[^"]*")/i';
preg_match_all("$regexp", $result, $matches);

$returnData = array();

for ($i=24; $i >= 0; $i--)
{
     $mail = str_replace('"', "", $matches[0][$i]);
     $mail = str_replace("href=", "/", $mail);

    if (strlen($mail) > 5)
    {
        $result = wrapcontent($mailBoxUrl . $mail, $cookie_file_path);
        echo $mailBoxUrl . $mail  . "<br />";
        /*$myFile = "finishedlogin" . $i . ".txt";
		$fh = fopen($myFile, 'w') or die("can't open file");
		fwrite($fh, $result);
		fclose($fh);*/

        $regexp = '/<div id\=\"mailContent\">(.*?)<\/div>/s';
        preg_match("$regexp", $result, $content);
        
        $regexp = '/<h1 id\=\"message_view_subject\">(.*?)<\/h1>/s';
        preg_match("$regexp", $result, $title);
        
        $regexp = '/<div id\=\"message_view_date\" class\=\"date\">(.*?)<\/div>/s';
        preg_match("$regexp", $result, $date);
        
        $regexp = '/<div class=\"details\">(.*?)<\/div>/s';
        preg_match_all("$regexp", $result, $from);

        $returnData = array("date" => strip_tags($date[1]), "title" =>  strip_tags($title[0]), "emailcontent" =>  $content[0]);
        $email_date = strtotime(trim(strip_tags($date[1])));
        $customermail = substr($mail, strpos($mail, "fromId=") + 7);

        //echo $returnData["title"];
        if (strpos($returnData["title"], "Dispatch") !== false)
        {
        	
            $regexp = '/(href)=("\/mc\/showMessage\?fid=Inbox&sort=date[^"]*")/i';
            preg_match_all("$regexp", $result, $attachment);
            //has xml attacment file 
            /*var_dump($attachment);
            $fp = fopen($returnData["title"] . '.txt', 'w');
			fwrite($fp, $result);
			fclose($fp);*/
            
            if ($attachment[2][0] != "")
            {
                $xml = get_attachment_xml($attachment[2][0]);
                //echo $xml;
                $data = ParserXmlToData($xml, $returnData["emailcontent"], $customermail, $email_date)   ;
                //var_dump($data);
            }
            else
                $data = ParserMailContent($returnData["emailcontent"], $customermail, $email_date);
        }
        else if(strpos($returnData["title"], "Voicemail") !== false)
        {
             $data = ParserMissCallEmail($returnData["emailcontent"], $customermail, $email_date);
             echo $returnData["emailcontent"];
        }
        
        $result = $dbrealtime->get_realtime("rb.dispatchID = " . $dbrealtime->escape($data["dispatchID"]) . " and (rb.status = 1 or rb.status = 3)", null);
        if (strpos($returnData["title"], "Dispatch") !== false && (!is_array($result) || count($result) == 0))
        {
            $dbrealtime->savemsgfromapi($data, $email_date);
            echo $dbrealtime->error_msg;     
        }
        else if(strpos($returnData["title"], "voicemail") !== false)
        {
            $dbrealtime->savemsgfromapi($data, $email_date);
        }
        
    } 
}

function get_attachment_xml($attachurl)
{
    global $mailBoxUrl, $cookie_file_path;
    
    $attachurl = str_replace('"', '', $attachurl);
    $attachurl = str_replace('/mc', '', $attachurl);
    //make virus scan on Yahoo
    //echo $mailBoxUrl . $attachurl;
    $xml = wrapcontent($mailBoxUrl . $attachurl, $cookie_file_path);
    //echo $xml;
    $regexp = '/(href)=("http\:\/\/us.f[^"]*")/i';
    //get download link
    preg_match_all("$regexp", $xml, $downloadlink);
    //var_dump($downloadlink);
    //get attachmment file
    $xml = wrapcontent(str_replace('"', "", $downloadlink[2][0]), $cookie_file_path);
    
    return $xml;
}

function wrapcontent($url, $cookiepath)
{
    global $agent, $reffer;
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_REFERER, $reffer);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookiepath);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookiepath);
    $result = curl_exec ($ch);
    curl_close ($ch);
    return $result;
}

function ParserXmlToData($xml, $content, $email, $mgsdate)
{
    $builderdb = new dbbuilders();
    $mailContent = CleanUpEmailContent($content);
    
    //echo $xml;
    $domObj = new xmlToArrayParser($xml); 
    $domArr = $domObj->array;
    
    

    $dispatchID = $domArr['VendorDispatch']['DispatchList']['_']['Id'];    
    $customerName = $domArr['VendorDispatch']['ContractCustomerList']['ContractCustomer']['_']['Name'];
    if (count($domArr['VendorDispatch']['ContractCustomerList']['ContractCustomer']['PhoneNumber']) > 1)
    {
        $phone1 = $domArr['VendorDispatch']['ContractCustomerList']['ContractCustomer']['PhoneNumber'][0]["_"]['Number'] ;
        $phone2 = $domArr['VendorDispatch']['ContractCustomerList']['ContractCustomer']['PhoneNumber'][1]["_"]['Number'] ;
    }
    else
        $phone1 = $domArr['VendorDispatch']['ContractCustomerList']['ContractCustomer']['PhoneNumber']["_"]['Number'] ;
    
    //var_dump($domArr['VendorDispatch']['Contract']['CoveredProperty']['_']);
    $address = $domArr['VendorDispatch']['Contract']['CoveredProperty']['_']['StreetNumber'] . " " . $domArr['VendorDispatch']['Contract']['CoveredProperty']['_']['StreetName'];
    $city = $domArr['VendorDispatch']['Contract']['CoveredProperty']['_']['CityName'];
    $state = $domArr['VendorDispatch']['Contract']['CoveredProperty']['_']['StateCode'];
    $zipcode = $domArr['VendorDispatch']['Contract']['CoveredProperty']['_']['ZipPostCode'];
    $urgency = $domArr['VendorDispatch']['DispatchList']['_']['dispatchPriorityValueList'];
    $note = "";
    if (! is_array($domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']["_"]))
    {
        for($work = 0; $work < count($domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']); $work++ )
        {
            $note .= $domArr['VendorDispatch']['DispatchList']['WorkOrderLineList'][$work]['_']['Description'];
            if (! is_array($domArr['VendorDispatch']['DispatchList']['WorkOrderLineList'][$work]['Symptom']['_']))
            {
                for($i = 0; $i < count($domArr['VendorDispatch']['DispatchList']['WorkOrderLineList'][$work]['Symptom']); $i++ )
                {
                    $note1 .= $domArr['VendorDispatch']['DispatchList']['WorkOrderLineList'][$work]['Symptom'][$i]['_']['Name'] . "\n";
                     
                }
                
            }
            else
            {
                $note1 .= $domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']['Symptom']['_']['Name'];
            }
            $note  .= ":" . $note1 . "\n";  
        }
    }
    else
    {
        $note = $domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']['_']['Description'];
        if (! is_array($domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']['Symptom']["_"]))
        {
            for($i = 0; $i < count($domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']['Symptom']); $i++ )
            {
                $note1 .= $domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']['Symptom'][$i]['_']['Name'] . "\n";    
            }    
        }
        else
            $note1 .= $domArr['VendorDispatch']['DispatchList']['WorkOrderLineList']['Symptom']['_']['Name'];
            
        $note  .= ":" . $note1 . "\n";    
    }

    
    
    $builder = $domArr['VendorDispatch']['Vendor']['_']['Name'];
    $builderid = $builderdb->check_existed_builder($builder);
    if ($builderid == 0 && $domArr['VendorDispatch']['Vendor']['_']['Name'] != "")
    {
        $buildernew = array(
                                "full_name" =>  $builder,
                                "address"   =>  $domArr['VendorDispatch']['Vendor']['CommercialProperty']['_']['StreetNumber'] . " " . $domArr['VendorDispatch']['Vendor']['CommercialProperty']['_']['StreetName'],
                                "city"   =>  $domArr['VendorDispatch']['Vendor']['CommercialProperty']['_']['CityName'],
                                "state"   =>  $domArr['VendorDispatch']['Vendor']['CommercialProperty']['_']['StateCode'],
                                "zip"   =>  $domArr['VendorDispatch']['Vendor']['CommercialProperty']['_']['ZipPostCode'],
                                "phone1"    =>  $domArr['VendorDispatch']['Vendor']['PhoneNumber'][0]['_']['Number'],
                                "fax"   =>  $domArr['VendorDispatch']['Vendor']['PhoneNumber'][1]['_']['Number'],
                                "office_number" =>  $domArr['VendorDispatch']['Vendor']['_']['Id']
                            );
        $builderid = $builderdb->save("INSERT", $buildernew, "");
    }
    if (!$builderid || $builderid == 0)	
    	$builderid = 20;	
    $data = array(
        "dispatchID" =>  $dispatchID ,
        "customer_name"  =>  $customerName,
        "customer_email"  =>  trim(str_replace(":", "", $email)),
        "phone"     =>  $phone1,
        "phone2"     =>  $phone2,
        "address"   =>  $address,
        "state" =>  $state,
        "city"  =>  $city,
        "zipcode"   =>  $zipcode,
        "urgency"   =>  $urgency,
        "description" =>  trim($mailContent),
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  $mgsdate,
        "board_system"  =>  1,
        "note"  =>  $note 
        
        
     );
     //var_dump($data);
    return $data;
}

function CleanUpEmailContent($content)
{
    $mailContent = preg_replace("/(\<script)(.*?)(script>)/si", "", $content);
    $mailContent = str_replace("\r\n", "\n", $mailContent);
    $mailContent = str_replace("\r", "\n", $mailContent);
    $mailContent = str_replace("<br>", "\r\n", $mailContent);
    $mailContent = str_replace("<br />", "\n", $mailContent);
    $mailContent = str_replace("<BR>", "\n", $mailContent);
    $mailContent = str_replace("&nbsp;", " ", $mailContent);
    $mailContent = str_replace("\t", "", $mailContent);
    $mailContent = preg_replace('/[\x80-\xFF]/', ' ', $mailContent);
    $mailContent = iconv("UTF-8","ISO-8859-1//IGNORE",$mailContent);
    $mailContent = str_replace("</tr>", "\n", $mailContent);
    $mailContent = strip_tags($mailContent);
    return $mailContent;
}

function ParserMissCallEmail($content, $email, $mgsdate, $subject)
{
     $data = array();
     $mailContent = CleanUpEmailContent($content);
     
     $temp = substr($mailContent, strpos($mailContent, "From") + 4, strpos($mailContent, "To") - strpos($mailContent, "From") - 4);
     $customer = substr($temp, 0, strpos($temp, "(") - 1 );
     $phone  = substr($temp, strpos($temp, "(") + 1 , strpos($temp, ")") - strpos($temp, "(") - 1);
     $data = array(
          "customer_name"  =>  trim(str_replace(":", "", $customer)),
          "customer_email"  =>  trim(str_replace(":", "", $email)),
          "phone"     =>  trim(str_replace(":", "", $phone)),
          "status"    =>   1,
          "time_received"  =>   date("Y-m-d h:i:s"),
          "msg_time"    =>  $mgsdate,
          "board_system"  =>  2,
          "description" =>  trim(substr($mailContent, 0, strpos($mailContent, '---')))
          );
     return $data;
}

    
function ParserMailContent($content, $email, $mgsdate)
{
     $data = array();
    $mailContent = CleanUpEmailContent($content);
    $dispatchID = substr($mailContent, strpos($mailContent, "Dispatch ID") + 12, strpos($mailContent, "Dispatch Date:") - strpos($mailContent, "Dispatch ID") - 12);     
    $customer = substr($mailContent, strpos($mailContent, "Customer:") + 10, strpos($mailContent, "Buyer") - strpos($mailContent, "Customer:") - 10);
    $phone  = substr($mailContent, strpos($mailContent, "Buyer") + 6, strpos($mailContent, "Property Address:") - strpos($mailContent, "Buyer") - 16);
    $urgency = substr($mailContent, strpos($mailContent, "Urgency") + 8, strpos($mailContent, "Service Fee Paid") - strpos($mailContent, "Urgency") - 8);
    $addressorg = substr($mailContent, strpos($mailContent, "Property Address") + 17, strpos($mailContent, "Dispatch Contact(s)") - strpos($mailContent, "Property Address") - 17);
    $address = substr($addressorg, 0, strpos($addressorg, "\n"));
   
    $city = substr($addressorg, strpos($addressorg, "\n"),  strpos($addressorg, ",") - strpos($addressorg, "\n"));
    $stateandzip = substr($addressorg, strpos($addressorg, ","));
    $state = substr($stateandzip, 0, strpos($stateandzip, " "));
    $zipcode = substr($stateandzip, strpos($stateandzip, " "));
    if (strpos($phone, " - Primary Phone") !== false)
    {
      $phone1 = substr($phone, 0, strpos($phone, " - Primary Phone"));
      $phone2 = substr($phone, strpos($phone, " - Primary Phone") + 17);
    }
    else
    {
      $phone1 = str_replace("- Home", "", $phone);
    }  
    $data = array(
       "dispatchID" =>  trim(str_replace(":", "", $dispatchID)) ,
       "customer_name"  =>  trim(str_replace(":", "", $customer)),
       "customer_email"  =>  trim(str_replace(":", "", $email)),
       "phone"     =>  trim($phone1),
       "phone2"    =>  trim($phone2),  
       "address"   =>  trim(str_replace(":", "", $address)),
       "city"      =>    trim($city),
       "state"      =>  trim($state),
       "zipcode"    =>  substr($zipcode, 0, 5), 
       "urgency"   =>  trim(str_replace(":", "", $urgency)),
       "description" =>  trim($mailContent),
       "status"    =>   1,
       "time_received"  =>   date("Y-m-d h:i:s"),
       "msg_time"    =>  $mgsdate,
       "board_system"  =>  1 
       
    );
    //var_dump($data);
     return $data;
}

 
?>