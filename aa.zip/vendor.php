<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objvendors = new dbvendors();
$objstates = new dbstates();

//requets parameter
$page = request_var('page', '1');
$id = request_var('id', '');
$full_name = request_var('full_name', '');
$address = request_var('address', '');
$city = request_var('city', '');
$state = request_var('state', '');
$zip = request_var('zip', '');
$phone1 = request_var('phone1', '');
$phone2 = request_var('phone2', '');
$email = request_var('email', '');
$keymap = request_var('keymap', '');

switch ($mode)
{
    case "view":
        //get all vendors
        $where_clause = " 1 = 1";
        if ($full_name)
            $where_clause .= " AND full_name like '%$full_name%'";
        
        $vendors = $objvendors->get_vendors($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', ''), request_var('sortby', 'asc') );
        $itemcount = $objvendors->get_vendors($where_clause, 0, 0, '', '', true);
        $templates->setvar('vendors', $vendors);
        
        
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "details":
        if ($id)
        {
            //get vendor information
            $vendor_infor = $objvendors->get_vendor_by_id($id);
            
            $templates->setvar('vendor_infor', $vendor_infor);         
        }
    break;

    case "delete":
        if ($id)
        {
            //delete vendor
            $objvendors->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {
            //get state for select
            $states = $objstates->get_states('', 0, 0, 'state_code');
            $templates->setvar('states', $states);
            
            //get vendor information
            $vendor_infor = $objvendors->get_vendor_by_id($id);                
            $templates->setvar('vendor_infor', $vendor_infor);  
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                
            }
            else
            {
                $validator = true;
            
                if (trim($full_name) == '')
                {
                    $validator = false;
                    $templates->setvar('error_full_name', $lang['E_NAME']);
                }
                if (trim($address) == '')
                {
                    $validator = false;
                    $templates->setvar('error_address', $lang['E_ADDRESS']);
                }
                if (trim($email) == '')
                {
                    $validator = false;
                    $templates->setvar('error_email', $lang['E_EMAIL']);
                }
                else
                {
                    if (!is_valid_email($email))
                    {
                        $validator = false;
                        $templates->setvar('error_email', $lang['E_INVAID_EMAIL']);
                    }
                    else
                    {
                        $vendors = $objvendors->get_vendor_by_email($email, " email <> '". $vendor_infor['email'] ."'");
                        if ($vendors)
                        {
                            $validator = false;
                            $templates->setvar('error_email', $lang['E_EXIST_EMAIL']);
                        }
                    }
                }
                
                $save_vendor = array(   'full_name' => $full_name,
                                        'address' => $address,
                                        'city' => $city,
                                        'state' => $state,
                                        'zip' => $zip,
                                        'phone1' => $phone1,
                                        'phone2' => $phone2,
                                        'email' => $email,
                                        'keymap' => $keymap);
                
                if ($validator)
                {
                    $objvendors->save('UPDATE', $save_vendor, "vendor_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('vendor_infor', $save_vendor); 
                }
            }
        }
    break;
    
    case "add":
        //get state for select
        $states = $objstates->get_states('', 0, 0, 'state_code');
        $templates->setvar('states', $states);
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $validator = true;
            
            if (trim($full_name) == '')
            {
                $validator = false;
                $templates->setvar('error_full_name', $lang['E_NAME']);
            }
            if (trim($address) == '')
            {
                $validator = false;
                $templates->setvar('error_address', $lang['E_ADDRESS']);
            }
            if (trim($email) == '')
            {
                $validator = false;
                $templates->setvar('error_email', $lang['E_EMAIL']);
            }
            else
            {
                if (!is_valid_email($email))
                {
                    $validator = false;
                    $templates->setvar('error_email', $lang['E_INVAID_EMAIL']);
                }
                else
                {
                    $vendors = $objvendors->get_vendor_by_email($email);
                    if ($vendors)
                    {
                        $validator = false;
                        $templates->setvar('error_email', $lang['E_EXIST_EMAIL']);
                    }
                }
            }
            
            $save_vendor = array(   'full_name' => $full_name,
                                    'address' => $address,
                                    'city' => $city,
                                    'state' => $state,
                                    'zip' => $zip,
                                    'phone1' => $phone1,
                                    'phone2' => $phone2,
                                    'email' => $email,
                                    'keymap' => $keymap);
            
            if ($validator)
            {
                $objvendors->save('INSERT', $save_vendor);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('vendor_infor', $save_vendor); 
            }
        }
    break;
}



//show template
$templates->show('vendor.tpl');
?>