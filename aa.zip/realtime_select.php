<?php
require_once ("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global;
$objrealtime = new dbrealtime ();
$objnotes = new dbrealtimenotes ();
$objtickets = new dbtickets ();
$objcustomers = new dbcustomers ();
$rt_id = request_var ( 'id', '' );
$sortby = request_var ( 'sortby', '' );
$notes = request_var ( 'txtnote', '' );
$scomlete = request_var ( 'comlete_x', '' );
$supdate = request_var ( 'update_x', '' );
$myuserID = $authenticate->get_user_id ();
$cURL = $_SESSION ["cURL"];

if ($scomlete > 0) {
	$mode = 'completed';
} elseif ($supdate > 0) {
	$mode = 'update';
} else {
	$mode = 'select';
}
if ($_SERVER ['REQUEST_METHOD'] == "POST") {
	if ($notes) {
		$notesinfo = array ("notes" => $notes, "realtime_id" => $rt_id, "userid" => $myuserID, "create_date" => date ( "Y-m-d H:i:s" ) );
		$cur_msg_id = $objnotes->save_realtimenotes ( "INSERT", $notesinfo, "" );
	}
}

$where_pending = " 1 = 1 AND (rb.id =" . $rt_id . ")";
$realtimelist = $objrealtime->get_realtime ( $where_pending, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby );
$realtimelist = $realtimelist [0];



switch ($mode) {
	
	case 'select' :
		
	break;
	case 'update' :
		if ($rt_id) {
			if ($realtimelist ['status'] == 1)
			{
				$parameters = array ('userID' => $myuserID, 'status' => 3, 'note' => $notes );
				$objrealtime->save ( 'UPDATE', $parameters, "id = $rt_id" );
				
				echo '<script language="javascript">top.window.location.href="' . $cURL . '"</script>'; 
			}
		}
	break;
	//---------------complete Real Time------------------------------------------------
	case 'completed' :
		if ($rt_id) {
			if ($realtimelist ['board_system'] == 2) {
				$parameters = array ('userID' => $myuserID, 'status' => 2, 'time_completed' => date ( "Y-m-d h:i:s" ) );
			} else {
				$parameters = array ('userID' => $myuserID, 'status' => 2, 'time_completed' => date ( "Y-m-d h:i:s" ) );
			}
			
			$objrealtime->save ( 'UPDATE', $parameters, "id = $rt_id" );
			//------- save ticket------------------------------------------------------------------
			

			$objtickets->get_auto_office_id ( $office_id );
            //$objtickets->get_auto_invoice_no ( $invoice_number );
            $objtickets->get_auto_invoice_no_realtime ( $invoice_number );// without R
			if($realtimelist['urgency']=='PM'){

              //$save_ticket = array ('status_service_id' => 1, 'invoice_number' => $invoice_number, 'office_number' => 'PM', 'dispatch_id' => $realtimelist ["dispatchID"], 'job_date' => date ( 'Y-m-d' ), 'client_name' => $realtimelist ["customer_name"], 'client_address' => $realtimelist ["address"], 'client_city' => $realtimelist ["city"], 'client_state' => $realtimelist ["state"], 'client_zip' => $realtimelist ["zipcode"], 'client_email' => $realtimelist ["customer_email"], 'client_phone' => $realtimelist ["phone"], 'office_notes' => $notes, 'builder_id' => $realtimelist ['builder_id'], 'posted_by' => date ( "Y-m-d" ), 'home_builder_note' => $realtimelist ['description'], 'created_date' => date ( "Y-m-d" ) );
                $save_ticket = array ('status_service_id' => 1, 'invoice_number' => $invoice_number, 'office_number' => 'PM', 'dispatch_id' => $realtimelist ["dispatchID"], 'job_date' => date ( 'Y-m-d' ), 'client_name' => $realtimelist ["customer_name"], 'client_address' => $realtimelist ["address"], 'client_city' => $realtimelist ["city"], 'client_state' => $realtimelist ["state"], 'client_zip' => $realtimelist ["zipcode"], 'client_email' => $realtimelist ["customer_email"], 'client_phone' => $realtimelist ["phone"], 'office_notes' => $notes, 'builder_id' => 31, 'posted_by' => date ( "Y" ), 'home_builder_note' => $realtimelist ['description'], 'created_date' => date ( "Y-m-d" ) );
              $save_customer = array ('full_name' => $realtimelist ["customer_name"], 'address' => $realtimelist ["address"], 'phone1' => $realtimelist ["phone"], 'phone2' => $realtimelist ["phone2"], 'city' => $realtimelist ["city"], 'state' => $realtimelist ["state"], 'zip' => $realtimelist ["zipcode"], 'email' => $realtimelist ["customer_email"], 'builder_id_1' => 19, 'builder_id_2' => 20,'builder_id_3'=>31);

            }else{
                //$save_ticket = array ('status_service_id' => 1, 'invoice_number' => $invoice_number, 'office_number' => $office_id, 'dispatch_id' => $realtimelist ["dispatchID"], 'job_date' => date ( 'Y-m-d' ), 'client_name' => $realtimelist ["customer_name"], 'client_address' => $realtimelist ["address"], 'client_city' => $realtimelist ["city"], 'client_state' => $realtimelist ["state"], 'client_zip' => $realtimelist ["zipcode"], 'client_email' => $realtimelist ["customer_email"], 'client_phone' => $realtimelist ["phone"], 'field_notes' => $notes, 'builder_id' => $realtimelist ['builder_id'], 'posted_by' => date ( "Y-m-d" ), 'home_builder_note' => $realtimelist ['description'], 'created_date' => date ( "Y-m-d" ) );
                $save_ticket = array ('status_service_id' => 1, 'invoice_number' => $invoice_number, 'office_number' => $office_id, 'dispatch_id' => $realtimelist ["dispatchID"], 'job_date' => date ( 'Y-m-d' ), 'client_name' => $realtimelist ["customer_name"], 'client_address' => $realtimelist ["address"], 'client_city' => $realtimelist ["city"], 'client_state' => $realtimelist ["state"], 'client_zip' => $realtimelist ["zipcode"], 'client_email' => $realtimelist ["customer_email"], 'client_phone' => $realtimelist ["phone"], 'field_notes' => $notes, 'builder_id' => 19, 'posted_by' => date ( "Y" ), 'home_builder_note' => $realtimelist ['description'], 'created_date' => date ( "Y-m-d" ) );

                $save_customer = array ('full_name' => $realtimelist ["customer_name"], 'address' => $realtimelist ["address"], 'phone1' => $realtimelist ["phone"], 'phone2' => $realtimelist ["phone2"], 'city' => $realtimelist ["city"], 'state' => $realtimelist ["state"], 'zip' => $realtimelist ["zipcode"], 'email' => $realtimelist ["customer_email"], 'builder_id_1' => 19, 'builder_id_2' => 20,'builder_id_3'=>31 );
            }
			$customer_id = 0;
			if ($realtimelist ['board_system'] != 2) {
				$customers = $objcustomers->check_exist_customer ( $save_customer );

				if ($customers) {

					$customer_id = $customers [0] ['customer_id'];
                    if($realtimelist['urgency']=='PM')
                        $objcustomers->save("UPDATE",$save_customer,'customer_id='.$customer_id);
				} else {
					//insert new customer
					$customer_id = $objcustomers->save ( 'INSERT', $save_customer );

				}
				$save_ticket ['customer_id'] = $customer_id;
                // build office note:
                /*$officeNote = '
                Dispatch ID: '.$realtimelist ['dispatchID'].'<br/>
                Dispatch Date: '.$realtimelist ['Dispatch_Date'].'<br/>
                Property Address: '.$realtimelist ['address'].'<br/>
                '.$realtimelist ['city'].', '.$realtimelist ['state'].' .'.$realtimelist ['zip'].'<br/>
                Customer: '.$realtimelist ['customer_name'].'--'.$realtimelist ['phone'].'<br/>
                Effective Date: '.$realtimelist ['Effective_Date'].'<br/>
                Expiration Date: '.$realtimelist ['Expiration_Date'].'
                ';*/
                if(
                    $realtimelist['urgency']=='PM' &&
                    isset($realtimelist ['Effective_Date']) && trim($realtimelist ['Effective_Date'])!=''&&
                    isset($realtimelist ['Expiration_Date']) && trim($realtimelist ['Expiration_Date'])!=''
                ){
                    $officeNote = '
                Dispatch Date: '.$realtimelist ['Dispatch_Date'].'<br/>
                Effective Date: '.$realtimelist ['Effective_Date'].'<br/>
                Expiration Date: '.$realtimelist ['Expiration_Date'].'<br/>
                Dispatch Notes: '.$realtimelist ['note'].'
                ';

                    $save_ticket ['office_notes'] = $officeNote;
                }
				//insert new ticket                
				$ticket_id = $objtickets->save ( 'INSERT', $save_ticket );
			}
			//------- end save ticket------------------------------------------------------------------ 
			echo '<script language="javascript">top.window.location.href="' . $cURL . '"</script>';
		}
		break;
}

$where_pending = " 1 = 1 AND (rb.id =" . $rt_id . ")";
$realtimelist = $objrealtime->get_realtime ( $where_pending, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby );
$realtimelist = $realtimelist [0];

$templates->setvar ( "realtimelist", $realtimelist );
$templates->show ( 'realtime_select.tpl' );
?>