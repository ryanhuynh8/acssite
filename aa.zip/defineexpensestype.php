<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objdefineexpense = new dbdefineexpense();

//requets parameter
$page = request_var('page', '1');
$id = request_var('id', '');
$description = request_var('description', '');
$type = request_var('type', '');
$fixed_amount = request_var('fixed_amount', '');

switch ($mode)
{
    case "view":
        //get all labors
        $where_clause = " 1 = 1";
        if ($description)
            $where_clause .= " AND description like '%$description%'";
        
        $define_expenses = $objdefineexpense->get_defineexpenses($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', ''), request_var('sortby', 'asc') );
        $itemcount = $objdefineexpense->get_defineexpenses($where_clause, 0, 0, '', '', true);
        $templates->setvar('define_expenses', $define_expenses);
        
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "delete":
        if ($id)
        {
            //delete labor
            $objdefineexpense->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {
            //get labor information
            $expense_infor = $objdefineexpense->get_define_expense_by_id($id);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {  
                $templates->setvar('expense_infor', $expense_infor);               
            }
            else
            {
                $validator = true;
            
                if (trim($description) == '')
                {
                    $validator = false;
                    $templates->setvar('error_description', $lang['E_DESCRIPTION']);
                }
                if (trim($type) == '')
                {
                    $validator = false;
                    $templates->setvar('error_type', $lang['E_TYPE']);
                }
                if (trim($fixed_amount) != '' &&  ( !is_numeric($fixed_amount) || $fixed_amount < 0) )
                {
                    $validator = false;
                    $templates->setvar('error_fixed_amount', $lang['E_FIXED_AMOUNT_NUMBERIC']);
                }
                
                $save_expense = array('description' => $description,
                                      'type' => $type,
                                      'fixed_amount' => $fixed_amount);
                
                
                if ($validator)
                {
                    $objdefineexpense->save('UPDATE', $save_expense, " define_expense_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {                    
                    $templates->setvar('expense_infor', $save_expense);  
                }
            }
        }
    break;
    
    case "add":        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $validator = true;
            
            if (trim($description) == '')
            {
                $validator = false;
                $templates->setvar('error_description', $lang['E_DESCRIPTION']);
            }
            if (trim($type) == '')
            {
                $validator = false;
                $templates->setvar('error_type', $lang['E_TYPE']);
            }
            if (trim($fixed_amount) != '' && ( !is_numeric($fixed_amount) || $fixed_amount < 0) )
            {
                $validator = false;
                $templates->setvar('error_fixed_amount', $lang['E_FIXED_AMOUNT_NUMBERIC']);
            }
            
            $save_expense = array('description' => $description,
                                  'type' => $type,
                                  'fixed_amount' => $fixed_amount);
            
            
            if ($validator)
            {
                $objdefineexpense->save('INSERT', $save_expense);
                
                $templates->setvar('save_success', true);
            }
            else
            {                    
                $templates->setvar('expense_infor', $save_expense);  
            }
        }
    break;
}



//show template
$templates->show('defineexpensestype.tpl');
?>