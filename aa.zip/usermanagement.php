<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objrole = new dbroles();

//requets parameter
$id = request_var('id', '');
$name = request_var('name', '');
$first_name = request_var('first_name', '');
$middle_name = request_var('middle_name', '');
$last_name = request_var('last_name', '');
$user_name = request_var('user_name', '');
$email = request_var('email', '');
$role_id = request_var('role_id', '');
$status = request_var('status', '');
$password = request_var('password', '');
$send_email = request_var('send_email', '');
$page = request_var('page', 1);
$password = request_var('password', '');
$confirm_password = request_var('confirm_password', '');

switch ($mode)
{
    case "view":
        //get roles for select
        $roles = $objrole->get_roles();
        
        //get all users
        $where_clause = ' 1 = 1';
        $where_clause .= $name ? " AND (u.first_name like '%$name%' OR u.last_name like '%$name%')" : "";
        $where_clause .= $user_name ? " AND u.user_name like '%$user_name%'" : "";
        $where_clause .= $role_id ? " AND u.role_id = $role_id" : "";
        $users = $objuser->get_users($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', ''), request_var('sortby', 'asc') );
        $itemcount = $objuser->get_users('', 0, 0, '', '', true);
        
        $templates->setvar('users', $users);
        $templates->setvar('roles', $roles);
        $templates->setvar('user_logging', $authenticate->get_user_id()); 
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        
        
    break;
    case 'edit':
        if ($id)
        {
            //get user information
            $user_infor = $objuser->get_user_by_id($id);
            $templates->setvar('user_infor', $user_infor);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                
            }
            else
            {
                $error_validator = true;
            
                if (trim($first_name) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_first_name', $lang['E_FIRST_NAME']);
                }
                if (trim($last_name) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_last_name', $lang['E_LAST_NAME']);
                }
                if (trim($user_name) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_user_name', $lang['E_USER_NAME']);
                }
                else
                {               
                    $user = $objuser->get_user_by_user_name($user_name, "user_name <> '". $user_infor['user_name'] ."'");                
                    if ($user)
                    {
                        $error_validator = false;
                        $templates->setvar('error_user_name', $lang['E_USER_NAME_EXISTS']);
                    }
                }
                if (trim($email) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_email', $lang['E_EMAIL']);
                }
                else
                {
                    if (!is_valid_email($email))
                    {
                        $error_validator = false;
                        $templates->setvar('error_email', $lang['E_EMAIL_INVALID']);
                    }
                    else
                    {
                        $user = $objuser->get_user_by_email($email, "email <> '". $user_infor['email'] ."'");
                        if ($user)
                        {
                            $error_validator = false;
                            $templates->setvar('error_email', $lang['E_EMAIL_EXISTS']);
                        }
                    }
                }
                if (trim($role_id) == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_role', $lang['E_ROLE']);
                }
                
                $save_user = array('first_name' => $first_name,
                                   'middle_name' => $middle_name,
                                   'last_name' => $last_name,
                                   'user_name' => $user_name,
                                   'email' => $email,
                                   'role_id' => $role_id,
                                   'status' => $status);
                
                if($error_validator)
                {
                    $objuser->save('UPDATE', $save_user, "user_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('user_infor', $save_user);
                }
            }
        }
    break;
    case 'add':        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $error_validator = true;
            
            if (trim($first_name) == '')
            {
                $error_validator = false;
                $templates->setvar('error_first_name', $lang['E_FIRST_NAME']);
            }
            if (trim($last_name) == '')
            {
                $error_validator = false;
                $templates->setvar('error_last_name', $lang['E_LAST_NAME']);
            }
            if (trim($user_name) == '')
            {
                $error_validator = false;
                $templates->setvar('error_user_name', $lang['E_USER_NAME']);
            }
            else
            {               
                $user = $objuser->get_user_by_user_name($user_name);                
                if ($user)
                {
                    $error_validator = false;
                    $templates->setvar('error_user_name', $lang['E_USER_NAME_EXISTS']);
                }
            }
            if (trim($email) == '')
            {
                $error_validator = false;
                $templates->setvar('error_email', $lang['E_EMAIL']);
            }
            else
            {
                if (!is_valid_email($email))
                {
                    $error_validator = false;
                    $templates->setvar('error_email', $lang['E_EMAIL_INVALID']);
                }
                else
                {
                    $user = $objuser->get_user_by_email($email);
                    if ($user)
                    {
                        $error_validator = false;
                        $templates->setvar('error_email', $lang['E_EMAIL_EXISTS']);
                    }
                }
            }
            if (trim($password) == '')
            {
                $error_validator = false;
                $templates->setvar('error_password', $lang['E_PASSWORD']);
            }
            elseif (strlen(trim($password)) < 6)
            {
                $error_validator = false;
                $templates->setvar('error_password', $lang['E_PASSWORD_LENGTH']);
            }
            elseif (trim($password) != trim($confirm_password) )
            {
                $error_validator = false;
                $templates->setvar('error_password', $lang['E_CONFIRM_PASSWORD']);
            }
            if (trim($role_id) == '')
            {
                $error_validator = false;
                $templates->setvar('error_role', $lang['E_ROLE']);
            }
            
            $save_user = array('first_name' => $first_name,
                               'middle_name' => $middle_name,
                               'last_name' => $last_name,
                               'user_name' => $user_name,
                               'email' => $email,
                               'role_id' => $role_id,
                               'status' => $status,
                               'password' => md5($password) );
            
            if($error_validator)
            {
                $objuser->save('INSERT', $save_user);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('user_infor', $save_user);
            }
        }
        
        
    break;
    case 'delete':
        if ($id && $id != $authenticate->get_user_id())
        { 
            //delete user
            $objuser->delete($id);
            
            $templates->setvar('delete_success', true);
        }
    break;
    case 'changepassword':
        if ($id)
        {
            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                $error_validator = true;
                
                if ($password == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_password', 'Password field cannot be blank.');
                }
                
                if ($error_validator)
                {
                    //get user information
                    $user_infor = $objuser->get_user_by_id($id);
                    
                    //change password
                    $save_user = array('password' => md5($password) );                    
                    $objuser->save('UPDATE', $save_user, "user_id = $id");
                    
                    //send email with password to user
                    if ($send_email)
                    {
                        $parameters = array('NAME' => $user_infor['first_name'] . ' ' . $user_infor['last_name'],
                                            'PASSWORD' => $password);
                        
                        notified_email(2, $parameters, '', $user_infor['email']);
                    }
                    $templates->setvar('save_success', true);
                }
            }
        }
    break;
}


//get all roles for select
$roles = $objrole->get_roles();
$templates->setvar('roles', $roles);


//show template
$templates->show('usermanagement.tpl');
?>