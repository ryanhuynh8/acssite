<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objcitypermitticket = new dbcitypermittickets();

//requets parameter
$ticket_id = request_var('ticket_id', '');
$technician = request_var('technician', '');

//get ticket information
$ticket_infor = $objcitypermitticket->get_ticket_by_id($ticket_id);
$address = $ticket_infor['client_address'] . ' ' . $ticket_infor['client_city'] . ', ' . $ticket_infor['client_state'] . ' ' . $ticket_infor['client_zip'];
$address_popup = $ticket_infor['client_address'] . '<br />' . $ticket_infor['client_city'] . ', ' . $ticket_infor['client_state'] . ' ' . $ticket_infor['client_zip'];
if ($_SERVER['REQUEST_METHOD'] == "POST")
    $ticket_infor['assign_by'] = $technician;


//get all user for select in popup
$users = $objuser->get_users('', 0, 0, 'name');

$content = '';
$content .= '<div>';
$content .= '<table width="100%" border="0" cellpadding="3" cellspacing="0">';
$content .= '<tr><td><b>Customer Name:</b></td><td>'. $ticket_infor['client_name'] .'</td></tr>';
$content .= '<tr><td><b>Address:</b></td><td>'. $address_popup .'</td></tr>';
$content .= '<tr><td><b>Phone:</b></td><td>'. $ticket_infor['client_phone'] .'</td></tr>';


$content .= '</table>';

$content .= '</div>';


$ticket_infor['address'] = $address;
$ticket_infor['content'] = $content;
$longlatitude = getLatitudeLongitude($address);
$ticket_infor['latitude'] = $longlatitude['latitude'];
$ticket_infor['longitude'] = $longlatitude['longitude'];

$templates->setvar('ticket_infor', $ticket_infor);

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $error_validator = true;
    if (trim($technician) == '')
    {
        $error_validator = false;
        $templates->setvar('error_technician', $lang['E_TECHNICIAN']);
    }
    
    if ($error_validator)
    {
        //update commission
        $ticketInfo = $objtickets->get_ticket_by_id($ticket_id);
        if ($technician != $ticketInfo['assign_by'])
        {
            $ticketInfo['assign_by'] = $technician;
            $objtickets->updateCommission($ticketInfo);
        }
        
        $save_ticket = array('assign_by' => $technician);        
        $objtickets->save('UPDATE', $save_ticket, " ticket_id = $ticket_id");
        
        
        
        $templates->setvar('save_success', true);
    }
}


//show template
$templates->show('mapcitypermit.tpl');
?>