<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objdbtask= new dbtask();
$objdbcomment= new dbcommenttask();
$objdbstatestask= new dbstatustask();
$objuser = new dbuser();

//requets parameter
$page = request_var('page', '1');
$id = request_var('id', '');
$due_date= request_var('due_date', '');
$from_due_date = request_var('from_due_date', '');
$to_due_date = request_var('to_due_date', '');
$create_on = request_var('create_on', '');
$from_create_on = request_var('from_create_on', '');
$to_create_on = request_var('to_create_on', '');
$posted_by = request_var('posted_by','');
$assign_by = request_var('assign_by','');
$status_task_id = request_var('status_task','');
$task_description = request_var('task_description', '');

//if ($_SERVER['REQUEST_METHOD'] == "POST")

switch ($mode)
{
    case "view":       
        //get all status task for select
        $where_clause_status = ' 1 = 1';
        $where_clause_status .= " AND status_task_id != 21";
        $status_task = $objdbstatestask->get_statustask($where_clause_status, 0, 0, 'status_task_id');        
        $templates->setvar('status_task', $status_task);
        
        //get all user for assign
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users); 
       
        //get all task         
        $preWeek =date('Y-m-d',time() - (7 * 24 * 60 * 60)); 
        $where_clause = ' 1 = 1';
        if ($task_description)
            $where_clause .= " AND t.task_description like '%$task_description%'"; 
		if ($status_task_id)                 
        	$where_clause .= $status_task_id  ? " AND t.status_task_id = $status_task_id" : '';
		else        	
			$where_clause .= " AND t.status_task_id !=21";
        $where_clause .= $assign_by  ? " AND t.assign_by = $assign_by" : '';
       // $where_clause .= $preWeek ? " AND (t.complete_date > '$preWeek'" : '';
      //  $where_clause .= $preWeek ? " OR t.complete_date ='0000-00-00') " : '';                      
        $tasks = $objdbtask->get_task($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'task_id'), request_var('sortby', 'desc'));         
        $itemcount = $objdbtask->get_task($where_clause, 0, 0, '', '', true);
        $templates->setvar('tasks', $tasks);            
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", false, false) : "");
    break;
    
    
     case "archived":       
        //get all status task for select
        $where_clause_status = ' 1 = 1';
        $where_clause_status .= " AND status_task_id != 21";
        $status_task = $objdbstatestask->get_statustask($where_clause_status, 0, 0, 'status_task_id');        
        $templates->setvar('status_task', $status_task);
        
        //get all user for assign
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users); 
       
        //get all task
        $preWeek =date('Y-m-d',time() - (7 * 24 * 60 * 60));  
        $where_clause = ' 1 = 1';
        if ($task_description)
            $where_clause .= " AND t.task_description like '%$task_description%'";            
        $where_clause .=" AND t.status_task_id = 21";
        $where_clause .= $assign_by  ? " AND t.assign_by = $assign_by" : '';
       // $where_clause .= $preWeek ? " AND (t.complete_date <= '$preWeek'" : '';
       // $where_clause .= $preWeek ? " AND t.complete_date !='0000-00-00') " : '';     
        $tasks = $objdbtask->get_task($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'task_id'), request_var('sortby', 'desc'));        
        $itemcount = $objdbtask->get_task($where_clause, 0, 0, '', '', true);
        $templates->setvar('tasks', $tasks);            
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", false, false) : "");
    break;
    
    case "details":
        if ($id)
        {
            //get announcement information
            $task_infor = $objdbtask->get_task_by_id($id);            
            
            $status_task = $objdbstatestask->get_status_task_by_id($task_infor['status_task_id']);
            $task_infor['status_task_name'] = $status_task['status_task_name'];
            
            $assign = $objuser->get_user_by_id($task_infor['assign_by']);
            $task_infor['assign_name'] = $assign['first_name'] . ' ' . $assign['last_name'];            
            
            $postedby = $objuser->get_user_by_id($task_infor['posted_by']);
            $task_infor['posted_by_name'] = $postedby['first_name'] . ' ' . $postedby['last_name']; 
                        
            $templates->setvar('task_infor', $task_infor);
            
              //get all comment ////////
            $where_clause = ' 1 = 1';           
            $where_clause .= $id  ? " AND t.task_id = $id" : '';            
            $tasks_comment = $objdbcomment->get_comment($where_clause, 0, 0, "comment_id", "desc");            
            $itemcount = $objdbcomment->get_comment($where_clause, 0, 0, '', '', true);
            $templates->setvar('tasks_comment', $tasks_comment);            
            //paging
            $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");           
                      
        }
    break;
    case "viewcomment": //comment
        if($id)
        {
              //get announcement information
            $task_infor = $objdbtask->get_task_by_id($id);                            
            
            $assign = $objuser->get_user_by_id($task_infor['assign_by']);
            $task_infor['assign_name'] = $assign['first_name'] . ' ' . $assign['last_name'];            
            
            $postedby = $objuser->get_user_by_id($task_infor['posted_by']);
            $task_infor['posted_by_name'] = $postedby['first_name'] . ' ' . $postedby['last_name']; 
                        
            $templates->setvar('task_infor', $task_infor);
                       
            
              //get all comment ////////
            $where_clause = ' 1 = 1';           
            $where_clause .= $id  ? " AND t.task_id = $id" : '';            
            $tasks_comment = $objdbcomment->get_comment($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE,"comment_id","desc");            
            $itemcount = $objdbcomment->get_comment($where_clause, 0, 0, '', '', true);            
            $templates->setvar('tasks_comment', $tasks_comment);            
            //paging
            $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false, true) : "");
            
            //add comment
             if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
               
            }
            else
            {                
                $validator = true;              
                if (trim($task_description) == '')
                {
                    $validator = false;
                    $templates->setvar('error_task_description', $lang['E_TASK_DESCRIPTION']);
                }                
                $posted_by=$user_global['user_id'];            
                $save_comment = array('posted_by' => $posted_by,
                                   'task_id' => $id,
                                   'post_on_date' => date('Y-m-d H:i:s'),                                                                    
                                   'description' => $task_description);                                      
                
                if ($validator)
                {                    
                    $objdbcomment->save('INSERT', $save_comment);                    
                    $templates->setvar('save_success', true);
                    redirect("task.php?mode=viewcomment&id=".$id);
                   
                }
                else
                {                    
                    $templates->setvar('$tasks_comment', $save_comment);  
                }
            }
        }
    break;

    case "delete":
        if ($id)
        {
            //delete announcement
            $objdbtask->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "edit":
        if ($id)
        {
            //get all status task for select
            $status_task = $objdbstatestask->get_statustask('', 0, 0, 'status_task_id');        
            $templates->setvar('status_task', $status_task);
        
            //get all user for assign
            $users = $objuser->get_users('', 0, 0, 'name');
            $templates->setvar('users', $users);
            
            //get task information
            $task_infor = $objdbtask->get_task_by_id($id); 
            $templates->setvar('task_infor', $task_infor);    
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
            
            }
            else
            {
                $validator = true;
                
                if (trim($task_description) == '')
                {
                    $validator = false;
                    $templates->setvar('error_task_description', $lang['E_TASK_DESCRIPTION']);
                }
                
                //  Complete Date
                $status_task = $objdbstatestask->get_status_task_by_id($status_task_id);
                $status_task_name = $status_task['status_task_name'];           
                $complete_date=null;                
                if($status_task_name == 'Complete')
                {
                    $complete_date= date('Y-m-d');    
                }                
                $posted_by=$user_global['user_id'];
                $save_task = array('posted_by' => $posted_by,
                                   'assign_by' => $assign_by,                                   
                                   'status_task_id' => $status_task_id,                                       
                                   'due_date' => convert_to_standard_date($due_date),
                                   'complete_date'=> $complete_date,
                                   'task_description' => $task_description);                                      
                
                if ($validator)
                {
                    $objdbtask->save('UPDATE', $save_task, " task_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('task_infor', $save_task);  
                }
            }
        }
    break;
    
    case "add":       
        
         //get all status task for select
        $status_task = $objdbstatestask->get_statustask('', 0, 0, 'status_task_id');        
        $templates->setvar('status_task', $status_task);        
            
        //get all user for assign
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);  
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
             $templates->setvar('task_infor', array('due_date' => date('Y-m-d')));                                                    
        }
        else
        {
                                 
            $validator = true;
            
            if (trim($task_description) == '')
            {
                $validator = false;
                $templates->setvar('error_task_description', $lang['E_TASK_DESCRIPTION']);
            }
        
            //  Complete Date
            $status_task = $objdbstatestask->get_status_task_by_id($status_task_id);
            $status_task_name = $status_task['status_task_name'];           
            $complete_date=null;            
            if($status_task_name == 'Complete')
            {
                $complete_date= date('Y-m-d');    
            }               
            
            $posted_by=$user_global['user_id'];            
            $save_task = array('posted_by' => $posted_by,
                                'assign_by' => $assign_by,
                                'status_task_id' => $status_task_id,
                                'create_on' => date('Y-m-d'), 
                                'due_date' => convert_to_standard_date($due_date),
                                'complete_date'=>$complete_date,
                                'task_description' => $task_description);     
            
            if ($validator)
            {
                $objdbtask->save('INSERT', $save_task);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('task_infor', $save_task);  
            }
        }
    break;
}


//show template
$templates->show('task.tpl');
?>