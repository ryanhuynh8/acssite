<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $actionsPermission;



//define object class
$objtickets = new dbtickets();
$objuser = new dbuser();
$objsettletickets= new dbsettletickets();


//requets parameter
$page = request_var('page', 1);
$user = request_var('user', '');
$paymentCash = request_var('payment_cash', '');
$paymentCheck = request_var('payment_check', '');
$paymentCreditCard = request_var('payment_credit_card', '');
$paymentNonCollectted = request_var('payment_non_collected', '');
$search = request_var('search', '');

$technician = request_var('technician', '');
$receivedDate = request_var('received_date', '');
$invoiceNumber = request_var('invoice_number', '');

switch ($mode)
{
    case "view":
		if ($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$saveTikets = array('ticket_invoice_id' 	=> $invoiceNumber,
								'received_by_name' 		=> $technician,                                       
								'received_date' 		=> convert_to_standard_date($receivedDate),
								'receipt_printed' 		=> 1);
			
			$objsettletickets->save('INSERT', $saveTikets);
			
			$templates->setvar('saveTikets', $saveTikets);
			$templates->setvar('save_success', true);
		}
		//get all user for select search
		$users = $objuser->get_users('', 0, 0, 'name');
		$templates->setvar('users', $users);
		
		//get all user for select search
		$accountants = $objuser->get_users(' u.role_id in (1, 2, 24, 26)', 0, 0, 'name');
		$templates->setvar('accountants', $accountants);
		
		
		
		$whereClause  = ' ';
		$whereClause .= $user ? " AND t.assign_by = $user" : '';
		
		$payments = array();
		if ($paymentCash) $payments[] = $payments;
		if ($paymentCheck) $payments[] = $paymentCheck;
		if ($paymentCreditCard) $payments[] = $paymentCreditCard;
		if ($paymentNonCollectted) $payments[] = $paymentNonCollectted;
		$whereClause .= $payments ? " AND t.payment_method in ('". implode("','", $payments) ."') " : ($search ? " AND t.payment_method in ('0') " : '');
		
		$tickets = $objsettletickets->getTicketsReceived($whereClause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'created_date'), request_var('sortby', 'desc') );		                
		
		$itemcount = $objsettletickets->getTicketsReceived($whereClause, 0, 0, '', '', true);                      
		$templates->setvar('tickets', $tickets);
		//paging
		$templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
		
		
		
		$filter = array('user' => $user,
						'payment_cash' => $paymentCash,
						'payment_check' => $paymentCheck,
						'payment_credit_card' => $paymentCreditCard,
						'payment_non_collected' => $paymentNonCollectted,
						'search' => $search);
		
		$templates->setvar('filter', $filter);
    break;

}

//show template
$templates->show('settletickets_received.tpl');

?>