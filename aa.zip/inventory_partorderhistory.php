<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objlaborsparts = new dblabors_parts();
$objvendors = new dbvendors();
$objinventoryorder = new dbinventoryorders();

//requets parameter
$page = request_var('page', '1');
$description = request_var('description', '');
$item_number = request_var('item_number', '');
$id = request_var('labor_part_id', '');


switch ($mode)
{
    case "view":
        $_SESSION['selfURL'] = selfURL();

        //get all parts
        $whereClause = ' 1 AND received_date IS NOT NULL';
        if ($description)
            $whereClause .= " AND p.description like '%$description%'";
        if ($item_number)
            $whereClause .= " AND p.item_number like '%$item_number%'";

        $parts = $objinventoryorder->getInventoriesHistory($whereClause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'created_date'), request_var('sortby', 'desc'));
        $itemcount = $objinventoryorder->getInventoriesHistory($whereClause, 0, 0, '', '', true);

        $templates->setvar('parts', $parts);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false, true) : "");
    break;
}



//show template
$templates->show('inventory_partorderhistory.tpl');
?>