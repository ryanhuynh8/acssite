<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objdefineexpense = new dbdefineexpense();
$objexpense = new dbexpense();

//requets parameter



//if ($_SERVER['REQUEST_METHOD'] == "POST")
$page = request_var('page', '1');
$id = request_var('id', '');
$expense = request_var('expense', '');
$type = request_var('type', '');
$date_from = request_var('date_from', '');
$date_to = request_var('date_to', '');
$payment = request_var('payment', '');
$amount = request_var('amount', '');
$date = request_var('date', '');
$notes = request_var('notes', '');


//get all define expense for select
$define_expenses = $objdefineexpense->get_defineexpenses('', 0, 0, 'description');
$templates->setvar('define_expenses', $define_expenses);
        
switch ($mode)
{
    case "view":
        //get all expense
        $date_from = convert_to_standard_date($date_from);
        $date_to = convert_to_standard_date($date_to);
        $where_clause = '1 = 1';
        $where_clause .= $expense ? " AND e.define_expense_id = $expense" : '';
        $where_clause .= $type ? " AND de.type = $type" : '';
        $where_clause .= $payment ? " AND e.payment = '$payment'" : '';
        $where_clause .= $date_from ? " AND e.date >= '$date_from'" : '';
        $where_clause .= $date_to ? " AND e.date <= '$date_to'" : '';
        $expenses = $objexpense->get_expenses($where_clause, 0, 0, request_var('sortfield', ''), request_var('sortby', 'asc') );
        $total_expenses = 0;
        if ($expenses)
        {
            foreach ($expenses as $record)
            {
                $total_expenses += $record['amount'];
            }            
        }
        
        
        $templates->setvar('expenses', $expenses);
        $templates->setvar('total_expenses', $total_expenses);
    break;

    case 'edit':
        if ($id)
        {
            $expense_infor = $objexpense->get_expense_by_id($id);
            $templates->setvar('expense_infor', $expense_infor);
            
            
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $define_expense_infor = $objdefineexpense->get_define_expense_by_id($expense_infor['define_expense_id']);
                $templates->setvar('define_expense_infor', $define_expense_infor);
            }
            else
            {
                $validator_error = true;
                
                if (trim($expense) == '')
                {
                    $validator_error = false;
                    $templates->setvar('error_expense', $lang['E_EXPENSE']);
                }
                if  (trim($amount) != '' && ( !is_numeric($amount) || $amount < 0) )
                {
                    $validator_error = false;
                    $templates->setvar('error_amount', $lang['E_AMOUNT']);
                }
                if (trim($date) != '' && !is_valid_date($date))
                {
                    $validator_error = false;
                    $templates->setvar('error_date', $lang['E_DATE']);
                }
                
                $save_expense = array('define_expense_id' => $expense,
                                      'amount' => $amount,
                                      'date' => convert_to_standard_date($date),
                                      'payment' => $payment,
                                      'notes' => $notes
                                      );
                
                if ($validator_error)
                {
                    $objexpense->save('UPDATE', $save_expense, " expense_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $define_expense_infor = $objdefineexpense->get_define_expense_by_id($save_expense['define_expense_id']);
                    $templates->setvar('define_expense_infor', $define_expense_infor);
                    $templates->setvar('expense_infor', $save_expense);
                }
            }
        }
    break;

    case 'get_define_expense';
        if ($expense)
        {
            $expense_infor = $objdefineexpense->get_define_expense_by_id($expense);
            
            echo strtoupper($expense_infor['type'] == 1 ? $lang['L_BUSSINESS'] : $lang['L_PERSONAL']) . ';' . $expense_infor['fixed_amount'];            
        }
        return;
    break;
}



//show template
$templates->show('reportexpenses.tpl');
?>