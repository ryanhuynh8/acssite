<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global;
$sortfield = request_var('sortfield', '');
$sortby = request_var('sortby', '');

$query_str = get_current_page("sortfield,sortby");
$templates->setvar("sortfield", $sortfield);
$templates->setvar("sortby", $sortby);

$templates->show('realtime_data_show.tpl');
?>