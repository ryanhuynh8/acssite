
<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;
$objlabors_parts = new dblabors_parts();
$id = request_var("id", 0);
$action = request_var('mode', 'view');
$get_labor_part_id = request_var("labor_part_id", "");
$get_item_number = request_var("item_number", "");
$get_description = request_var("description", "");
$get_unit_cost = request_var("unit_cost", "");
$get_unit_price = request_var("unit_price", "");
$get_mark_up = request_var("mark_up", "");
$get_posted_by = request_var("posted_by", "");
$get_posted_date = request_var("posted_date", "");
$get_is_availabled = request_var("is_availabled", "");
$get_type = request_var("type", "");
$get_uom = request_var("uom", "");
$get_quantity_on_hand = request_var("quantity_on_hand", "");
$get_verdor_id = request_var("verdor_id", "");
$get_vendor_part = request_var("vendor_part", "");
switch ($action)
{
	case 'add':
	$error = false;
	if ($_SERVER['REQUEST_METHOD'] == "POST")
	{
if ($get_item_number == "")
{
	$error = true;
	$templates->setvar("item_number_error", $lang["L_ITEM_NUMBER"]);
}
if ($get_unit_cost == "")
{
	$error = true;
	$templates->setvar("unit_cost_error", $lang["L_UNIT_COST"]);
}
if ($get_unit_price == "")
{
	$error = true;
	$templates->setvar("unit_price_error", $lang["L_UNIT_PRICE"]);
}
if ($get_quantity_on_hand == "")
{
	$error = true;
	$templates->setvar("quantity_on_hand_error", $lang["L_QUANTITY_ON_HAND"]);
}else
{
	if (!isnumeric($quantity_on_hand))
	{
		$error = true;
		$templates->setvar("quantity_on_hand_error", $lang["L_QUANTITY_ON_HAND"]);
	}
}
$labors_partsinfo = array(
		"labor_part_id"    =>  $get_labor_part_id,
		"item_number"    =>  $get_item_number,
		"description"    =>  $get_description,
		"unit_cost"    =>  $get_unit_cost,
		"unit_price"    =>  $get_unit_price,
		"mark_up"    =>  $get_mark_up,
		"posted_by"    =>  $get_posted_by,
		"posted_date"    =>  $get_posted_date,
		"is_availabled"    =>  $get_is_availabled,
		"type"    =>  $get_type,
		"uom"    =>  $get_uom,
		"quantity_on_hand"    =>  $get_quantity_on_hand,
		"verdor_id"    =>  $get_verdor_id,
		"vendor_part"    =>  $get_vendor_part,
);
if (!$error)
{
	$objlabors_parts->save_labors_parts("INSERT", $labors_partsinfo, "");
	$templates->setvar("L_CONTINUE", sprintf($lang["L_CONTINUE"], get_page()));
	$templates->setvar("save_successed", true);
}
}
$templates->setvar("labors_parts", $labors_partsinfo);
break;
case 'edit':
if ($id != 0 && isnumeric($id))
{
	$error = false;
if ($_SERVER['REQUEST_METHOD'] == "POST")
{
if ($get_item_number == "")
{
	$error = true;
	$templates->setvar("item_number_error", $lang["L_ITEM_NUMBER"]);
}
if ($get_unit_cost == "")
{
	$error = true;
	$templates->setvar("unit_cost_error", $lang["L_UNIT_COST"]);
}
if ($get_unit_price == "")
{
	$error = true;
	$templates->setvar("unit_price_error", $lang["L_UNIT_PRICE"]);
}
if ($get_quantity_on_hand == "")
{
	$error = true;
	$templates->setvar("quantity_on_hand_error", $lang["L_QUANTITY_ON_HAND"]);
}else
{
	if (!isnumeric($quantity_on_hand))
	{
		$error = true;
		$templates->setvar("quantity_on_hand_error", $lang["L_QUANTITY_ON_HAND"]);
	}
}
$labors_partsinfo = array(
		"labor_part_id"    =>  $get_labor_part_id,
		"item_number"    =>  $get_item_number,
		"description"    =>  $get_description,
		"unit_cost"    =>  $get_unit_cost,
		"unit_price"    =>  $get_unit_price,
		"mark_up"    =>  $get_mark_up,
		"posted_by"    =>  $get_posted_by,
		"posted_date"    =>  $get_posted_date,
		"is_availabled"    =>  $get_is_availabled,
		"type"    =>  $get_type,
		"uom"    =>  $get_uom,
		"quantity_on_hand"    =>  $get_quantity_on_hand,
		"verdor_id"    =>  $get_verdor_id,
		"vendor_part"    =>  $get_vendor_part,
);
if (!$error)
{
	$objlabors_parts->save_labors_parts("UPDATE", $labors_partsinfo, "id = $id");
	$templates->setvar("L_CONTINUE", sprintf($lang["L_CONTINUE"], get_page()));
	$templates->setvar("save_successed", true);
}
}
else
{
	$labors_partsinfo = $objlabors_parts->get_labors_parts("id = $id", $page, ADMIN_MAX_RECORD_PER_PAGE, "", "");
	$labors_partsinfo = $labors_partsinfo[0];
}
}
$templates->setvar("labors_parts", $labors_partsinfo);
break;
case 'delete':
if ($id != 0 && isnumeric($id))
{
	$objlabors_parts->delete_labors_parts($id);
	$templates->setvar("delete_successed", true);
	$templates->setvar("L_CONTINUE", sprintf($lang["L_CONTINUE"], get_page()));
}
break;
default:
$page = request_var("page", 1);
if (!$page || $page < 0 || ! isnumeric($page))
	$page = 1;
$labors_partsinfo = $objlabors_parts->get_labors_parts($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortcondition);
$templates->setvar("mode", "view");
$itemcount = $objlabors_parts->get_labors_parts($where_clause, "1", "1", "", "", true);
$templates->setvar("SHOW_PAGING", paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false));
$templates->setvar("labors_parts", $labors_partsinfo);
break;
}
$templates->setvar("mode", $action);
$templates->show('labors_parts.tpl');
?>