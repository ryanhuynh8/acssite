<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objproposals = new dbproposals();
$objproposalparts = new dbproposalparts();

$objbankcategories = new dbbankcategories();
$objbankstatement = new dbbankstatement();
$objbankaccounts = new dbbankaccounts();

//requets parameter
$file = request_var('file', '');
$account = request_var('account', '');
$import = request_var('import', '');
$reject = request_var('reject', '');
$allow = request_var('allow', '');


switch ($mode)
{
    case 'view':
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $file_path = 'upload/file_bankstatement/';
            $validator_error = true;
            
            $file = file_upload('file', $file_path);
            
            if ($account == '')
            {
                $validator_error = false;
                $templates->setvar('ERROR_ACCOUNT', $lang['E_ACCOUNT']);
            }
            
            if ($file['error'] == 1)
            {
                $validator_error = false;
                $templates->setvar('ERROR_FILE', $lang['E_FILE_SELECT']);
            }
            else
            {
                $names = explode('.', $file['name']);
                $ext = strtolower($names[count($names)-1]);
                if ($ext != 'csv')
                {
                    $validator_error = false;
                    $templates->setvar('ERROR_FILE', $lang['E_FILE_TYPE']);
                }
            }
            if ($validator_error)
            {
                $file = file_upload('file', $file_path, true);
                
                //import data from csv file to database
                $result = $objbankstatement->import_csv($file_path . $file['name'], $account);
                
                $templates->setvar('result', $result);
                
                $statementInfo = array();
                $statementInfo['account'] = $account;
                $templates->setvar('statementInfo', $statementInfo);
            }
            else
            {
                $statementInfo = array();
                $statementInfo['account'] = $account;
                $templates->setvar('statementInfo', $statementInfo);
            }
        }
        else
        {
            unset($_SESSION['file_imported']);
        }
        
        //get bank accounts for select
        $accounts = $objbankaccounts->get_accounts('', 0, 0, 'bank_account_id');
        $templates->setvar('accounts', $accounts);
    break;

    case "import_duplicated" :
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            if ($allow)
            {
                $imported_date = date('Y-m-d H:i:s');
                foreach ($_POST['type'] as $key=>$type)
                {
                    $save_details = array(  'bank_category_id' 	 => $_POST['bank_category_id'][$key],
                                            'bank_account_id'	 => $account,
                                            'type' 				 => $_POST['type'][$key],
                                            'posted_date' 		 => $_POST['posted_date'][$key],
                                            'description' 		 => $_POST['description'][$key],
                                            'amount' 			 => $_POST['amount'][$key],
                                            'imported_date' 	 => $imported_date);
                    
                    $objbankstatement->save('INSERT', $save_details);
                }
            }
        }
    break;
}



//show template
$templates->show('bankstatementimport.tpl');
?>