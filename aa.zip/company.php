<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objcompany = new dbcompany();

//requets parameter
$name = request_var('name', '');
$address = request_var('address', '');
$phone = request_var('phone', '');
$fax = request_var('fax', '');
$logo = request_var('logo', '');
$update = request_var('update', '');
$update_logo = request_var('update_logo', '');
$backup_server = request_var('backup_server', '');
$backup_local = request_var('backup_local', '');
switch ($mode)
{
    case "view":
        
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            if ($update)
            {
                $error_validator = true;
                
                if ($name == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_name', 'Company Name field cannot be blank.');
                }
                if ($address == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_address', 'Company Address field cannot be blank.');
                }
                
                $save_company = array('name' => $name,
                                      'address' => $address,
                                      'phone' => $phone,
                                      'fax' => $fax);
                
                if ($error_validator)
                {                    
                    $objcompany->save($save_company);
                    
                    $templates->setvar('save_success', true);
                    
                    $save_company['backup_server'] = $company['backup_server'];
                    $save_company['backup_local'] = $company['backup_local'];
                    $save_company['logo'] = $company['logo'];
                    $templates->setvar('company', $save_company);
                }
                else
                {
                    $save_company['backup_server'] = $company['backup_server'];
                    $save_company['backup_local'] = $company['backup_local'];
                    $templates->setvar('company', $save_company);
                }
            }
            
            if ($update_logo)
            {
                $error_validator = true;
                
                if (!$_FILES['logo']['name'])
                {
                    $error_validator = false;
                    $templates->setvar('error_logo', 'You are not select image yet.');
                }
                elseif (!check_allow_file_image($_FILES['logo']['type']) )
                {
                    $error_validator = false;
                    $templates->setvar('error_logo', 'Only acceptable formats are: JPEG, BMP, PNG.');
                }
                
                if ($error_validator)
                {
                    //upload file logo
                    if ($_FILES['logo']['name'])
                    {
                        $upload_image = md5($_FILES['logo']['name'].time()) . get_extension($_FILES['logo']['name']);
                        upload_file($_FILES['logo']['tmp_name'], $_FILES['logo']['name'], $upload_image, UPLOAD_PATH . 'company/');
                        $save_company['logo'] = $upload_image;
                    }
                    
                    $objcompany->save($save_company);
                    
                    
                    
                    $templates->setvar('save_success_logo', true);
                }
                else
                {
                    $templates->setvar('company', $company);
                }
            }
            
            if ($backup_server)
            {
                /*
                $objcompany->backup();
                
                $templates->setvar('backup_success', true);
                */
            }
            
            if ($backup_local)
            {
                
            }
        }
        
        //get company information
        $company = $objcompany->get_company();
        $templates->setvar("company", $company);
        if (!file_exists(UPLOAD_PATH . 'company/' . $company['logo']) )
            $company['logo'] = '';
        
    break;

    case 'restore':
        /*
        if ($handle = opendir('backup/')) {        
            //This is the correct way to loop over the directory.
            while (false !== ($file = readdir($handle))) {
                echo "$file\n";
            }
        
            //This is the WRONG way to loop over the directory.
            while ($file = readdir($handle)) {
                echo "$file\n";
            }
        
            closedir($handle);
        }
        */
    break;
}

//show template
$templates->show('company.tpl');
?>