<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objyahoo = new dbyahooapi();

//requets parameter
$id = request_var('id', '');
$user_name = request_var('user_name', '');
$password = request_var('password', '');

$mailUserName = request_var('mail_user_name', '');
$mailPassword = request_var('mail_password', '');
$mailSender = request_var('mail_sender', '');
$emailWarning = request_var('email_warning', '');
$timeRotate = request_var('time_rotate_realtime_map', '');


$user_name = trim($user_name);
$password = trim($password);
$mailUserName = trim($mailUserName);
$mailPassword = trim($mailPassword);
$mailSender = trim($mailSender);
$emailWarning = trim($emailWarning);
$timeRotate = trim($timeRotate);

switch ($mode)
{
    case "view":
		
		
			
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            $yahoo_info = $objyahoo->get_yahoo_api();
			$templates->setvar('yahoo_info', $yahoo_info);
			
			$globalConfig['mail_sender'] = $config->configurations['MAIL_SENDER'];
			$globalConfig['mail_user_name'] = $config->configurations['MAIL_USER_NAME'];
			$globalConfig['mail_password'] = $config->configurations['MAIL_PASSWORD'];
			
			$globalConfig['email_warning'] = $config->configurations['EMAIL_WARNING_QUANTITY'];
            $globalConfig['time_rotate_realtime_map'] = $config->configurations['TIME_ROTATE_REALTIME_MAP'];
			
			$templates->setvar('globalConfig', $globalConfig);
        }
        else
        {
            $validator = true;
                
			if (trim($user_name) == '')
			{
				$validator = false;
				$templates->setvar('error_user_name', $lang['E_USER_NAME']);
			}
			if (trim($password) == '')
			{
				$validator = false;
				$templates->setvar('error_password', $lang['E_PASSWORD']);
			}
			
			$save_yahoo = array('user_name' => $user_name,
								'password' => $password);
			
			if ($validator)
			{
				if ($id)
					$objyahoo->save('UPDATE', $save_yahoo, " yahoo_api_id = $id");
				else
					$objyahoo->save('INSERT', $save_yahoo);
					
				//mail config
				if (array_key_exists('MAIL_SENDER', $config->configurations) )
					$config->save_config('UPDATE', array('value' => $mailSender), " config_key = 'MAIL_SENDER'");
				else
					$config->save_config('INSERT', array('config_key' => 'MAIL_SENDER' ,'value' => $mailSender, 'type' => '1') );
				
				if (array_key_exists('MAIL_USER_NAME', $config->configurations) )
					$config->save_config('UPDATE', array('value' => $mailUserName), " config_key = 'MAIL_USER_NAME'");
				else
					$config->save_config('INSERT', array('config_key' => 'MAIL_USER_NAME' ,'value' => $mailUserName, 'type' => '1') );
					
				if (array_key_exists('MAIL_PASSWORD', $config->configurations) )
					$config->save_config('UPDATE', array('value' => $mailPassword), " config_key = 'MAIL_PASSWORD'");
				else
					$config->save_config('INSERT', array('config_key' => 'MAIL_PASSWORD' ,'value' => $mailPassword, 'type' => '1') );
					
				if (array_key_exists('EMAIL_WARNING_QUANTITY', $config->configurations) )
					$config->save_config('UPDATE', array('value' => $emailWarning), " config_key = 'EMAIL_WARNING_QUANTITY'");
				else
					$config->save_config('INSERT', array('config_key' => 'EMAIL_WARNING_QUANTITY' ,'value' => $emailWarning, 'type' => '1') );

                if (array_key_exists('TIME_ROTATE_REALTIME_MAP', $config->configurations) )
                    $config->save_config('UPDATE', array('value' => $timeRotate), " config_key = 'TIME_ROTATE_REALTIME_MAP'");
                else
                    $config->save_config('INSERT', array('config_key' => 'TIME_ROTATE_REALTIME_MAP' ,'value' => $timeRotate, 'type' => '1') );
				
				$templates->setvar('save_success', true);
			}
			else
			{
				$save_yahoo['yahoo_api_id'] = $id; 
				$templates->setvar('yahoo_info', $save_yahoo);
			}
		}
    break;
}



//show template
$templates->show('configyahooapi.tpl');
?>