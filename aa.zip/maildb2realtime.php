<?php
#error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
session_start();
ob_start();
require_once("includes/config.php");
require_once("includes/constants.php");
require_once("includes/dbl.php");
require_once("dataaccessor/dbrealtime.php");
require_once("dataaccessor/dbbuilders.php");
#require_once("dataaccessor/dbcustomers.php");
require_once("includes/html2text.php");
set_time_limit(0);
$dbrealtime = new dbrealtime();
$dbrealtime->backup_mailInData();
$mailData =$dbrealtime->get_mailInData();

foreach ($mailData as $mailDB)
{
    if($mailDB['Type']==1)
        if($mailDB['Message_xml'])
            $data = ParserXmlToData($mailDB['Message_xml'], $mailDB['Message'], $mailDB['EmailFrom'], $mailDB['DateE']);
        else
            $data = ParserMailContent($mailDB['Message'], $mailDB['EmailFrom'], $mailDB['DateE']);

    elseif($mailDB['Type']==2)
        $data = ParserMissCallEmail($mailDB['Message'], $mailDB['EmailFrom'], $mailDB['DateE']);

    if($mailDB['Type']==3){
        $plain_text =convert_html_to_text($mailDB['Message_html']);

        if($mailDB['Message']!=null){
            $dispatchIDPrefix = 0;
            preg_match('~ID:(\s?)([0-9]+)~is', $mailDB['Subject'], $match);
            if (isset($match[2]) && is_numeric(trim($match[2]))) {
                $dispatchID = trim($match[2]);
                $dispatchIDPrefix = (int)leftStr($dispatchID, 4);
            }
            if(preg_match('~Click here to view in browser~is',strip_tags($mailDB['Message_html']),$match) && ($dispatchIDPrefix==2000 || $dispatchIDPrefix==1000)){
                $data = parserMailContent2014_2($mailDB['Message_html'],$mailDB['EmailFrom']);
            }
            else{
                //$data =ParserMailContentPM($mailDB['Message'],$mailDB['EmailFrom'],$mailDB['DateE']);
                $data = ParserXmlToDataPM($mailDB['Message_html'],$mailDB['Message_xml'],$mailDB['EmailFrom'],$mailDB['DateE']);
            }

        }else{
            $data = ParserXmlToDataPM($mailDB['Message_html'],$mailDB['Message_xml'],$mailDB['EmailFrom'],$mailDB['DateE']);
        }

    }
    $dbrealtime->savemsgfromapi($data,  $mailDB['DateE']);
    $dbrealtime->update_mailStatus($mailDB['ID']);

}
function leftStr($str, $num)
{
    if ($num < strlen($str))
        return substr($str, 0, $num);
    else
        return $str;
}
function parserMailContent2014($content,$customer_email){
    correctContentMail($content);
    $mailContent = $content;
    $Data = array(
        "dispatchID" =>  '' ,
        "customer_name"  =>  '',
        "customer_email"  =>  $customer_email,
        "phone"     =>  '',
        "phone2"    =>  '',
        "address"   =>  '',
        "city"      =>    '',
        "state"      =>  '',
        "zipcode"    =>  '',
        "urgency"   =>  "PM",
        "description" =>  trim($content),
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  '',
        "board_system"  =>  1,
        "note"=>''

    );
    $RealContent = '';
    $content = explode('American Home Shield service request.',$content);
    if(is_array($content) && sizeof($content)>1){
        $content = explode('*Download the HVAC Customer Checklist',$content[1]);
        if(is_array($content) && sizeof($content)>1){
            $RealContent = $content[0];
        }
    }
    if(trim($RealContent)!=''){
        preg_match('~\*Dispatch ID: \*([^*]*)\*Dispatch Date: \*([^*]*)\*Property Address: \*([^*]*)\*Customer:\*([^*]*)\*Effective Date: \*([^*]*)\*Expiration Date: \*([^*]*)\*Dispatch Notes:\*([^*]*)\*~is',$RealContent,$match);
        if(isset($match[1]) && trim($match[1])!='')
            $Data['dispatchID'] = trim($match[1]);
        if(isset($match[2]) && trim($match[2])!='')
            $Data['msg_time'] = trim($match[2]);
        if(isset($match[3]) && trim($match[3])!=''){
            $addArr = explode('<br />',nl2br(trim($match[3])));
            if(is_array($addArr) && isset($addArr[0]) && trim($addArr[0])!='')
                $Data['address'] = trim($addArr[0]);
            if(is_array($addArr) && isset($addArr[1]) && trim($addArr[1])!=''){
                $cityState = explode(',',trim($addArr[1]));
                if(is_array($cityState) && isset($cityState[0]) && trim($cityState[0])!='')
                    $Data['city'] = trim($cityState[0]);
                if(is_array($cityState) && isset($cityState[1]) && trim($cityState[1])!='')
                    $Data['state'] = trim($cityState[1]);
            }
            if(is_array($addArr) && isset($addArr[2]) && trim($addArr[2])!='')
                $Data['zipcode'] = trim($addArr[2]);
        }

        if(isset($match[4]) && trim($match[4])!=''){
            $namePhoneArr = explode('<br />',nl2br(trim($match[4])));
            if(is_array($namePhoneArr) && isset($namePhoneArr[0]) && trim($namePhoneArr[0])!='')
                $Data['customer_name'] = strtoupper(trim($namePhoneArr[0]));
            if(is_array($namePhoneArr) && isset($namePhoneArr[1]) && trim($namePhoneArr[1])!='')
                $Data['phone'] = trim($namePhoneArr[1]);
        }
        /*        if(isset($match[5]) && trim($match[5])!='')
                    $Data['Effective_Date'] = trim($match[5]);
                if(isset($match[6]) && trim($match[6])!='')
                    $Data['Expiration_Date'] = trim($match[6]);*/
        if(isset($match[7]) && trim(str_replace('Coverage','',$match[7]))!='')
            $Data['note'] = trim(str_replace('Coverage','',$match[7]));

        if($Data['description']!=''){
            $dsc = explode('American Home Shield service request.',nl2br($Data['description']));
            if(isset($dsc[1]) && trim($dsc[1])!=''){
                $dsc = explode('Coverage     *',$dsc[1]);
                if(isset($dsc[0]) && trim($dsc[0])!=''){
                    $Data['description'] = trim($dsc[0]);
                    $Data['description'] = str_replace('*<br />',"",$Data['description']);
                    $Data['description'] = preg_replace('#<br />(\s*<br />)+#', '[br]',$Data['description']);
                    $Data['description'] = str_replace(array('<br />','*'),"",$Data['description']);
                    $Data['description'] = str_replace('[br]',"<br />",$Data['description']);
                }
            }
        }

        if(preg_match('~\*Vendor: \*([^*]*)\*~is',$RealContent,$match)){
            if(isset($match[1]) && trim($match[1])!=''){
                $builderdb = new dbbuilders();
                $builder = trim($match[1]);
                if(preg_match('~AHS~',$mailContent,$match))
                    $builder = 'Preventative Maintenance (AHS)';
                $builderid = $builderdb->check_existed_builder($builder);
                if ($builderid == 0 && $builder != "")
                {
                    $buildernew = array(
                        "full_name" =>  $builder,
                        "address"   =>  $Data['address'],
                        "city"   =>  $Data['city'],
                        "state"   =>  $Data['state'],
                        "zip"   =>  $Data['zip'],
                        "phone1"    =>  $Data['phone']
                    );
                    $builderid = $builderdb->save("INSERT", $buildernew, "");
                }
                if (!$builderid || $builderid == 0)
                    $builderid = 20;
                $Data['builder_id'] = $builderid;
            }
        }
    }
    return $Data;
}
function correctContentMail($htmlContent){
    $mailContent = $htmlContent;
    if(preg_match('~</title>(\s*?)<div>(.*)</table>(\s*?)<img~is',$htmlContent,$match)){

        if(isset($match[2]) && trim($match[2])!=''){
            $contentTmp = trim($match[2]);
            preg_match('~<td bgcolor="#FFFFFF" width="700" align="center">(.*)</tbody></table></td>(\s*?)<td width="10">~is',$contentTmp,$match);
            $contentTmp = $match[1].'</tbody></table>';
            $contentTmp = preg_replace('~<sup>([^<]*)</sup>~','<sup>&reg;</sup>',$contentTmp);
            $mailContent = $contentTmp;
        }
    }
    elseif(preg_match('~<div id=([^>]*)><div>(.*)</table>(\s*?)<img~is',$htmlContent,$match)){

        if(isset($match[2]) && trim($match[2])!=''){
            $contentTmp = trim($match[2]);
            preg_match('~<td align="center" bgcolor="#FFFFFF" width="700">(.*)</tbody></table></td>(\s*?)<td width="10">~is',$contentTmp,$match);
            $contentTmp = $match[1].'</tbody></table>';
            $contentTmp = preg_replace('~<sup>([^<]*)</sup>~','<sup>&reg;</sup>',$contentTmp);
            $mailContent = $contentTmp;
        }
    }elseif(preg_match('~<body>(\s*?)<table(.*)</table>(\s*?)<img~is',$htmlContent,$match)){
        if(isset($match[2]) && trim($match[2])!=''){
            $contentTmp = trim('<table '.$match[2]);
            preg_match('~<td bgcolor="#FFFFFF" width="700" align="center">(.*)</table></td>(\s*?)<td width="10">~is',$contentTmp,$match);
            $contentTmp = $match[1].'</table>';
            $contentTmp = preg_replace('~<sup>([^<]*)</sup>~','<sup>&reg;</sup>',$contentTmp);
            $mailContent = $contentTmp;
        }
    }
    return $mailContent;
}
function parserMailContent2014_2($content,$customer_email){
    global $dispatchIDPrefix;

    $mailContent = correctContentMail($content);

    $Data = array(
        "dispatchID" =>  '' ,
        "customer_name"  =>  '',
        "customer_email"  =>  $customer_email,
        "phone"     =>  '',
        "phone2"    =>  '',
        "address"   =>  '',
        "city"      =>    '',
        "state"      =>  '',
        "zipcode"    =>  '',
        "urgency"   =>  'PM',
        "description" =>  $mailContent,
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  time(),
        "board_system"  =>  1,
        "note"=>''

    );
    //echo $mailContent; die;
    if(preg_match_all('~<td align="left" valign="top"><font([^>]*)>(.*?)</font>~is',$mailContent,$match)){
        if(is_array($match[2]) && sizeof($match[2])>0){
            $i=0;
            foreach($match[2] as $str){

                if($dispatchIDPrefix==2000){
                    $i++;
                    if($i==1)
                        $str = $str.'<br>';
                    $str = preg_replace('#<br>(\s*<br>)+#', '|',$str);
                    if(preg_match_all('~<b>([^<]*)</b><br>([^\|]*)\|~is',$str,$match2)){
                        if(3==sizeof($match2) && is_array($match2[1]) && is_array($match2[2])){

                            foreach($match2[1] as $key => $name){

                                if(trim($name)=='Vendor:')
                                    $Data['Vendor'] = trim($match2[2][$key]);

                                if(trim($name)=='Dispatch ID:')
                                    $Data['dispatchID'] = trim($match2[2][$key]);

                                if(trim($name)=='Dispatch Date:')
                                    $Data['Dispatch_Date'] = trim($match2[2][$key]);

                                if(trim($name)=='Property Address:'){
                                    $addArr = explode('<br>',trim($match2[2][$key]));
                                    if(is_array($addArr) && isset($addArr[0]) && trim($addArr[0])!='')
                                        $Data['address'] = trim($addArr[0]);
                                    if(is_array($addArr) && isset($addArr[1]) && trim($addArr[1])!=''){
                                        $cityState = explode(',',trim($addArr[1]));
                                        if(is_array($cityState) && isset($cityState[0]) && trim($cityState[0])!='')
                                            $Data['city'] = trim($cityState[0]);
                                        if(is_array($cityState) && isset($cityState[1]) && trim($cityState[1])!='')
                                            $Data['state'] = trim($cityState[1]);
                                    }
                                    if(is_array($addArr) && isset($addArr[2]) && trim($addArr[2])!='')
                                        $Data['zipcode'] = trim($addArr[2]);
                                }

                                if(trim($name)=='Customer:'){
                                    $namePhoneArr = explode('<br>',trim($match2[2][$key]));
                                    if(is_array($namePhoneArr) && isset($namePhoneArr[0]) && trim($namePhoneArr[0])!='')
                                        $Data['customer_name'] = strtoupper(trim($namePhoneArr[0]));
                                    if(is_array($namePhoneArr) && isset($namePhoneArr[1]) && trim($namePhoneArr[1])!='')
                                        $Data['phone'] = trim($namePhoneArr[1]);
                                }

                                if(trim($name)=='Effective Date:')
                                    $Data['Effective_Date'] = trim($match2[2][$key]);

                                if(trim($name)=='Expiration Date:')
                                    $Data['Expiration_Date'] = trim($match2[2][$key]);

                                if(trim($name)=='Dispatch Notes:')
                                    $Data['note'] = trim($match2[2][$key]);
                            }
                        }
                    }
                }else{
                    $str = trim($str);
                    $str = explode('<b>',$str);
                    if(is_array($str) && count($str)>1){
                        for($i=1;$i<count($str);$i++){
                            $str2 = explode('</b>',$str[$i]);
                            if(is_array($str2) && sizeof($str2)==2){
                                $name = $str2[0];
                                $str2[1] = str_replace(array('<br>','<br/>','<br />'),"\n",$str2[1]);
                                $str2[1] = preg_replace("/\s{2,}/","\n",trim($str2[1]));
                                $str2[1] = preg_replace("/\n{2,}/","\n",trim($str2[1]));
                                if(trim($name)=='Vendor:')
                                    $Data['Vendor'] = cleanValue($str2[1]);

                                if(trim($name)=='Dispatch ID:')
                                    $Data['dispatchID'] = cleanValue($str2[1]);

                                if(trim($name)=='Dispatch Date:')
                                    $Data['Dispatch_Date'] = cleanValue($str2[1]);
                                if(trim($name)=='Property Address:'){
                                    $addArr = explode("\n",trim($str2[1]));
                                    if(is_array($addArr) && isset($addArr[0]) && trim($addArr[0])!='')
                                        $Data['address'] = cleanValue($addArr[0]);
                                    if(is_array($addArr) && isset($addArr[1]) && trim($addArr[1])!=''){
                                        $cityState = explode(',',trim($addArr[1]));
                                        if(is_array($cityState) && isset($cityState[0]) && trim($cityState[0])!='')
                                            $Data['city'] = cleanValue($cityState[0]);
                                        if(is_array($cityState) && isset($cityState[1]) && trim($cityState[1])!='')
                                            $Data['state'] = cleanValue($cityState[1]);
                                    }
                                    if(is_array($addArr) && isset($addArr[2]) && trim($addArr[2])!='')
                                        $Data['zipcode'] = cleanValue($addArr[2]);
                                }
                                if(trim($name)=='Customer:'){
                                    $namePhoneArr = explode("\n",trim($str2[1]));
                                    if(is_array($namePhoneArr) && isset($namePhoneArr[0]) && trim($namePhoneArr[0])!='')
                                        $Data['customer_name'] = strtoupper(cleanValue($namePhoneArr[0]));
                                    if(is_array($namePhoneArr) && isset($namePhoneArr[1]) && trim($namePhoneArr[1])!='')
                                        $Data['phone'] = cleanValue($namePhoneArr[1]);
                                    if(is_array($namePhoneArr) && isset($namePhoneArr[2]) && trim($namePhoneArr[2])!='')
                                        $Data['phone2'] = cleanValue($namePhoneArr[2]);
                                }

                                if(trim($name)=='Effective Date:')
                                    $Data['Effective_Date'] = cleanValue($str2[1]);

                                if(trim($name)=='Expiration Date:')
                                    $Data['Expiration_Date'] = cleanValue($str2[1]);

                                if(trim($name)=='Dispatch Notes:')
                                    $Data['note'] = cleanValue($str2[1]);
                            }
                        }
                    }
                }
            }
        }
        $Data['description'] = strip_tags($Data['description'],'<a><br>');
        $Data['description'] = str_replace('&nbsp;',' ',$Data['description']);
        $Data['description'] = str_replace(array('<br />','<br/>'),'<br>',$Data['description']);
        //$Data['description'] = preg_replace("/(\s){2,}/"," ",trim($Data['description']));
        $Data['description'] = preg_replace("/(<br\ ?\/?>)+/","<br />",trim($Data['description']));
        $Data['description'] = preg_replace("/\s{2,}/"," ",trim($Data['description']));
        $Data['description'] = str_replace('Acs Absolute Comfort Llc:','<br/>Acs Absolute Comfort Llc:',$Data['description']);
        $Data['description'] = str_replace('American Home Shield service request.','American Home Shield service request.<br/>',$Data['description']);
        $Data['description'] = str_replace('Dispatch Preventative Maintenance','Dispatch <br/>Preventative Maintenance',$Data['description']);
        $Data['description'] = str_replace('Coverage <a','Coverage<br/><a',$Data['description']);
        $Data['description'] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $Data['description']);
        ################### builder ###################
        /*$builderdb = new dbbuilders();
        $builder = trim($Data['Vendor']);
        $builderid = $builderdb->check_existed_builder($builder);
        if ($builderid == 0 && $builder != "")
        {
            $buildernew = array(
                "full_name" =>  $builder,
                "address"   =>  $Data['address'],
                "city"   =>  $Data['city'],
                "state"   =>  $Data['state'],
                "zip"   =>  $Data['zip'],
                "phone1"    =>  $Data['phone']
            );
            $builderid = $builderdb->save("INSERT", $buildernew, "");
        }
        if (!$builderid || $builderid == 0)
            $builderid = 20*/;
        $Data['builder_id'] = 31;
    }
    return $Data;
}
function ParserXmlToData($xml, $content, $email, $mgsdate)
{
    $builderdb = new dbbuilders();
    $mailContent = CleanUpEmailContent($content);

    $domObj = new SimpleXMLElement($xml);
    $domArr = $domObj;

    $dispatchID= $domArr->DispatchList['Id'];
    $customerName = $domArr->ContractCustomerList->ContractCustomer['Name'];
    if (count($domArr->ContractCustomerList->ContractCustomer->PhoneNumber) > 1)
    {
        $phone1 = $domArr->ContractCustomerList->ContractCustomer->PhoneNumber[0]['Number'] ;
        $phone2 = $domArr->ContractCustomerList->ContractCustomer->PhoneNumber[1]['Number'] ;
    }else
        $phone1 = $domArr->ContractCustomerList->ContractCustomer->PhoneNumber['Number'] ;
    $address = $domArr->Contract->CoveredProperty['StreetNumber'] ;
    $address .= " " .$domArr->Contract->CoveredProperty['StreetName'] ;
    $city = $domArr->Contract->CoveredProperty['CityName'];
    $state = $domArr->Contract->CoveredProperty['StateCode'];
    $zipcode = $domArr->Contract->CoveredProperty['ZipPostCode'];
    $urgency = $domArr->DispatchList['dispatchPriorityValueList'];
    $note = "";
    $note1 = "";
    if (is_array($domArr->DispatchList->WorkOrderLineList))
    {
        $countWorkOrderLineList = count($domArr->DispatchList->WorkOrderLineList);
        for($work = 0; $work < $countWorkOrderLineList; $work++ )
        {
            $note .= $domArr->DispatchList->WorkOrderLineList[$work]['Description'];
            echo $note;
            if (!is_array($domArr->DispatchList->WorkOrderLineList->Symptom))
            {
                echo count($domArr->DispatchList->WorkOrderLineList[$work]['Symptom']);
                for($i = 0; $i < count($domArr->DispatchList->WorkOrderLineList[$work]['Symptom']); $i++ )
                {
                    $note1 .= $domArr->DispatchList->WorkOrderLineList[$work]->Symptom[$i]['Name'] . "\n";

                }

            }
            else
            {
                $note1 .= $domArr->DispatchList->WorkOrderLineList->Symptom['Name'];
            }
            $note  .= ": " . $note1 . "\n";
        }
    }else
    {
        $note = $domArr->DispatchList->WorkOrderLineList['Description'];
        if (!is_array($domArr->DispatchList->WorkOrderLineList->Symptom))
        {

            for($i = 0; $i < count($domArr->DispatchList->WorkOrderLineList->Symptom); $i++ )
            {
                $note1 .= $domArr->DispatchList->WorkOrderLineList->Symptom[$i]['Name'] . "\n";
            }
        }
        else
            $note1 .= $domArr->DispatchList->WorkOrderLineList->Symptom['Name'];

        $note  .= ":" . $note1 . "\n";
    }
    $builder = $domArr->Vendor['Name'];
    $builderid = $builderdb->check_existed_builder($builder);
    if ($builderid == 0 && $domArr->Vendor['Name'] != "")
    {
        $buildernew = array(
            "full_name" =>  $builder,
            "address"   =>  $domArr->Vendor->CommercialProperty['StreetNumber'] . " " . $domArr->Vendor->CommercialProperty['StreetName'],
            "city"   =>  $domArr->Vendor->CommercialProperty['CityName'],
            "state"   =>  $domArr->Vendor->CommercialProperty['StateCode'],
            "zip"   =>  $domArr->Vendor->CommercialProperty['ZipPostCode'],
            "phone1"    =>  $domArr->Vendor->PhoneNumber[0]['Number'],
            "fax"   =>  $domArr->Vendor->PhoneNumber[1]['Number'],
            "office_number" =>  $domArr->Vendor['Id']
        );
        $builderid = $builderdb->save("INSERT", $buildernew, "");
    }
    if (!$builderid || $builderid == 0)
        $builderid = 20;
    $customerName=strtoupper($customerName);
    $data = array(
        "dispatchID" =>  $dispatchID ,
        "customer_name"  =>  $customerName,
        "customer_email"  =>  trim(str_replace(":", "", $email)),
        "phone"     =>  $phone1,
        "phone2"     =>  $phone2,
        "address"   =>  $address,
        "state" =>  $state,
        "city"  =>  $city,
        "zipcode"   =>  $zipcode,
        "urgency"   =>  $urgency,
        "description" =>  trim($mailContent),
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  $mgsdate,
        "board_system"  =>  1,
        "note"  =>  $note


    );
    return $data;
}

function CleanUpEmailContent($content)
{
    $mailContent = preg_replace("/(\<script)(.*?)(script>)/si", "", $content);
    $mailContent = str_replace("\r\n", "\n", $mailContent);
    $mailContent = str_replace("\r", "\n", $mailContent);
    $mailContent = str_replace("<br>", "\r\n", $mailContent);
    $mailContent = str_replace("<br />", "\n", $mailContent);
    $mailContent = str_replace("<BR>", "\n", $mailContent);
    $mailContent = str_replace("&nbsp;", " ", $mailContent);
    $mailContent = str_replace("\t", "", $mailContent);
    $mailContent = preg_replace('/[\x80-\xFF]/', ' ', $mailContent);
    $mailContent = iconv("UTF-8","ISO-8859-1//IGNORE",$mailContent);
    $mailContent = str_replace("</tr>", "\n", $mailContent);
    $mailContent = strip_tags($mailContent);
    return $mailContent;
}

function ParserMissCallEmail($content, $email, $mgsdate)
{
    $data = array();
    $mailContent = CleanUpEmailContent($content);

    $temp = substr($mailContent, strpos($mailContent, "From") + 4, strpos($mailContent, "To") - strpos($mailContent, "From") - 4);
    $customer = substr($temp, 0, strpos($temp, "(") - 1 );
    $phone  = substr($temp, strpos($temp, "(") + 1 , strpos($temp, ")") - strpos($temp, "(") - 1);
    $customer=strtoupper($customer);
    $data = array(
        "customer_name"  =>  trim(str_replace(":", "", $customer)),
        "customer_email"  =>  trim(str_replace(":", "", $email)),
        "phone"     =>  trim(str_replace(":", "", $phone)),
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  $mgsdate,
        "board_system"  =>  2,
        "description" =>  trim(substr($mailContent, 0, strpos($mailContent, '---')))
    );
    return $data;
}

function ParserXmlToDataPM($html,$xml, $email, $mgsdate)
{
    $data = array();
    $domObj = new SimpleXMLElement($xml);
    $domArr = $domObj;

    $dispatchID = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->ActivityId;
    // var_dump($domObj->ListOfAhsEaiIoActivityCheetahMail->Action->ListOfContact->Contact->ContactLastName);
    // var_dump($domObj->ListOfAhsEaiIoActivityCheetahMail);
    // var_dump($dispatchID);
    // die();
    $customer = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->ListOfContact->Contact->ContactFirstName.' '.$domArr->ListOfAhsEaiIoActivityCheetahMail->Action->ListOfContact->Contact->ContactLastName;

    $phone  = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->ListOfContact->Contact->ContactHomePhoneNumber;
    $phone2 = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->AHSPrimaryOrganizationMainPhone;
    //$urgency =$domArr->Priority;
    $address = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->AHSPropertyAddressLine1;

    $city = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->AHSPropertyCity;

    $state = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->AHSPropertyState;
    $zipcode = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->AHSPropertyZipCode;
    $claimID = $domArr->ListOfAhsEaiIoActivityCheetahMail->Action->PrimaryClaimId;
    $claimID ="Claim ID: ".$claimID;
    $plain_text =convert_html_to_text($html);
    $plain_text = mb_convert_encoding($plain_text, "EUC-JP", "auto");
    $plain_text=str_replace('?','',$plain_text);
    $plain_text=preg_replace('/(\r\n|\n|\r){3,}/', "$1$1", $plain_text);
    $customer=strtoupper($customer);
    $data = array(
        "dispatchID" => $dispatchID ,
        "customer_name"  =>   $customer,
        "customer_email"  =>  trim(str_replace(":", "", $email)),
        "phone"     =>  $phone,
        // "phone2"    =>  $phone2,
        "address"   =>   $address,
        "city"      =>    $city,
        "state"      =>  $state,
        "zipcode"    =>  $zipcode,
        "urgency"   =>  "PM",
        "description" =>  trim($plain_text),
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  $mgsdate,
        "board_system"  =>  1,
        "note"=>$claimID,

    );
    // echo "123";

    return $data;
}

function ParserMailContent($content, $email, $mgsdate)
{
    $data = array();
    $mailContent = CleanUpEmailContent($content);
    $dispatchID = substr($mailContent, strpos($mailContent, "Dispatch ID") + 12, strpos($mailContent, "Dispatch Date:") - strpos($mailContent, "Dispatch ID") - 12);
    $customer = substr($mailContent, strpos($mailContent, "Customer:") + 10, strpos($mailContent, "Buyer") - strpos($mailContent, "Customer:") - 10);
    $phone  = substr($mailContent, strpos($mailContent, "Buyer") + 6, strpos($mailContent, "Property Address:") - strpos($mailContent, "Buyer") - 16);
    $urgency = substr($mailContent, strpos($mailContent, "Urgency") + 8, strpos($mailContent, "Service Fee Paid") - strpos($mailContent, "Urgency") - 8);
    $addressorg = substr($mailContent, strpos($mailContent, "Property Address") + 17, strpos($mailContent, "Dispatch Contact(s)") - strpos($mailContent, "Property Address") - 17);
    $address = substr($addressorg, 0, strpos($addressorg, "\n"));

    $city = substr($addressorg, strpos($addressorg, "\n"),  strpos($addressorg, ",") - strpos($addressorg, "\n"));
    $stateandzip = substr($addressorg, strpos($addressorg, ","));
    $state = substr($stateandzip, 1, 3);
    $zipcode = substr($stateandzip,6);
    if (strpos($phone, " - Primary Phone") !== false)
    {
        $phone1 = substr($phone, 0, strpos($phone, " - Primary Phone"));
        $phone2 = substr($phone, strpos($phone, " - Primary Phone") + 17);
    }
    else
    {
        $phone1 = str_replace("- Home", "", $phone);
    }

    $customer=strtoupper($customer);
    $data = array(
        "dispatchID" =>  trim(str_replace(":", "", $dispatchID)) ,
        "customer_name"  =>  trim(str_replace(":", "", $customer)),
        "customer_email"  =>  trim(str_replace(":", "", $email)),
        "phone"     =>  trim($phone1),
        "phone2"    =>  trim($phone2),
        "address"   =>  trim(str_replace(":", "", $address)),
        "city"      =>    trim($city),
        "state"      =>  trim($state),
        "zipcode"    =>  substr($zipcode, 0, 5),
        "urgency"   =>  trim(str_replace(":", "", $urgency)),
        "description" =>  trim($mailContent),
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  $mgsdate,
        "board_system"  =>  1

    );
    // echo "123";

    return $data;
}

function ParserMailContentPM($content, $email, $mgsdate)
{
    $data = array();
    $mailContent = CleanUpEmailContent($content);
    $dispatchID = substr($mailContent, strpos($mailContent, "Dispatch ID") + 12, strpos($mailContent, "Claim  ID") - strpos($mailContent, "Dispatch ID") - 12);
    $customer = substr($mailContent, strpos($mailContent, "Customer:") + 10, strpos($mailContent, "Main Phone ") - strpos($mailContent, "Customer:") - 10);
    $phone  = substr($mailContent, strpos($mailContent, "Main Phone #: ") + 14, strpos($mailContent, "Property Address:") - strpos($mailContent, "Main Phone #:") - 14);
    $urgency = substr($mailContent, strpos($mailContent, "Urgency") + 8, strpos($mailContent, "Dispatch Date:") - strpos($mailContent, "Urgency") - 8);
    $addressorg = substr($mailContent, strpos($mailContent, "Property Address") + 16, strpos($mailContent, "Effective Date") - strpos($mailContent, "Property Address") - 16);

    $address2 = trim(str_replace(":", "", $addressorg));
    $address = substr($address2, 0, strpos($address2, "\n"));

    $claimIDa =  substr($mailContent, strpos($mailContent, "Claim  ID") + 12, strpos($mailContent, "Status") - strpos($mailContent, "Claim  ID") - 12);
    $claimID = "Claim ID: ".$claimIDa;

    $city = substr($address2, strpos($address2, "\n"),  strpos($address2, ",") - strpos($address2, "\n"));

    $stateandzip = substr($address2, strpos($address2, ","));
    $state = substr($stateandzip, 1, 3);

    $zipcode = substr($stateandzip,4);

    if (strpos($phone, " - Primary Phone") !== false)
    {
        $phone1 = substr($phone, 0, strpos($phone, " - Primary Phone"));
        $phone2 = substr($phone, strpos($phone, " - Primary Phone") + 17);
    }
    else
    {
        $phone1 = str_replace("- Home", "", $phone);
    }
    $customer=strtoupper($customer);

    $mailContent = preg_replace("/(\n){3,}/","\r\n\r\n",trim($mailContent));
    //$mailContent = preg_replace("/[ ]{3,}/", " ", $mailContent);
    //$mailContent = preg_replace("/[\n\n\n]+/", "\n\n", $mailContent);
    //$mailContent =preg_replace("/\s+/", " ", $mailContent);
    $vowels = array("(",")","-"," ");
    $phone1=str_replace($vowels,"", $phone1);
    $phone2=(isset($phone2)&&$phone2!='')?str_replace($vowels,"", $phone2):'';
    $data = array(
        "dispatchID" =>  trim(str_replace(":", "", $dispatchID)) ,
        "customer_name"  =>  trim(str_replace(":", "", $customer)),
        "customer_email"  =>  trim(str_replace(":", "", $email)),
        "phone"     =>  trim($phone1),
        "phone2"    =>  trim($phone2),
        "address"   =>  $address,
        "city"      =>    trim($city),
        "state"      =>  trim($state),
        "zipcode"    =>  substr($zipcode, 0, 6),
        // "urgency"   =>  trim(str_replace(":", "", $urgency)),
        "urgency"   =>  "PM",
        "description" =>  trim($mailContent),
        "status"    =>   1,
        "time_received"  =>   date("Y-m-d h:i:s"),
        "msg_time"    =>  $mgsdate,
        "board_system"  =>  1,
        "note"=>$claimID

    );

    return $data;
}
function cleanValue($str){
    return trim(strip_tags($str));
}
?>