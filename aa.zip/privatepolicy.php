<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class


//requets parameter


if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    
}


//show template
$templates->show('privatepolicy.tpl');
?>