<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objlaborsparts = new dblabors_parts();
$objvendors = new dbvendors();
$objinventory = new dbinventory();
$objinventoryorder = new dbinventoryorders();

//requets parameter
$page = request_var('page', '1');
$description = request_var('description', '');
$item_number = request_var('item_number', '');
$id = request_var('labor_part_id', '');
$orderId = request_var('order_id', '');
$quantity = request_var('quantity', '');
$partId = request_var('part_id', '');
$placedOrder = request_var('placed_order', '');
$orderDate = request_var('order_date', '');
$orderPo = request_var('order_po', '');
$notes = request_var('notes', '');
$receivedDate = request_var('received_date', '');
$receivedCount = request_var('received_count', '');
$receivedBy = request_var('received_by', '');

switch ($mode)
{
    case "view":
        $_SESSION['selfURL'] = selfURL();

        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            if ($id)
            {
                $error = false;
                if ($quantity == '')
                {
                    $error = true;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY']);
                }
                elseif (!ctype_digit($quantity))
                {
                    $error = true;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY_NUMERIC']);
                }

                if (!$error)
                {
                    $partInfo = $objlaborsparts->get_labor_part_by_id($id);
                    $savePart = array(
                        'quantity_on_hand' => $partInfo['quantity_on_hand'] + $quantity,
                        'updated_date' => date('Y-m-d H:i:s')
                    );
                    $objlaborsparts->save('UPDATE', $savePart, "labor_part_id=$id");
                }
            }

        }

        //get current summer
        $spring = strtotime(date('Y') . '-03-20');
        $summer = strtotime(date('Y') . '-07-20');
        $fall = strtotime(date('Y') . '-09-22');
        $winter = strtotime(date('Y') . '-12-21');

        $currentSeason = 'winter';
        if (time() >= $spring && time() < $summer)
            $currentSeason = 'spring';
        elseif (time() >= $summer && time() < $fall)
            $currentSeason = 'summer';
        elseif (time() >= $fall && time() < $winter)
            $currentSeason = 'fall';

        //get all labors
        $whereClause = ' 1 AND p.type = 2';
        if ($description)
            $whereClause .= " AND p.description like '%$description%'";
        if ($item_number)
            $whereClause .= " AND p.item_number like '%$item_number%'";

        $parts = $objinventoryorder->getInventories($whereClause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'description'), request_var('sortby', 'asc'));
        $itemcount = $objinventoryorder->getInventories($whereClause, 0, 0, '', '', true);

        $templates->setvar('parts', $parts);
        $templates->setvar('currentSeason', $currentSeason);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false, true) : "");
    break;

    case "receive":
        if ($orderId)
        {
            //get part info
            $partInfo = $objinventoryorder->getOrderById($orderId);

            if ($_SERVER['REQUEST_METHOD'] == 'POST')
            {
                $validator = true;
                if (trim($receivedDate) == '')
                {
                    $validator = false;
                    $templates->setvar('error_received_date', $lang['E_RECEIVED_DATE']);
                }
                elseif(!is_valid_date($receivedDate))
                {
                    $validator = false;
                    $templates->setvar('error_received_date', $lang['E_RECEIVED_DATE_DATE']);
                }
                elseif (strtotime($partInfo['ordered_date']) > strtotime(convert_to_standard_date($receivedDate)) )
                {
                    $validator = false;
                    $templates->setvar('error_received_date', sprintf($lang['E_RECEIVED_DATE_GREATER'], date('m/d/Y', strtotime($partInfo['ordered_date'])) ) );
                }
                if (trim($receivedCount) == '')
                {
                    $validator = false;
                    $templates->setvar('error_received_count', $lang['E_RECEIVED_COUNT']);
                }
                elseif (!ctype_digit($receivedCount) )
                {
                    $validator = false;
                    $templates->setvar('error_received_count', $lang['E_RECEIVED_COUNT_NUMERIC']);
                }
                if (trim($receivedBy) == '')
                {
                    $validator = false;
                    $templates->setvar('error_received_by', $lang['E_RECEIVED_BY']);
                }

                $saveOrder = array(
                    'received_date'     => convert_to_standard_date($receivedDate),
                    'received_count'    => $receivedCount,
                    'received_by'       => $receivedBy,
                    'received_note'     => $notes,
                    'received'          => 1
                );

                if ($validator)
                {
                    $objinventoryorder->save('UPDATE', $saveOrder, "inventory_order_id = $orderId");

                    //update inventory in warehouse
                    $objinventory->update_quantity_warehourse($saveOrder['received_count'], $partInfo['labor_part_id']);

                    $templates->setvar('save_success', true);
                }
                else
                {
                    if ($saveOrder)
                    {
                        $partInfo = array_merge($partInfo, $saveOrder);
                    }
                }
            }

            $templates->setvar('partInfo', $partInfo);
        }
    break;

    case "submit_order":
        if ($partId)
        {
            $validator = true;

            if ($validator)
            {
                $orderDate = convert_to_standard_date($orderDate);
                $saveOrder = array(
                    'labor_part_id'     => $partId,
                    'created_date'      => date('Y-m-d H:i:s'),
                    'creator'           => $user_global['user_id'],
                    'placed_order'      => $placedOrder,
                    'ordered_date'      => $orderDate,
                    'po'                => $orderPo,
                    'order_note'        => $notes
                );

                $objinventoryorder->save('INSERT', $saveOrder);
                echo $objinventoryorder->sql;
            }
        }

        exit();
    break;
}



//show template
$templates->show('inventory_partorder.tpl');
?>