<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global;
$completenum = request_var('complete', '');
$sortfield = request_var('sortfield', '');
$sortby = request_var('sortby', '');
   //define object class
   $objrealtime = new dbrealtime();
   $where_clause = " 1 = 1 AND (rb.status = 3 OR rb.status = 1) AND rs.id = rb.status";
   $realtimelist = $objrealtime->get_realtime($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield, $sortby);
   $pending_total =0;
   $inprogress_total=0;
   if($realtimelist){
      foreach($realtimelist as $realtime){
         if($realtime['status'] == 1){
           $pending_total = $pending_total + 1;
         }
         if($realtime['status'] == 3){
           $inprogress_total = $inprogress_total + 1;
         }
      }
   }
 if($completenum){  
    //Complete ticket  
    $where_clause2 = " 1 = 1 AND (rb.status = 2) AND rs.id = rb.status";
           $realtimecomplete = $objrealtime->get_realtime($where_clause2, $page, ADMIN_MAX_RECORD_PER_PAGE, $sortfield,$sortby);  
   $templates->setvar("realtimecomplete", $realtimecomplete);
 }   
   $templates->setvar("complete", $completenum);
   $templates->setvar("pending_total", $pending_total);
   $templates->setvar("inprogress_total", $inprogress_total);
   $templates->setvar("realtimelist", $realtimelist);
   $templates->show('service_request.tpl');
?>