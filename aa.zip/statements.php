<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objtickets = new dbtickets();
$objbuilders = new dbbuilders();
$objcustomers = new dbcustomers();
$objpaymenthistory = new dbpaymenthistory();

//requets parameter
$page = request_var('page', 1);
$builder = request_var('builder', '');
$customer = request_var('customer', '');
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');


switch ($mode)
{
    case 'view':
        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);
        //get all builder for select
        $builders = $objbuilders->get_builders('', 0, 0, 'full_name');
        $templates->setvar('builders', $builders);
        
        //get all customer for select
        $customers = $objcustomers->get_customers($builder ? "b.builder_id = $builder" : '', 0, 0, 'full_name');
        $templates->setvar('customers', $customers);
        
        //get all tickets
        $where_clause = ' 1 = 1';
        $where_clause .= $builder ? " AND t.builder_id = $builder" : '';
        $where_clause .= $customer ? " AND t.customer_id = $customer" : '';
        $where_clause .= $from_date ? " AND t.created_date >= '$from_date 00:00:00'" : '';
        $where_clause .= $to_date ? " AND t.created_date <= '$to_date 23:59:59'" : '';        
        $tickets_tmp = $objtickets->get_tickets_cashreceipt($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 't.ticket_id'), request_var('sortby', 'desc') );
        $itemcount = $objtickets->get_tickets_cashreceipt($where_clause, 0, 0, '', '', true);
        
        //calculation ticket
        $tickets = array();
        if ($tickets_tmp)
        {
            foreach ($tickets_tmp as $record)
            {
                $record['builder_discount'] = $record['builder_discount'] / 100 * $record['authoried_amount'];
                $record['invoice_amount'] = $record['authoried_amount'] - $record['builder_discount'];
                
                //calculation total paid amount
                $payments = $objpaymenthistory->get_payments("ticket_id = " . $record['ticket_id'], 0, 0, 'received_date', 'desc');
                $paid_amount = 0;
                if ($payments)
                {
                    foreach ($payments as $payment)
                    {
                        $paid_amount += $payment['received_amount'];
                    }
                }
                $record['paid_amount'] = $paid_amount;
                
                $payment_tmp = array();
                $total_amount = $record['authoried_amount'];
                $total_paid_amount = 0;
                foreach ($payments as $payment)
                {
                    $payment['balanced'] = $total_amount - $payment['received_amount'];
                    $payment_tmp[] = $payment;
                    $total_amount = $payment['balanced'];
                    $total_paid_amount += $payment['received_amount'];
                }
                $record['payments'] = $payment_tmp;
                $record['total_paid_amount'] = $total_paid_amount;
                
                $tickets[] = $record;
            }
        }
        
        $templates->setvar('tickets', $tickets);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case 'get_customer_by_builder':
        $customers = $objcustomers->get_customers($builder ? "b.builder_id = $builder" : '', 0, 0, 'full_name');
        $html = '<select id="customer" name="customer" class="select" style="width:200px">';
        $html .= '<option value="">'. $lang['L_ALL'] .'</option>';
        if ($customers)
        {
            foreach ($customers as $customer)
            {
                $html .= '<option value="'. $customer['customer_id'] .'">'. truncate_text($customer['full_name'], 50) .'</option>';
            }
        }
        $html .= '</select>';
        echo $html;
        return;
    break;
}

//show template
$templates->show('statements.tpl');
?>