<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objnotes = new dbnotes();

//requets parameter
$ticket_id = request_var('ticketid', '');

//get all notes
$notes = $objnotes->get_notes('', 0, 0, request_var('sortfield', 'note_name'), request_var('sortby', 'asc') );
$templates->setvar('notes', $notes);

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    
}


//show template
$templates->show('selectnotes.tpl');
?>