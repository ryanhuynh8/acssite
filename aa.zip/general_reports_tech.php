<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $tax;
ini_set('max_execution_time',360000);
ini_set('memory_limit','256M');
set_time_limit(360000) ;


//define object class
$objgeneral_report = new dbgeneralreports();
//requets parameter
$user = $authenticate->get_user_id();
$from_date = request_var('from_date', '');
$to_date = request_var('to_date', '');
$page = request_var('page', 1);

switch ($mode)
{
    case "view":
        //set filter
        get_date_month($start_date, $end_date);
        if (!$from_date) $from_date = date('m/d/Y', strtotime($start_date) );
        if (!$to_date) $to_date = date('m/d/Y', strtotime($end_date) );
        $templates->setvar('filter', array('from_date' => $from_date, 'to_date' => $to_date) );

        // apply filter
        $whereclause = ' 1 = 1';

        $from_date = convert_to_standard_date($from_date);
        $to_date = convert_to_standard_date($to_date);

        $whereclause .= $from_date ? " AND t3.promised_date >= '$from_date 00:00:00'" : '';
        $whereclause .= $to_date ? " AND t3.promised_date <= '$to_date 23:59:59'" : '';

        //get all user for select
        $users = $objuser->get_users('', 0, 0, 'name');
        $templates->setvar('users', $users);


        $tickets = $objgeneral_report->get_tickets_technicion($whereclause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'tech_name'), request_var('sortby', 'asc') );
        $itemcount = $objgeneral_report->get_tickets_technicion($whereclause, 0, 0, '', '', true);

        $templates->setvar('results', $tickets);
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        break;
}

//show template
$templates->show('general_reports_tech.tpl');
?>