<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;
$fullname = request_var("fullname", "");
$semail = request_var("email", "");
$sphone = request_var("phone", "");
$saddress = request_var("address", "");
$content = request_var("content", "");
$scity = request_var("city", "");
$sstate = request_var("state", "");
$szipcode = request_var("zipcode", "");
$hash = request_var("hash", "");
$dbrealtime = new dbrealtime();
$content = urldecode($content);
$content = strip_tags($content);

$reHash = md5($fullname.$semail.$sphone.$saddress.$scity.$sstate.$szipcode."ACSC");

if ($reHash == $hash)
{
	$saveArr = array(
		"board_system"	=>	3,
		"customer_name"	=>	$fullname,
		"customer_email"	=>	$semail,
		"phone"	=>	$sphone, 
		"address"	=>	$saddress,
		"city"	=>	$szipcode,
		"state"	=>	$sstate,
		"zipcode"	=>	$szipcode,
		"time_received"	=>	date("Y-m-d H:i:s"),
		"description"	=>	$content,
		"status"	=>	1
	);
	$dbrealtime->save("INSERT", $saveArr);
	
	
}

?>