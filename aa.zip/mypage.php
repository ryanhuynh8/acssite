<?php

require_once("includes/common.php");
global $templates, $config, $authenticate, $lang, $user_global;

//define object class
$objdbcomment=new dbcommenttask();
$objdbstatustask=new dbstatustask();
$objannouncements= new dbannouncements();
$objdbtask= new dbtask();
$page = request_var('page', 1);
$id = request_var('id', '');
$task_description=request_var('task_description','');
$status_task_id = request_var('status_task','');
switch ($mode)
{
    case "view":     
    	
        // Get ALl Announcements            
        $date_now=convert_to_standard_date(date('m/d/Y'));
        $where_clause = ' 1 = 1';      		          
        $where_clause .= $date_now ? " AND post_on_date <= '$date_now'" : '';
        $where_clause .= $date_now ? " AND (expired_date >= '$date_now'" : '';
        $where_clause .= $date_now ? " OR expired_date ='0000-00-00') " : '';        
        $announcements_tmp = $objannouncements->get_announcements($where_clause,0, 0, 'post_on_date', 'desc');        
        $templates->setvar('announcement', $announcements_tmp);
        // End all annoucements        
        
         //get all task
        $userid=$user_global['user_id'];
        $preWeek =date('Y-m-d',time() - (7 * 24 * 60 * 60));  
        $where_clause = ' 1 = 1';      
        $where_clause .= ' AND t.status_task_id !=21'; 
        $where_clause .= $userid  ? " AND t.assign_by = $userid" : '';
       // $where_clause .= $preWeek ? " AND (t.complete_date > '$preWeek'" : '';
        //$where_clause .= $preWeek ? " OR t.complete_date ='0000-00-00') " : ''; 
        $tasks = $objdbtask->get_task($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'task_id'), request_var('sortby', 'desc'));             
        $itemcount = $objdbtask->get_task($where_clause, 0, 0, '', '', true);
		
		$totalTasksUnread = $objdbtask->get_task($where_clause . ' AND readed = 0', 0, 0, '', '', true);
		
		$templates->setvar('totalTasksUnread', $totalTasksUnread);
        $templates->setvar('tasks', $tasks);            
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        
        
    break;

    case "archived":
        // Get ALl Announcements            
        $date_now=convert_to_standard_date(date('m/d/Y'));
        $where_clause = ' 1 = 1';        
        $where_clause .= $date_now ? " AND post_on_date <= '$date_now'" : '';
        $where_clause .= $date_now ? " AND (expired_date >= '$date_now'" : '';
        $where_clause .= $date_now ? " OR expired_date ='0000-00-00') " : '';        
        $announcements_tmp = $objannouncements->get_announcements($where_clause,0, 0, 'post_on_date', 'desc');        
        $templates->setvar('announcement', $announcements_tmp);
        // End all annoucements        
        
         //get all task
        $userid=$user_global['user_id'];
        $preWeek =date('Y-m-d',time() - (7 * 24 * 60 * 60));  
        $where_clause = ' 1 = 1';   
        $where_clause .= ' AND t.status_task_id =21';   
        $where_clause .= $userid  ? " AND t.assign_by = $userid" : '';
      //  $where_clause .= $preWeek ? " AND (t.complete_date <= '$preWeek'" : '';
     //   $where_clause .= $preWeek ? " AND t.complete_date !='0000-00-00') " : '';  
        $tasks = $objdbtask->get_task($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'task_id'), request_var('sortby', 'desc'));                    
        $itemcount = $objdbtask->get_task($where_clause, 0, 0, '', '', true);
		
		$totalTasksUnread = $objdbtask->get_task($where_clause . ' AND readed = 0', 0, 0, '', '', true);
		
		$templates->setvar('totalTasksUnread', $totalTasksUnread);
		
        $templates->setvar('tasks', $tasks);            
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
        
        
    break;

    case "edit":       //edit status 
          //get all status task for select
        $status_task = $objdbstatustask->get_statustask('', 0, 0, 'status_task_id');        
        
         //get all task
        $task_infor = $objdbtask->get_task_by_id($id);
        
        //get all comment ////////
        $where_clause = ' 1 = 1';           
        $where_clause .= $id  ? " AND t.task_id = $id" : '';                   
        $tasks_comment = $objdbcomment->get_comment($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, "comment_id", "desc");            
        $itemcount = $objdbcomment->get_comment($where_clause, 0, 0, '', '', true);
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false,true) : "");
        //add comment
        if ($_SERVER['REQUEST_METHOD'] != "POST")
         {
          
        }
        else
        {
            $validator = true;                
            //  Complete Date
            $status_task = $objdbstatustask->get_status_task_by_id($status_task_id);
            $status_task_name = $status_task['status_task_name'];           
            $complete_date=null;            
            if($status_task_name == 'Complete')
            {
                $complete_date= date('Y-m-d');    
            }
            $save_task = array('complete_date'=>$complete_date,
                               'status_task_id' => $status_task_id);                                                                                                                        
            
            if ($validator)
            {                
                $objdbtask->save('UPDATE', $save_task, " task_id = $id");                               
                $templates->setvar('save_success', true);                
                redirect("mypage.php?mode=details&save_success=true&id=".$id);                
            }
            else
            {
                $templates->setvar('task_infor', $save_task);  
            }
         }
         
    
    break;

    case "details":   //add comment     
          //get all status task for select
        $status_task = $objdbstatustask->get_statustask('', 0, 0, 'status_task_id');        
        
         //get all task
        $task_infor = $objdbtask->get_task_by_id($id);
        
        //get all comment ////////
        $where_clause = ' 1 = 1';           
        $where_clause .= $id  ? " AND t.task_id = $id" : '';                   
        $tasks_comment = $objdbcomment->get_comment($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, "comment_id", "desc");            
        $itemcount = $objdbcomment->get_comment($where_clause, 0, 0, '', '', true);
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false,true) : "");
        //add comment
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
			//update task to read
			$objdbtask->save('UPDATE', array('readed' => 1) , 'task_id = ' . (int) $id);
        }
        else
        {
			$validator = true;              
			if (trim($task_description) == '')
			{                
				$validator = false;
				$templates->setvar('error_description', $lang['E_DESCRIPTION']);
			}                
			$posted_by=$user_global['user_id'];                      
			$save_comment = array('posted_by' => $posted_by,
                              'task_id' => $id,
                              'post_on_date' => date('Y-m-d H:i:s'),                                                                  
                              'description' => $task_description);                                      
           
            if ($validator)
            {                
                $objdbcomment->save('INSERT', $save_comment);                    
                $templates->setvar('save_success', true);
				//get all comment ////////
                $where_clause = ' 1 = 1';           
                $where_clause .= $id  ? " AND t.task_id = $id" : '';            
                $tasks_comment = $objdbcomment->get_comment($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE,"comment_id", "desc");            
                $itemcount = $objdbcomment->get_comment($where_clause, 0, 0, '', '', true);            
                          
                //paging
                $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false,true) : "");
    
			}
			else
			{                    
				$templates->setvar('$tasks_comment', $save_comment);  
			}
         }
         
        $templates->setvar('status_task', $status_task);
        $templates->setvar('task_infor', $task_infor);
        $templates->setvar('tasks_comment', $tasks_comment);
        
    break;
}


$templates->show('mypage.tpl');
?>