<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;


if (!$authenticate->get_authentication())
    redirect('index.php?permission=false');

//define object
$objcompany = new dbcompany();
$objproposals = new dbproposals();
$objcustomers = new dbcustomers();

$id = request_var('id', '');
$email = request_var('email', '');


if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    $validator_error = true;
    if (trim($email) == '')
    {
        $validator_error = false;
        $templates->setvar('error_email', $lang['E_EMAIL']);
    }
    else
    {
        if (!is_valid_email($email))
        {
            $validator_error = false;
            $templates->setvar('error_email', $lang['E_EMAIL_INVALID']);
        }
    }
    
    if ($validator_error)
    {
        $msgbody = get_email_body($id, $base_url, $tax);
        $from = $config->configurations["ADMIN_EMAIL"];
        $subject = "ACS Absolute Comfort LLC - Proposal";
        send_mail($from, $email, $subject, $msgbody, true);
        
        $templates->setvar('save_success', true);
    }
    else
    {
        $templates->setvar('proposal_infor', array('email' => $email) );
    }
}
else
{
    $proposal_infor = $objproposals->get_proposal_by_id($id);
    $customer = $objcustomers->get_customer_by_id($proposal_infor['customer_id']);
    $proposal_infor['email'] = $customer['email'];
    $templates->setvar('proposal_infor', $proposal_infor);
}


$templates->show('proposalemail.tpl');


function get_email_body($id, $base_url, $tax)
{
    global $objcompany, $objproposals, $objcustomers;
    
    $company_infor = $objcompany->get_company();
    
    $results = array();
    $parts_selected = $objproposals->get_parts_selected($id);
    $index = 0;
    $category_id = '';
    foreach($parts_selected as $part)
    {                
        if ($part['proposal_category_id'] != $category_id)
        {
            $category_id = $part['proposal_category_id'];                    
            $results[$index]['category_name'] = $part['category_name'];
            $results[$index]['parts'][] = $part;
            $index++;
        }
        else
        {
            $results[$index - 1]['parts'][] = $part;
        }
    }            
    
    $proposal_infor = $objproposals->get_proposal_by_id($id);
    
    $body = '';
    $body .= '
    <div style="width:100%">
        <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tbody><tr>
                <td width="50%" valign="top">
                    <img title="ACS Absolute Comfort, LLC." alt="ACS Absolute Comfort, LLC." src="'. $base_url .'upload/company/' .$company_infor['logo'] .'"></td>
                <td width="50%" valign="top" style="font-size:120%;">
                    <div style="line-height:150%;padding:10px 0 30px;">
                        <b style="font-size:120%;">'. $company_infor['name'] .'</b><br>'/*.nl2br($company_infor['address']) */.'
                        12102 5th St Houston<br>Houston, TX 77072
                        <br/>281-495-2013 Office | 1888-6307801 Fax
                        <br/>Web: <a href="http://www.acscomfort.com" target="_blank">www.acscomfort.com</a>
                        <br/>Email: <a href="mailto:acsabsolutecomfort@yahoo.com" target="_blank">acsabsolutecomfort@yahoo.com</a>
                        <br/>License #: TACLB023232C.
                    </div>
                </td>
            </tr>
            <tr>
                <td style="padding:10px 0;line-height:135%;" colspan="2"><br />
                    The following is a list of charges that are covered and not covered by your home warranty. Included are upgrades that are highly recommended or required in order to bring your equipment up to current codes and regulations required by EPA guidelines for handling refrigerants. ACS Absolute Comfort suggests that all ciphers that violating safety of the home owner as well as our technicians must be repaired before performing any repair to your air conditioning or heating system. Other charges include maintenance required to properly diagnose your system and charge related to the installation of new equipment. If you disagree with the non cover charges, our best advice will be call to your insurance provider and ask for a second opinion or cash out.
                </td>
        </tr></tbody></table>
        
        <div style="padding: 5px 0;">
            <div style="padding: 5px 0;">
                <table width="80%" cellspacing="1" cellpadding="5" border="0" style="border: 1px solid #C0C0C0;">';
               
            $index = 0;
            $total_price = 0;
            if ($results)
            {
                foreach ($results as $entry)
                {
                    if ($index == 0)
                    {
                        $body .= '<tr style="background-color: #045979;color: #FFFFFF;">
                                <th style="text-align:left">'.$entry['category_name'].'</th>
                                <th style="text-align:left;width: 50px;">Qty</th>
                                <th style="text-align:left;width: 80px;">Price</th>
                            </tr>';
                    }
                    else
                    {
                        $body .= '<tr style="background-color: #045979;color: #FFFFFF;">
                                <th style="text-align:left">'.$entry['category_name'].'</th>
                                <th style="text-align:left;width: 50px;"></th>
                                <th style="text-align:left;width: 80px;"></th>
                            </tr>';
                    }
                    $index2 = 0;
                    foreach ($entry['parts'] as $entry2)
                    {
                        $body .= '<tr style="'. ($index2 % 2 == 0 ? 'background-color: #E1E1E1;' : 'background-color: #F7F7F7;') .'">
                                    <td>'. $entry2['proposal_part_name'] .'</td>
                                    <td>'. $entry2['quantity'] .'</td>
                                    <td>'. ($entry2['price'] != '' ? number_format($entry2['quantity'] * $entry2['price'], 2, '.', ',') : '') .'</td>
                                </tr>';
                        $index++;
                        $total_price += $entry2['quantity'] * $entry2['price'];
                    }
                    
                }
            }
            else
            {
                $body .= '<tr style="background-color: #E1E1E1;">
                                    <td colspan="3">No Part record found.</td>
                                </tr>';
            }
            $body .= '
                </table>
                <table width="80%" cellspacing="1" cellpadding="5" border="0" style="border: 0">
                    <tbody>
                    <tr>
                        <td align="right"><b>Total Amount:</b></td>
                        <td align="right" style="width: 50px;">'. number_format($total_price, 2, '.', '') .'</td>
                    </tr>
                </tbody></table>
            </div>
            <br>
            <div style="border-bottom: 1px solid #777777;color: #000000;font-size: 110%;font-weight: bold;margin-bottom: 5px;padding: 10px 0 3px;">Customer Information</div>
            <table width="100%" cellspacing="1" cellpadding="5" border="0">
                <tbody><tr>
                    <td style="background-color: #EEEEEE;padding: 0 5px;white-space: nowrap;width: 140px;">Customer Name:</td>
                    <td colspan="5">'. $proposal_infor['full_name'] .'</td>
                </tr>
                <tr>
                    <td style="background-color: #EEEEEE;padding: 0 5px;white-space: nowrap;width: 140px;">Address:</td>
                    <td colspan="5">'. $proposal_infor['address'] .'</td>
                </tr>
                <tr>
                    <td style="background-color: #EEEEEE;padding: 0 5px;white-space: nowrap;width: 140px;">City:</td>
                    <td>'. $proposal_infor['city'] .'</td>
                    <td style="background-color: #EEEEEE;padding: 0 5px;white-space: nowrap;width:50px">State:</td>
                    <td>'. $proposal_infor['state'] .'</td>
                    <td style="background-color: #EEEEEE;padding: 0 5px;white-space: nowrap;width:35px">Zip:</td>
                    <td style="width:250px">'. $proposal_infor['zip'] .'</td>
                </tr>
            </tbody></table>
            <br>
            <div style="border-bottom: 1px solid #777777;color: #000000;font-size: 110%;font-weight: bold;margin-bottom: 5px;padding: 10px 0 3px;">HOMEOWNER AUTHORIZATION</div>
            <span style="line-height: 150%;">All charge outlined above have been explained by the technician. PAYMENT FOR ALL HOMEOWNER CHARGES IS DUE PRIOR TO PERFORMING WORK</span>
            <br><br>
            <div style="border-bottom: 1px solid #777777;color: #000000;font-size: 110%;font-weight: bold;margin-bottom: 5px;padding: 10px 0 3px;">Total Homeowner Charges:</div>
            <span style="line-height: 150%;">I _____________________ , homeowner, authorize ACS Absolute Comfort to proceed with the above repairs.</span>
            <br><br>
            <br><br><br>
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody><tr>
                    <td width="70%"><b>Signature</b></td>
                    <td><b>Date</b></td>
                </tr>
            </tbody></table>
            <br><br><br><br><br><br>
        </div>
    </div>
    ';
    
    return $body;
}
?>