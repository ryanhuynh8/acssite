<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objbuilders = new dbbuilders();
$objstates = new dbstates();
$objcustomers = new dbcustomers();

//requets parameter
$page = request_var('page', '1');
$name = request_var('name', '');
$contact_name = request_var('contact_name', '');
$id = request_var('id', '');
$full_name = request_var('full_name', '');
$address = request_var('address', '');
$city = request_var('city', '');
$state = request_var('state', '');
$zip = request_var('zip', '');
$contact_name = request_var('contact_name', '');
$phone1 = request_var('phone1', '');
$phone2 = request_var('phone2', '');
$fax = request_var('fax', '');
$office_number = request_var('office_number', '');
$discount = request_var('discount', '');
$deduct = request_var('deduct', '');


switch ($mode)
{
    case "view":
        //get all builders
        $where_clause = " 1 = 1";
        if ($name)
            $where_clause .= " AND full_name like '%$name%'";
        if ($contact_name)
            $where_clause .= " AND contact_name like '%$contact_name%'";
        
        $builders = $objbuilders->get_builders($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', ''), request_var('sortby', 'asc') );
        $itemcount = $objbuilders->get_builders($where_clause, 0, 0, '', '', true);
        $templates->setvar('builders', $builders);
        
        
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "details":
        if ($id)
        {
            //get builder information
            $builder_infor = $objbuilders->get_builder_by_id($id);
            
            $templates->setvar('builder_infor', $builder_infor);            
        }
    break;

    case "delete":
        if ($id)
        {
            //delete all customers
            $save_customer = array('builder_id' => 0);
            $objcustomers->save('UPDATE', $save_customer, "builder_id = $id");
            //delete builder
            $objbuilders->delete($id);      
        
            $templates->setvar('delete_success', true);
        }
    break;

    case "edit":
        if ($id)
        {
            //get state for select
            $states = $objstates->get_states('', 0, 0, 'state_code');
            $templates->setvar('states', $states);
            
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                //get builder information
                $builder_infor = $objbuilders->get_builder_by_id($id);
                
                
                $templates->setvar('builder_infor', $builder_infor);                
            }
            else
            {
                $validator = true;
            
                if (trim($full_name) == '')
                {
                    $validator = false;
                    $templates->setvar('error_full_name', $lang['E_FULL_NAME']);
                }
                if (trim($address) == '')
                {
                    $validator = false;
                    $templates->setvar('error_address', $lang['E_ADDRESS']);
                }
                
                $save_builder = array('full_name' => $full_name,
                                       'address' => $address,
                                       'city' => $city,
                                       'state' => $state,
                                       'zip' => $zip,
                                       'contact_name' => $contact_name,
                                       'phone1' => $phone1,
                                       'phone2' => $phone2,
                                       'fax' => $fax,
                                       'office_number' => $office_number,
                                       'discount' => $discount,
                                       'deduct_from_contractor' => $deduct);
                
                if ($validator)
                {
                    $objbuilders->save('UPDATE', $save_builder, "builder_id = $id");
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('builder_infor', $save_builder);  
                }
            }
        }
    break;
    
    case "add":
        //get state for select
        $states = $objstates->get_states('', 0, 0, 'state_code');
        $templates->setvar('states', $states);
        
        if ($_SERVER['REQUEST_METHOD'] != "POST")
        {
            
        }
        else
        {
            $validator = true;
            
            if (trim($full_name) == '')
            {
                $validator = false;
                $templates->setvar('error_full_name', $lang['E_FULL_NAME']);
            }
            if (trim($address) == '')
            {
                $validator = false;
                $templates->setvar('error_address', $lang['E_ADDRESS']);
            }
            
            $save_builder = array('full_name' => $full_name,
                                   'address' => $address,
                                   'city' => $city,
                                   'state' => $state,
                                   'zip' => $zip,
                                   'contact_name' => $contact_name,
                                   'phone1' => $phone1,
                                   'phone2' => $phone2,
                                   'fax' => $fax,
                                   'office_number' => $office_number,
                                   'discount' => $discount,
                                   'deduct_from_contractor' => $deduct);
            
            if ($validator)
            {
                $objbuilders->save('INSERT', $save_builder);
                
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('builder_infor', $save_builder);  
            }
        }
    break;
}



//show template
$templates->show('builder.tpl');
?>