<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;


$templates->show('realtime_menu.tpl');
?>