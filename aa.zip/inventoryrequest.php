<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objlaborsparts = new dblabors_parts();
$objtickets = new dbtickets();
$objinventory = new dbinventory();

//requets parameter
$page = request_var('page', '1');
$id = request_var('id', '');
$user_id = request_var('user_id', '');
$item_number = request_var('item_number', '');
$description = request_var('description', '');
$quantity = request_var('quantity', '');
$part = request_var('part', '');

switch ($mode)
{
    case "view":
        $_SESSION['item_number'] = '';
        $_SESSION['description'] = '';
        
        //get all part
        $where_clause = " 1 ";
        $where_clause .= $user_id ? " AND u.user_id = " . $user_id : '';
        
        //get all user for select tech name
        $users = $objuser->get_users('', 0, 0, 'name', 'asc');
        $templates->setvar('users', $users);
        
        //get all technicians inventory
        $technicians = $objinventory->get_inventories_users($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'name'), request_var('sortby', 'asc') );
        $itemcount = $objinventory->get_inventories_users($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('technicians', $technicians);
        
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;
    
    case "view_edit_inventory":
        if ($user_id)
        {
            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                $search = request_var('search', '');
                $clear = request_var('clear', '');
                if ($search)
                {
                    $_SESSION['item_number'] = $item_number;
                    $_SESSION['description'] = $description;
                }
                if ($clear)
                {
                    $_SESSION['item_number'] = '';
                    $_SESSION['description'] = '';
                }
            }
            //get user information
            $user_infor = $objuser->get_user_by_id($user_id);
            $templates->setvar('user_infor', $user_infor);
            
            //get part by technicians
            $where_clause = " 1 AND i.user_id = " . $user_infor['user_id'];
            $where_clause .= $_SESSION['description'] ? " AND lb.description like '%". $_SESSION['description'] ."%'" : '';
            $where_clause .= $_SESSION['item_number'] ? " AND lb.item_number like '%". $_SESSION['item_number'] ."%'" : '';
            
            $tmp_parts = $objinventory->get_inventories($where_clause, 0, 0, request_var('sortfield', 'inventory_id'), request_var('sortby', 'asc') );            
            $parts = array();
            $total_amount = 0;
            if ($tmp_parts)
            {
                foreach ($tmp_parts as $part)
                {
                    $part['tech_price'] = $part['unit_cost']  + $part['unit_cost'] * $part['tech_mark_up'] / 100;
                    $part['price'] = number_format($part['tech_price'], 2, '.', '') * number_format($part['quantity'], 2, '.', '');
                    $parts[] = $part;
                    
                    $total_amount += $part['price'];
                }                
            }
            
            $templates->setvar('total_amount', $total_amount);
            $templates->setvar('parts', $parts);
        }
    break;

    case "delete":
        if ($id)
        {
            $part_infor = $objinventory->get_inventory_by_id($id);
            
            $objinventory->update_quantity_warehourse($part_infor['quantity'], $part_infor['labor_part_id']);
            
            //delete part
            $objinventory->delete($id);            
            
            $templates->setvar('delete_success', true);       
        }
    break;

    case "return":
        if ($id)
        {

            //get user information
            $user_infor = $objuser->get_user_by_id($user_id);
            $templates->setvar('user_infor', $user_infor);
            //get part information
            $part_infor = $objinventory->get_inventory_by_id($id);
            $part_infor['tech_price'] = $part_infor['unit_cost']  + $part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100;
            $part_infor['price'] = number_format($part_infor['tech_price'], 2, '.', '') * number_format($part_infor['quantity'], 2, '.', '');
            $templates->setvar('part_infor', $part_infor);
            
            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                $validator_error = true;
                
                if (trim($quantity) == '')
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY']);
                }
                elseif (!is_numeric($quantity) || $quantity < 0)
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY_NUMBERIC']);
                }
                elseif ($quantity > $part_infor['quantity'])
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY_LEAST']);  
                }
                
                if ($validator_error)
                {
                    //update quantity user inventory
                    $quantity_inventory = $part_infor['quantity'] - $quantity;
                    $save_inventory = array('quantity' => $quantity_inventory,
                                            'actived_date' => date('Y-m-d') );
                    $objinventory->save('UPDATE', $save_inventory, " inventory_id=$id");

                    $save_track=array('labor_part_id'=>$part_infor['labor_part_id'],
                                      'inventory_id'=>$id,
                                      'date'=>date('Y-m-d'),
                                      'approved_id'=>$authenticate->get_user_id(),
                                      'quantity'=>$quantity);
                    $objinventory->save_track('INSERT',$save_track);

                    //update quantity warehourse
                    $objinventory->update_quantity_warehourse($quantity, $part_infor['labor_part_id']);
                    $objinventory->delete_inventory_zero();
                    $templates->setvar('save_success', true);
                }
            }
        }
    break;

    case "lost":
        if ($id)
        {
            //get user information
            $user_infor = $objuser->get_user_by_id($user_id);
            $templates->setvar('user_infor', $user_infor);
            
            //get part information
            $part_infor = $objinventory->get_inventory_by_id($id);
            $part_infor['tech_price'] = $part_infor['unit_cost']  + $part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100;
            $part_infor['price'] = number_format($part_infor['tech_price'], 2, '.', '') * number_format($part_infor['quantity'], 2, '.', '');
            $templates->setvar('part_infor', $part_infor);
            
            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                $validator_error = true;
                
                if (trim($quantity) == '')
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY']);
                }
                elseif (!is_numeric($quantity) || $quantity < 0)
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY_NUMBERIC']);
                }
                elseif ($quantity > $part_infor['quantity'])
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY_LEAST']);
                }
                
                if ($validator_error)
                {
                    $quantity = $part_infor['quantity'] - $quantity;
                    $save_inventory = array('quantity' => $quantity,
                                            'actived_date' => date('Y-m-d') );
                    $objinventory->save('UPDATE', $save_inventory, " inventory_id=$id");
                    
                    $objinventory->delete_inventory_zero();
                    
                    $templates->setvar('save_success', true);
                }
            }
        }
    break;
    
    case "edit":
        if ($id)
        {
            //get user information
            $user_infor = $objuser->get_user_by_id($user_id);
            $templates->setvar('user_infor', $user_infor);
            
            //get part information
            $part_infor = $objinventory->get_inventory_by_id($id);
            $part_infor['tech_price'] = $part_infor['unit_cost']  + $part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100;
            $part_infor['price'] = number_format($part_infor['tech_price'], 2, '.', '') * number_format($part_infor['quantity'], 2, '.', '');
            
            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                $moreQuantity = $quantity - $part_infor['quantity'];
                
                $validator_error = true;
                
                if (trim($quantity) == '')
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY']);
                }
                elseif (!is_numeric($quantity) || $quantity < 0)
                {
                    $validator_error = false;
                    $templates->setvar('error_quantity', $lang['E_QUANTITY_NUMBERIC']);
                }
                else
                {
                    $part_infor_validator = $objlaborsparts->get_labor_part_by_id($part_infor['labor_part_id']);
                    
                    if ($moreQuantity > $part_infor_validator['quantity_on_hand'] && $part_infor['labor_part_id'])
                    {
                        $validator_error = false;
                        $templates->setvar('error_quantity', $lang['E_ENOUGH_QUANTITY']);
                    }
                }
                
                $save_inventory = array('quantity' => $quantity,
                                        'actived_date' => date('Y-m-d') );
                
                if ($validator_error)
                {                    
                    $objinventory->save('UPDATE', $save_inventory, " inventory_id=$id");
                    
                    $objinventory->update_quantity_warehourse(-$moreQuantity, $part_infor['labor_part_id']);
                    
                    $objinventory->delete_inventory_zero();
                    
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $part_infor['quantity'] = $save_inventory['quantity'];
                }
            }
            
            $templates->setvar('part_infor', $part_infor);
        }
    break;


    case "info":
        if ($id)
        {
            //get user information
            $user_infor = $objuser->get_user_by_id($user_id);
            $templates->setvar('user_infor', $user_infor);

            //get part information
            $part_infor = $objinventory->get_inventory_by_id($id);
            $part_infor['tech_price'] = $part_infor['unit_cost']  + $part_infor['unit_cost'] * $part_infor['tech_mark_up'] / 100;
            $part_infor['price'] = number_format($part_infor['tech_price'], 2, '.', '') * number_format($part_infor['quantity'], 2, '.', '');
            $return = $objinventory->get_history_by_id($id);
            $templates->setvar('return',$return);
            $templates->setvar('part_infor', $part_infor);
        }
        break;

    case "request_supply" :
        $save = request_var('save', '');
        $search = request_var('search', '');
        if ($user_id)
        {
            //get user information
            $user_infor = $objuser->get_user_by_id($user_id);
            $templates->setvar('user_infor', $user_infor);
            
            //get all part no labor
            $where_clause = " 1 AND type = 2";
            $parts = $objlaborsparts->get_labors_parts($where_clause, 0, 0, 'description');
            $templates->setvar('parts', $parts);
            
            if ($_SERVER['REQUEST_METHOD'] == "POST")
            {
                //get all part no labor
                $where_clause = " 1 AND type = 2 ";
                $where_clause .= $item_number ? " AND item_number like '%$item_number%' " : "";
                $where_clause .= $description ? " AND description like '%$description%' " : "";
                $parts = $objlaborsparts->get_labors_parts($where_clause, 0, 0, 'description');
                $templates->setvar('parts', $parts);
                
                if ($save)
                {
                    $validator_error = true;
                    if ($part == '')
                    {
                        $validator_error = false;
                        $templates->setvar('error_part', $lang['E_PART']);
                    }
                    if (trim($quantity) == '')
                    {
                        $validator_error = false;
                        $templates->setvar('error_quantity', $lang['E_QUANTITY']);
                    }
                    elseif (!is_numeric($quantity) || $quantity <= 0)
                    {
                        $validator_error = false;
                        $templates->setvar('error_quantity', $lang['E_QUANTITY_NUMERIC']);
                    }
                    else
                    {
                        $part_infor = $objlaborsparts->get_labor_part_by_id($part);
                        if ($quantity > $part_infor['quantity_on_hand'] && $part)
                        {
                            $validator_error = false;
                            $templates->setvar('error_quantity', $lang['E_ENOUGH_QUANTITY']);
                        }
                    }
                    
                    $save_inventory = array('user_id' => $user_infor['user_id'],
                                            'labor_part_id' => $part,
                                            'quantity' => $quantity,
                                            'actived_date' => date('Y-m-d') );
                    
                    if ($validator_error)
                    {
                        //check if inventory exists
                        $where_clause = " 1 AND i.labor_part_id = $part and i.user_id = " . $user_infor['user_id'];
                        $inventories = $objinventory->get_inventories($where_clause, 0, 0);
                        $inventory = $inventories[0];
                        if ($inventory)
                        {
                            $quantity_inventory = $quantity + $inventory['quantity'];
                            $objinventory->save('UPDATE', array('quantity' => $quantity_inventory, 'actived_date' => date('Y-m-d') ), " inventory_id=" . $inventory['inventory_id']);
                        }
                        else
                        {
                            $objinventory->save('INSERT', $save_inventory);
                        }
                        
                        //update quantity warehourse
                        $objinventory->update_quantity_warehourse(-$quantity, $part);
                        
                        $templates->setvar('save_success', true);
                        
                        //notify email
                        $objlaborsparts->email_warning_quantity($part);
                        
                    }
                    else
                    {
                        $templates->setvar('part_infor', $save_inventory);
                    }
                }
            }
        }
    break;
}


//show template
$templates->show('inventoryrequest.tpl');
?>