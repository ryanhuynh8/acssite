<?php
require_once("includes/common.php");
global $templates, $config, $authenticate, $lang;

//define object class
$objproposals = new dbproposals();
$objproposalparts = new dbproposalparts();

$objbankcategories = new dbbankcategories();
$objbankstatement = new dbbankstatement();

//requets parameter
$id = request_var('id', '');
$category_name = request_var('category_name', '');
$keyword = request_var('keyword', '');
$page = request_var('page', 1);


switch ($mode)
{
    case 'view':       
        //get all proposal categories
        $where_clause = ' 1 = 1';
        $where_clause .= $category_name ? " AND bank_category_name like '%$category_name%'" : '';
        $where_clause .= $keyword ? " AND keyword like '%$keyword%'" : '';
        
        $categories = $objbankcategories->get_categories($where_clause, $page, ADMIN_MAX_RECORD_PER_PAGE, request_var('sortfield', 'bank_category_name'), request_var('sortby', 'asc') );
        $itemcount = $objbankcategories->get_categories($where_clause, 0, 0, '', '', true);
        
        $templates->setvar('categories', $categories);
        //paging
        $templates->setvar("PAGING", $itemcount > ADMIN_MAX_RECORD_PER_PAGE ? paging($page, ADMIN_MAX_RECORD_PER_PAGE, $itemcount, "page","", true, false) : "");
    break;

    case 'edit':
        if ($id)
        {
            if ($_SERVER['REQUEST_METHOD'] != "POST")
            {
                $category_infor = $objbankcategories->get_category_by_id($id);
                
                $templates->setvar('category_infor', $category_infor);
            }
            else
            {
                $error_validator = true;
                
                if ($category_name == '')
                {
                    $error_validator = false;
                    $templates->setvar('error_category_name', $lang['E_CATEGORY_NAME']);
                }
                
                $save_category = array('bank_category_name' => trim($category_name),
                                       'keyword'            => trim($keyword) );
                
                if ($error_validator)
                {
                    $objbankcategories->save('UPDATE', $save_category, " bank_category_id = $id");
                    $templates->setvar('save_success', true);
                }
                else
                {
                    $templates->setvar('category_infor', $save_category);
                }
            }
        }
    break;

    case 'add':        
        if ($_SERVER['REQUEST_METHOD'] == "POST")
        {
            $error_validator = true;
            
            if ($category_name == '')
            {
                $error_validator = false;
                $templates->setvar('error_category_name', $lang['E_CATEGORY_NAME']);
            }
            
            $save_category = array('bank_category_name' => trim($category_name),
                                   'keyword'            => trim($keyword) );
            
            if ($error_validator)
            {
                $objbankcategories->save('INSERT', $save_category);
                $templates->setvar('save_success', true);
            }
            else
            {
                $templates->setvar('category_infor', $save_category);
            }
        }
    break;

    case 'details':
        if ($id)
        {            
            $category_infor = $objbankcategories->get_category_by_id($id);
                
            $templates->setvar('category_infor', $category_infor);
        }
    break;

    case "delete":
        if ($id)
        {
            $statements = $objbankstatement->get_statements_by_category($id);
            if ($statements)
            {
                $confirm_delete = request_var('confirm_delete', '');
                if ($confirm_delete)
                {
                    $objbankstatement->delete_statements_by_category($id);                    
                    $objbankcategories->delete($id);
                    $templates->setvar('delete_success', true);
                }
                else
                {
                    $templates->setvar('confirm_delete', true);
                }
            }
            else
            {
                $objbankcategories->delete($id);
                $templates->setvar('delete_success', true);
            }
        }
    break;
}



//show template
$templates->show('bankstatementcategories.tpl');
?>